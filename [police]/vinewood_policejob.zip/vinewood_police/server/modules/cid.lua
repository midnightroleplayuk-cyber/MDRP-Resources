-- CID case files: an investigation's officer in case (OIC), status, people, linked references
-- (calls, custody, exhibits, MDT incidents), actions and an investigation log.
VPO.Cases = {}
local CS = VPO.Cases
local Cfg = Config.CID
local L = VPO.L

local function label(o) return VPO.Officers.Label(o) end
local function dec(s, fallback) local ok, v = pcall(json.decode, s or ''); return ok and v or fallback end

local function canManage(src, o, c)
    if c and c.oic_identifier == o.identifier then return true end
    if o.rank.level >= VPO.Ranks.Level(Cfg.ManageRank) then return true end
    local s = VPO.Duty.Get(src)
    return s ~= nil and VPO.Util.Contains(Cfg.ManageUnits, s.unit)
end

local function entry(caseId, kind, text, by, extra)
    extra = extra or {}
    MySQL.insert.await([[INSERT INTO vpo_case_entries (case_id, kind, text, officer, assigned_identifier, assigned_name, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)]],
        { caseId, kind, tostring(text):sub(1, 2000), by, extra.assignedIdentifier, extra.assignedName, os.time() })
    MySQL.update('UPDATE vpo_cases SET updated_at = ? WHERE id = ?', { os.time(), caseId })
end

--- Creates a case. data = { title, type, summary, links = { refs } }. Returns id, ref.
function CS.Create(src, o, data)
    local title = VPO.Util.Trim(data.title, 160)
    if not title then return nil, L('cid_need_title') end
    local t = os.time()
    local links = {}
    for _, r in ipairs(data.links or {}) do local x = VPO.Util.Trim(r, 32); if x then links[#links + 1] = x end end
    local id = MySQL.insert.await([[INSERT INTO vpo_cases (title, type, status, oic_identifier, oic_name, summary, links, people, created_by, created_at, updated_at)
        VALUES (?, ?, 'Open', ?, ?, ?, ?, '[]', ?, ?, ?)]],
        { title, VPO.Util.Contains(Cfg.Types, data.type) and data.type or 'Other', o.identifier, label(o), VPO.Util.Trim(data.summary, 2000),
          json.encode(links), label(o), t, t })
    if not id then return nil, L('qual_failed') end
    local ref = ('CID/%s/%s/%05d'):format(Config.Force.short, os.date('%y%m'), id)
    MySQL.update('UPDATE vpo_cases SET ref = ? WHERE id = ?', { ref, id })
    entry(id, 'log', ('Case opened by %s'):format(label(o)), label(o))
    VPO.Audit.Log({ action = 'cid.create', actor = src, targetType = 'case', targetId = ref, new = { title = title } })
    return id, ref
end

local function caseView(src, o, c)
    local entries = MySQL.query.await('SELECT * FROM vpo_case_entries WHERE case_id = ? ORDER BY id DESC LIMIT 150', { c.id }) or {}
    local actions, log = {}, {}
    for _, e in ipairs(entries) do
        if e.kind == 'action' then actions[#actions + 1] = e else log[#log + 1] = e end
    end
    local links = dec(c.links, {})
    -- Exhibits linked to any of the case's references, or to the case itself
    local refs = { c.ref }
    for _, r in ipairs(links) do refs[#refs + 1] = r end
    local exhibits = {}
    if #refs > 0 then
        local marks = {}
        for _ in ipairs(refs) do marks[#marks + 1] = '?' end
        local rows = MySQL.query.await(('SELECT ref, description, status, linked_ref FROM vpo_exhibits WHERE linked_ref IN (%s) OR ref IN (%s) ORDER BY id'):format(
            table.concat(marks, ','), table.concat(marks, ',')), (function() local a = {} for _, r in ipairs(refs) do a[#a + 1] = r end for _, r in ipairs(refs) do a[#a + 1] = r end return a end)()) or {}
        exhibits = rows
    end
    return {
        id = c.id, ref = c.ref, title = c.title, type = c.type, status = c.status, oic = c.oic_name, oicMe = c.oic_identifier == o.identifier,
        summary = c.summary, links = links, people = dec(c.people, {}), createdAt = c.created_at, updatedAt = c.updated_at,
        actions = actions, log = log, exhibits = exhibits, canManage = canManage(src, o, c),
    }
end

local function getCase(id) return MySQL.single.await('SELECT * FROM vpo_cases WHERE id = ?', { tonumber(id) or 0 }) end

VPO.Net.Callback('cid:list', { permission = 'cid.view', rate = 'cid' }, function(src, o, d)
    d = type(d) == 'table' and d or {}
    local q = VPO.Util.Trim(d.q, 60)
    local rows
    if q then
        local like = '%' .. q:gsub('[%%_]', '') .. '%'
        rows = MySQL.query.await([[SELECT id, ref, title, type, status, oic_name, updated_at FROM vpo_cases
            WHERE ref LIKE ? OR title LIKE ? OR links LIKE ? OR people LIKE ? ORDER BY updated_at DESC LIMIT 50]], { like, like, like, like })
    elseif d.mine then
        rows = MySQL.query.await('SELECT id, ref, title, type, status, oic_name, updated_at FROM vpo_cases WHERE oic_identifier = ? AND closed_at IS NULL ORDER BY updated_at DESC LIMIT 50', { o.identifier })
    else
        rows = MySQL.query.await('SELECT id, ref, title, type, status, oic_name, updated_at FROM vpo_cases WHERE closed_at IS NULL ORDER BY updated_at DESC LIMIT 50')
    end
    -- Actions given to me on open cases
    local mine = MySQL.query.await([[SELECT e.id, e.text, e.case_id, c.ref FROM vpo_case_entries e JOIN vpo_cases c ON c.id = e.case_id
        WHERE e.kind = 'action' AND e.assigned_identifier = ? AND e.done_at IS NULL AND c.closed_at IS NULL ORDER BY e.id LIMIT 20]], { o.identifier }) or {}
    local out = VPO.Hub.Header(src, o)
    out.ok, out.cases, out.myActions, out.q, out.mine = true, rows or {}, mine, q, d.mine == true
    out.types, out.statuses, out.personRoles = Cfg.Types, Cfg.Statuses, Cfg.PersonRoles
    out.canCreate = VPO.Permissions.Check(src, 'cid.create') == true
    return out
end)

VPO.Net.Callback('cid:create', { permission = 'cid.create', rate = 'cid' }, function(src, o, d)
    d = type(d) == 'table' and d or {}
    local links = {}
    for r in tostring(d.links or ''):gmatch('[^,%s]+') do links[#links + 1] = r end
    local id, ref = CS.Create(src, o, { title = d.title, type = d.type, summary = d.summary, links = links })
    if not id then return { error = ref } end
    return { ok = true, case = caseView(src, o, getCase(id)) }
end)

VPO.Net.Callback('cid:open', { permission = 'cid.view', rate = 'cid' }, function(src, o, d)
    local c = getCase(type(d) == 'table' and d.id or nil)
    if not c then return { error = L('cid_not_found') } end
    local out = VPO.Hub.Header(src, o)
    out.ok, out.case = true, caseView(src, o, c)
    out.types, out.statuses, out.personRoles = Cfg.Types, Cfg.Statuses, Cfg.PersonRoles
    out.officers = {}
    for s in pairs(VPO.Duty.All()) do
        local x = VPO.Officers.Get(s)
        if x then out.officers[#out.officers + 1] = { src = s, label = label(x) } end
    end
    return out
end)

--- All edits to a case go through here: { id, op, ... }
VPO.Net.Callback('cid:update', { permission = 'cid.view', rate = 'cid' }, function(src, o, d)
    d = type(d) == 'table' and d or {}
    local c = getCase(d.id)
    if not c then return { error = L('cid_not_found') } end
    local by = label(o)
    local op = d.op

    if op == 'note' then
        local text = VPO.Util.Trim(d.text, 2000)
        if not text then return { error = L('notebook_empty') } end
        entry(c.id, 'log', text, by)

    elseif op == 'actionDone' then
        local e = MySQL.single.await("SELECT * FROM vpo_case_entries WHERE id = ? AND case_id = ? AND kind = 'action'", { tonumber(d.entry), c.id })
        if not e or e.done_at then return { error = L('cid_not_found') } end
        if e.assigned_identifier ~= o.identifier and not canManage(src, o, c) then return { error = L('cid_not_yours') } end
        local result = VPO.Util.Trim(d.result, 500)
        MySQL.update('UPDATE vpo_case_entries SET done_at = ?, done_by = ? WHERE id = ?', { os.time(), by, e.id })
        entry(c.id, 'log', ('Action done: %s%s'):format(e.text, result and (' (' .. result .. ')') or ''), by)

    else
        if not canManage(src, o, c) then return { error = L('cid_not_yours') } end
        if op == 'status' then
            if not VPO.Util.Contains(Cfg.Statuses, d.status) then return { error = L('cid_bad_status') } end
            local closed = (d.status == 'Closed' or d.status:find('^Filed')) and os.time() or nil
            MySQL.update('UPDATE vpo_cases SET status = ?, closed_at = ? WHERE id = ?', { d.status, closed, c.id })
            entry(c.id, 'log', ('Status: %s'):format(d.status), by)
        elseif op == 'summary' then
            MySQL.update('UPDATE vpo_cases SET summary = ? WHERE id = ?', { VPO.Util.Trim(d.text, 2000), c.id })
            entry(c.id, 'log', 'Summary updated', by)
        elseif op == 'link' then
            local ref = VPO.Util.Trim(d.ref, 32)
            if not ref then return { error = L('cid_need_ref') } end
            local links = dec(c.links, {})
            if not VPO.Util.Contains(links, ref) then links[#links + 1] = ref end
            MySQL.update('UPDATE vpo_cases SET links = ? WHERE id = ?', { json.encode(links), c.id })
            entry(c.id, 'log', ('Linked %s'):format(ref), by)
        elseif op == 'unlink' then
            local links, out = dec(c.links, {}), {}
            for _, r in ipairs(links) do if r ~= d.ref then out[#out + 1] = r end end
            MySQL.update('UPDATE vpo_cases SET links = ? WHERE id = ?', { json.encode(out), c.id })
            entry(c.id, 'log', ('Unlinked %s'):format(tostring(d.ref)), by)
        elseif op == 'person' then
            local name = VPO.Util.Trim(d.name, 100)
            if not name or not VPO.Util.Contains(Cfg.PersonRoles, d.role) then return { error = L('cid_need_person') } end
            local people = dec(c.people, {})
            people[#people + 1] = { name = name, role = d.role, details = VPO.Util.Trim(d.details, 300) }
            MySQL.update('UPDATE vpo_cases SET people = ? WHERE id = ?', { json.encode(people), c.id })
            entry(c.id, 'log', ('%s added: %s'):format(d.role, name), by)
        elseif op == 'removePerson' then
            local people, out = dec(c.people, {}), {}
            for i, p in ipairs(people) do if i ~= tonumber(d.index) then out[#out + 1] = p end end
            MySQL.update('UPDATE vpo_cases SET people = ? WHERE id = ?', { json.encode(out), c.id })
            entry(c.id, 'log', 'Person removed', by)
        elseif op == 'action' then
            local text = VPO.Util.Trim(d.text, 300)
            if not text then return { error = L('notebook_empty') } end
            local target = tonumber(d.assign)
            local t = target and VPO.Officers.Get(target) or nil
            entry(c.id, 'action', text, by, { assignedIdentifier = t and t.identifier or nil, assignedName = t and label(t) or nil })
            if t and target ~= src then VPO.Notify(target, L('cid_action_given', c.ref, text), 'inform', 8000) end
        elseif op == 'oic' then
            local target = tonumber(d.target)
            local t = target and VPO.Officers.Get(target)
            if not t then return { error = L('restraint_no_target') } end
            MySQL.update('UPDATE vpo_cases SET oic_identifier = ?, oic_name = ? WHERE id = ?', { t.identifier, label(t), c.id })
            entry(c.id, 'log', ('OIC now %s'):format(label(t)), by)
            if target ~= src then VPO.Notify(target, L('cid_oic_given', c.ref), 'inform', 8000) end
        else
            return { error = L('npc_custody_unknown') }
        end
    end
    VPO.Audit.Log({ action = 'cid.' .. tostring(op), actor = src, targetType = 'case', targetId = c.ref })
    return { ok = true, case = caseView(src, o, getCase(c.id)) }
end)
