-- NPC people at callout scenes: suspects, victims, witnesses, drivers. Each has a saved identity
-- (VPO.NPC), a behaviour and a state. Officers deal with them in the person panel (target the ped):
-- details, PNC, fingerprints, search, breath tests, arrest and hand-over to custody, or let them go.
-- The server decides; the controlling officer's client moves the ped.
VPO.Encounters = {}
local EN = VPO.Encounters
local L = VPO.L
local people = {}  -- [id] = person
local byPed = {}   -- [pedNet] = id
local seq = 0

local function chance(pct) return math.random(1, 100) <= (pct or 0) end
local function ped(src) local p = GetPlayerPed(src); return (p and p ~= 0) and p or nil end
local function entity(net)
    net = tonumber(net)
    local e = net and NetworkGetEntityFromNetworkId(net) or 0
    return (e and e ~= 0 and DoesEntityExist(e)) and e or nil
end
local function dist(a, b) if not a or not b then return math.huge end return #(GetEntityCoords(a) - GetEntityCoords(b)) end

local ROLE = { suspect = 'Suspect', victim = 'Victim', witness = 'Witness', driver = 'Driver', subject = 'Person of concern', keyholder = 'Keyholder' }

local function publish()
    local list = {}
    for net, id in pairs(byPed) do list[tostring(net)] = id end
    GlobalState.vpo_enc_peds = list
end

local function cuffedList(p, on)
    local list = GlobalState.vpo_npc_cuffed or {}
    list[tostring(p.pedNet)] = on or nil
    GlobalState.vpo_npc_cuffed = list
end

--- Instruction for the person's ped, sent to the call's controlling officer.
function EN.Control(p, action, extra)
    local call = VPO.Callouts.Get(p.callId)
    local ctl = call and VPO.Callouts.Controller(call)
    if not ctl then return end
    local msg = { person = p.id, ped = p.pedNet, action = action }
    for k, v in pairs(extra or {}) do msg[k] = v end
    TriggerClientEvent('vinewood_police:client:enc:control', ctl, msg)
end

---------------------------------------------------------------------------
-- Creating people
---------------------------------------------------------------------------
--- def = { role, model, coords = vec4, behaviour = 'compliant'|'flee'|'hostile'|'uncooperative'|'nervous',
---         trigger = nil|'approach' (flee/hostile when an officer gets close), action = initial client action,
---         actionData = {}, statement = text, finds = { labels }, offences = { suggested }, drink, drug, falseDetails }
function EN.Spawn(callId, def)
    local model = GetHashKey(def.model)
    local c = def.coords
    local p = CreatePed(4, model, c.x, c.y, c.z - 1.0, c.w or 0.0, true, true)
    local deadline = GetGameTimer() + 3000
    while not DoesEntityExist(p) and GetGameTimer() < deadline do Wait(20) end
    if not DoesEntityExist(p) then VPO.Log.warn('Callout ped %s failed to spawn', def.model) return nil end
    SetEntityOrphanMode(p, 2)
    seq = seq + 1
    local person = def.person or VPO.NPC.NewPerson()
    if def.address then
        person.address = def.address
        MySQL.update('UPDATE vpo_npc_people SET address = ? WHERE id = ?', { def.address, person.id })
    end
    if def.licence then
        person.licence = def.licence
        MySQL.update('UPDATE vpo_npc_people SET licence = ? WHERE id = ?', { def.licence, person.id })
    end
    local rec = {
        id = seq, callId = callId, role = def.role, roleLabel = ROLE[def.role] or def.role, ped = p, pedNet = NetworkGetNetworkIdFromEntity(p),
        model = model, profile = person, behaviour = def.behaviour or 'compliant', trigger = def.trigger,
        state = 'idle', statement = def.statement, finds = {}, exhibits = {}, tests = {},
        drink = def.drink, drug = def.drug, suggested = def.offences, warned = false, injured = def.injured,
        fake = def.falseDetails and VPO.NPC.MakeIdentity() or nil, weapon = def.weapon, weaponLabel = def.weaponLabel,
    }
    if def.weapon and def.weaponLabel then rec.finds[#rec.finds + 1] = { label = def.weaponLabel, seized = false } end
    for _, label in ipairs(def.finds or {}) do table.insert(rec.finds, 1, { label = label, seized = false }) end
    people[rec.id], byPed[rec.pedNet] = rec, rec.id
    publish()
    EN.Control(rec, def.action or 'idle', def.actionData)
    return rec
end

function EN.Get(id) return people[id] end

--- Removes a person (ped deleted unless keepPed; then it's released to the world).
function EN.Remove(id, keepPed)
    local p = people[id]
    if not p then return end
    people[id] = nil
    byPed[p.pedNet] = nil
    cuffedList(p, false)
    publish()
    if p.ped and DoesEntityExist(p.ped) then
        if keepPed then SetEntityOrphanMode(p.ped, 0) else DeleteEntity(p.ped) end
    end
end

function EN.ForCall(callId)
    local out = {}
    for _, p in pairs(people) do if p.callId == callId then out[#out + 1] = p end end
    table.sort(out, function(a, b) return a.id < b.id end)
    return out
end

--- Short view for the call panel.
function EN.Summary(p)
    return { id = p.id, role = p.roleLabel, name = (p.identified and VPO.NPC.FullName(p.profile)) or (p.given and p.given.name) or nil,
        state = p.state, pedNet = p.pedNet }
end

---------------------------------------------------------------------------
-- Hostile behaviour is gated like vehicle stops
---------------------------------------------------------------------------
local function hostileAllowed(p)
    if not Config.NPC.AllowHostile then return false end
    local e = entity(p.pedNet)
    if not e then return false end
    local c = GetEntityCoords(e)
    for _, z in ipairs(Config.NPC.NoHostileZones or {}) do if #(c - z.coords) <= z.radius then return false end end
    local n = 0
    for _, id in ipairs(GetPlayers()) do
        local pp = ped(tonumber(id))
        if pp and #(GetEntityCoords(pp) - c) <= 60.0 then n = n + 1 end
    end
    return n <= (Config.NPC.HostileMaxPlayersNearby or 6)
end

local function bolt(p, said)
    p.state = 'fleeing'
    EN.Control(p, 'flee')
    return said or L('npc_bolts')
end

local function attack(p)
    if hostileAllowed(p) then
        p.state = 'hostile'
        EN.Control(p, 'hostile', { weapon = p.weapon })
        local call = VPO.Callouts.Get(p.callId)
        if call then VPO.Callouts.Escalate(call, p.weapon and L('enc_armed_attack') or L('enc_attack')) end
        return p.weapon and L('enc_attacks_armed') or L('npc_goes_for_you')
    end
    if p.weapon then return EN.Surrender(p) end
    p.refusals = (p.refusals or 0) + 1
    return L('enc_argues')
end

--- Gives up: drops any weapon, hands up.
function EN.Surrender(p)
    p.state = 'surrendered'
    EN.Control(p, 'surrender')
    return p.weapon and L('enc_drops_weapon') or L('npc_surrendered')
end

--- Is an Armed response officer within range of this ped?
local function arvNear(e, range)
    for src, s in pairs(VPO.Duty.All()) do
        if s.unit == 'arv' then
            local pp = ped(src)
            if pp and dist(pp, e) <= range then return true end
        end
    end
    return false
end

---------------------------------------------------------------------------
-- Watching scenes: approach triggers, catching runners, losing them
---------------------------------------------------------------------------
local function officersNear(e, range)
    local list = {}
    for src in pairs(VPO.Duty.All()) do
        local pp = ped(src)
        if pp and dist(pp, e) <= range then list[#list + 1] = src end
    end
    return list
end

CreateThread(function()
    while true do
        Wait(1000)
        for _, p in pairs(people) do
            local e = entity(p.pedNet)
            if not e then
                if p.state ~= 'arrested' and p.state ~= 'released' then p.state = 'gone' end
            elseif p.state == 'idle' and p.trigger == 'approach' and p.behaviour == 'armed' then
                -- Armed suspects decide when police close in: armed officers make giving up far more likely
                if #officersNear(e, 25.0) > 0 then
                    local A = Config.Callouts.Armed
                    local said
                    if math.random(1, 100) <= (arvNear(e, 30.0) and A.SurrenderToARV or A.SurrenderToOfficers) then
                        said = EN.Surrender(p)
                    elseif math.random(1, 100) <= 50 then
                        said = bolt(p)
                    else
                        said = attack(p)
                    end
                    for _, o in ipairs(officersNear(e, 60.0)) do VPO.Notify(o, ('%s: %s'):format(p.roleLabel, said), p.state == 'surrendered' and 'success' or 'error', 8000) end
                end
            elseif p.state == 'idle' and p.trigger == 'approach' then
                if p.behaviour == 'flee' and #officersNear(e, 14.0) > 0 then
                    bolt(p)
                    for _, o in ipairs(officersNear(e, 40.0)) do VPO.Notify(o, L('enc_running', p.roleLabel), 'error') end
                elseif p.behaviour == 'hostile' and #officersNear(e, 4.0) > 0 then
                    attack(p)
                end
            elseif p.state == 'fleeing' then
                if #officersNear(e, 200.0) == 0 then
                    p.lostFor = (p.lostFor or 0) + 1
                    if p.lostFor >= (Config.NPC.LostSeconds or 40) then
                        p.state = 'gone'
                        EN.Control(p, 'release')
                        local call = VPO.Callouts.Get(p.callId)
                        if call then VPO.Callouts.Note(call, ('%s made off'):format(p.roleLabel)) end
                    end
                else
                    p.lostFor = 0
                end
            end
        end
    end
end)

VPO.Net.On('enc:event', { permission = 'calls.attend', rate = 'calls', silent = true }, function(src, _, id, event)
    local p = people[tonumber(id) or 0]
    if not p or event ~= 'surrendered' then return end
    if p.state ~= 'fleeing' and p.state ~= 'hostile' then return end
    local e = entity(p.pedNet)
    if e and #officersNear(e, 8.0) > 0 then
        p.state = 'surrendered'
        for _, o in ipairs(officersNear(e, 40.0)) do VPO.Notify(o, L('npc_surrendered'), 'success') end
    end
end)

---------------------------------------------------------------------------
-- Person panel
---------------------------------------------------------------------------
local function offencesList()
    return VPO.ArrestOffences()
end

local function view(p)
    local call = VPO.Callouts.Get(p.callId)
    return {
        id = p.id, role = p.role, roleLabel = p.roleLabel, state = p.state, statement = p.statement,
        given = p.given and { name = p.given.name, dob = p.given.dob, address = p.given.address } or nil,
        pnc = p.pnc, fingerprint = p.fingerprint, finds = p.searched and p.finds or nil, tests = p.tests, injured = p.injured,
        suggested = p.suggested, offences = offencesList(), caution = Config.Arrest.Caution,
        call = call and { id = call.id, ref = call.ref, title = call.title } or nil,
        canFingerprint = Config.NPC.FingerprintItem == false or Config.NPC.FingerprintItem == nil,
    }
end

local function near(src, p, range)
    local e = entity(p.pedNet)
    return e and dist(ped(src), e) <= (range or 4.0)
end

local function talkable(p) return p.state == 'idle' or p.state == 'surrendered' or p.state == 'arrested' end

local function personFor(src, d, range)
    local id = tonumber(type(d) == 'table' and d.id or nil)
    if not id and type(d) == 'table' and d.ped then id = byPed[tonumber(d.ped)] end
    local p = id and people[id]
    if not p then return nil, L('enc_gone') end
    if not near(src, p, range or 5.0) then return nil, L('restraint_too_far') end
    local call = VPO.Callouts.Get(p.callId)
    if call then VPO.Callouts.Attend(call, src) end
    return p
end

local function reply(p, said, extra)
    local out = { ok = true, person = view(p), said = said }
    for k, v in pairs(extra or {}) do out[k] = v end
    return out
end

VPO.Net.Callback('enc:open', { permission = 'calls.attend', rate = 'calls' }, function(src, o, d)
    local p, err = personFor(src, d, 6.0)
    if not p then return { error = err } end
    local out = VPO.Hub.Header(src, o)
    out.ok, out.person = true, view(p)
    return out
end)

VPO.Net.Callback('enc:ask', { permission = 'calls.attend', rate = 'calls' }, function(src, _, d)
    local p, err = personFor(src, d)
    if not p then return { error = err } end
    if not talkable(p) then return { error = L('npc_cant_talk') } end
    if (p.behaviour == 'uncooperative' or p.behaviour == 'hostile') and not p.warned and p.state ~= 'arrested' then
        return reply(p, L('npc_refuses_details'))
    end
    local who = p.fake or p.profile
    p.given = { name = VPO.NPC.FullName(who), firstname = who.firstname, lastname = who.lastname, dob = who.dob, address = who.address, false_ = p.fake ~= nil }
    return reply(p, p.behaviour == 'nervous' and L('npc_gives_details_nervous') or L('npc_gives_details'))
end)

VPO.Net.Callback('enc:warn', { permission = 'calls.attend', rate = 'calls' }, function(src, _, d)
    local p, err = personFor(src, d)
    if not p then return { error = err } end
    p.warned = true
    if p.behaviour == 'hostile' and p.state == 'idle' and chance(50) then return reply(p, attack(p)) end
    return reply(p, L('npc_warned'))
end)

VPO.Net.Callback('enc:pnc', { permission = 'calls.attend', rate = 'calls' }, function(src, _, d)
    local p, err = personFor(src, d, 30.0)
    if not p then return { error = err } end
    if not p.given then return { error = L('npc_need_details') } end
    local r = VPO.NPC.FindByDetails(p.given.firstname, p.given.lastname, p.given.dob)
    p.pnc = r and { found = true, name = VPO.NPC.FullName(r), dob = r.dob, address = r.address, licence = r.licence, points = r.points, wanted = r.wanted }
        or { found = false, name = p.given.name, dob = p.given.dob }
    return reply(p)
end)

VPO.Net.Callback('enc:fingerprint', { permission = 'calls.attend', rate = 'calls' }, function(src, _, d)
    local p, err = personFor(src, d)
    if not p then return { error = err } end
    if Config.NPC.FingerprintItem and not VPO.Inventory.Has(src, Config.NPC.FingerprintItem, 1) then return { error = L('npc_need_scanner') } end
    if not talkable(p) then return { error = L('npc_cant_talk') } end
    local r = VPO.NPC.GetPerson(p.profile.id) or p.profile
    if r.prior_record then
        p.identified = true
        p.fingerprint = { match = true, name = VPO.NPC.FullName(r), dob = r.dob, wanted = r.wanted, mismatch = p.given ~= nil and p.given.false_ == true }
    else
        p.fingerprint = { match = false }
    end
    return reply(p)
end)

VPO.Net.Callback('enc:search', { permission = 'calls.attend', rate = 'calls' }, function(src, _, d)
    local p, err = personFor(src, d)
    if not p then return { error = err } end
    if p.state ~= 'surrendered' and p.state ~= 'arrested' and not (p.state == 'idle' and p.warned) then
        -- Searching someone who isn't detained: a suspect with something to hide may run
        if p.role == 'suspect' and (p.behaviour == 'nervous' or p.behaviour == 'flee') and #p.finds > 0 and chance(40) then
            return reply(p, bolt(p))
        end
    end
    p.searched = true
    return reply(p, #p.finds > 0 and L('enc_found_items') or L('enc_found_nothing'))
end)

VPO.Net.Callback('enc:seize', { permission = 'search.seize', rate = 'calls' }, function(src, o, d)
    local p, err = personFor(src, d)
    if not p then return { error = err } end
    local item = p.finds[tonumber(d.index) or 0]
    if not item or not p.searched then return { error = L('equipment_not_found') } end
    if not item.seized then
        local call = VPO.Callouts.Get(p.callId)
        local known = (p.identified and VPO.NPC.FullName(p.profile)) or (p.given and p.given.name) or L('npc_unknown_person')
        local _, ref = VPO.Evidence.Create(o, { description = item.label, fromName = known, linkedRef = (p.arrest and p.arrest.ref) or (call and call.ref) })
        if not ref then return { error = L('qual_failed') } end
        item.seized, item.exhibit = true, ref
        p.exhibits[#p.exhibits + 1] = { ref = ref, label = item.label }
    end
    return reply(p)
end)

VPO.Net.Callback('enc:test', { permission = 'roads.test', rate = 'calls' }, function(src, _, d)
    local p, err = personFor(src, d)
    if not p then return { error = err } end
    if not talkable(p) then return { error = L('npc_cant_talk') } end
    local kind = d.kind == 'drug' and 'drug' or 'breath'
    local limit = Config.Roads.Tests.BreathLimit
    local r
    if p.behaviour == 'uncooperative' and not p.warned then r = { outcome = 'refused' }
    elseif kind == 'breath' then
        local reading = p.drink and math.random(40, 95) or (chance(15) and math.random(4, 20) or 0)
        r = { outcome = reading > limit and 'fail' or 'pass', reading = reading }
    else
        r = p.drug and { outcome = 'fail', substance = Config.Roads.Tests.DrugsTested[math.random(1, #Config.Roads.Tests.DrugsTested)] } or { outcome = 'pass' }
    end
    r.kind, r.limit, r.at = kind, limit, os.time()
    p.tests[#p.tests + 1] = r
    return reply(p)
end)

local function allowedOffences()
    local set = {}
    for _, a in ipairs(offencesList()) do for _, it in ipairs(a.items or {}) do set[('%s, %s'):format(it, a.act)] = true end end
    return set
end

VPO.Net.Callback('enc:arrest', { permission = 'arrest.make', rate = 'arrest' }, function(src, o, d)
    local p, err = personFor(src, d, 4.0)
    if not p then return { error = err } end
    if p.state == 'arrested' then return { error = L('arrest_already') } end
    if p.state ~= 'idle' and p.state ~= 'surrendered' then return { error = L('npc_detain_first') } end
    local allowed, offences = allowedOffences(), {}
    for _, off in ipairs(type(d.offences) == 'table' and d.offences or {}) do
        if allowed[off] and not VPO.Util.Contains(offences, off) then offences[#offences + 1] = off end
    end
    if #offences == 0 then return { error = L('arrest_need_offence') } end
    local grounds = VPO.Util.Trim(d.grounds, 2000)
    if not grounds or #grounds < Config.Arrest.GroundsMinLength then return { error = L('arrest_need_grounds', Config.Arrest.GroundsMinLength) } end
    if d.cautioned ~= true then return { error = L('arrest_need_caution') } end

    -- The moment of arrest is when people run or fight
    if p.state == 'idle' then
        if p.behaviour == 'flee' or (p.behaviour == 'nervous' and chance(25)) then return reply(p, bolt(p)) end
        if p.behaviour == 'hostile' and chance(60) then return reply(p, attack(p)) end
        if p.behaviour == 'armed' then return reply(p, chance(50) and bolt(p) or attack(p)) end
    end

    local call = VPO.Callouts.Get(p.callId)
    local known = (p.identified and VPO.NPC.FullName(p.profile)) or (p.given and p.given.name) or L('npc_unknown_person')
    local id = MySQL.insert.await([[INSERT INTO vpo_arrests (identifier, subject_name, offences, grounds, necessity, cautioned, location,
        officer_identifier, officer_name, created_at) VALUES (?, ?, ?, ?, ?, 1, ?, ?, ?, ?)]],
        { ('npc:%d'):format(p.profile.id), known, json.encode(offences), grounds, json.encode({ 'NPC' }), call and call.location,
          o.identifier, VPO.Officers.Label(o), os.time() })
    if not id then return { error = L('qual_failed') } end
    local ref = ('%s/%s/%05d'):format(Config.Force.short, os.date('%y%m'), id)
    MySQL.update.await('UPDATE vpo_arrests SET ref = ? WHERE id = ?', { ref, id })
    VPO.NPC.Keep(p.profile.id)
    p.arrest = { id = id, ref = ref, offences = offences, by = VPO.Officers.Label(o), at = os.time(), model = p.model, name = known }
    p.state = 'arrested'
    cuffedList(p, true)
    EN.Control(p, 'cuff')
    VPO.Duty.AddStat(src, 'arrests', 1)
    if Config.Standards.PromptOnCuff then VPO.Standards.Prompt(src, 'Handcuffing', known, ref) end
    if call then VPO.Callouts.Note(call, ('%s arrested (%s)'):format(known, ref)) end
    VPO.Audit.Log({ action = 'arrest.make', actor = src, targetType = 'npc', targetId = ('npc:%d'):format(p.profile.id), new = { ref = ref, offences = offences }, reason = grounds })
    return reply(p, L('npc_arrested', ref))
end)

VPO.Net.Callback('enc:handover', { permission = 'arrest.make', rate = 'arrest' }, function(src, _, d)
    local p, err = personFor(src, d, 10.0)
    if not p then return { error = err } end
    if p.state ~= 'arrested' then return { error = L('npc_not_arrested') } end
    local call = VPO.Callouts.Get(p.callId)
    local suite = VPO.CustodyNpc.ReceiveFrom(src, {
        arrest = p.arrest, personId = p.profile.id, sourceRef = call and call.ref or nil,
        evidence = { exhibits = p.exhibits, tests = p.tests, details = p.given, fingerprint = p.fingerprint },
    })
    EN.Control(p, 'handover')
    EN.Remove(p.id, true)
    return { ok = true, suite = suite and suite.label or nil }
end)

VPO.Net.Callback('enc:release', { permission = 'calls.attend', rate = 'calls' }, function(src, _, d)
    local p, err = personFor(src, d, 10.0)
    if not p then return { error = err } end
    if p.state == 'arrested' then return { error = L('custody_use_panel') } end
    p.state = 'released'
    EN.Control(p, 'release')
    EN.Remove(p.id, true)
    return { ok = true }
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= VPO.Resource then return end
    for id in pairs(people) do EN.Remove(id) end
    GlobalState.vpo_enc_peds = {}
end)
