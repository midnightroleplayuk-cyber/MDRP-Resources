-- Generated NPC people and vehicles. Made the first time a vehicle is stopped and kept, so the same
-- plate leads to the same keeper, driver and documents next time. Nothing is generated for NPCs
-- nobody stops, so there's no background cost.
VPO.NPC = {}
local N = VPO.NPC
local C = Config.NPC
local Names = Config.NPCNames

---------------------------------------------------------------------------
-- Random helpers
---------------------------------------------------------------------------
local function chance(pct) return math.random(1, 100) <= (pct or 0) end
local function pick(list) return list[math.random(1, #list)] end

--- Weighted pick from { key = weight }. Keys are sorted first so results don't depend on table order.
function N.Weighted(t)
    local keys, total = {}, 0
    for k, w in pairs(t) do if w > 0 then keys[#keys + 1] = k; total = total + w end end
    table.sort(keys)
    local r = math.random() * total
    for _, k in ipairs(keys) do
        r = r - t[k]
        if r <= 0 then return k end
    end
    return keys[#keys]
end

local function dob(minAge, maxAge)
    local age = math.random(minAge, maxAge)
    local t = os.time() - math.floor(age * 365.25 * 86400) - math.random(0, 364) * 86400
    return os.date('%d/%m/%Y', t)
end

local function address()
    return ('%d %s, %s'):format(math.random(1, 180), pick(Names.streets), pick(Names.areas))
end

--- A person's details (not saved). sex 'M'/'F'; surname optional.
function N.MakeIdentity(surname)
    local sex = chance(50) and 'M' or 'F'
    return {
        firstname = pick(sex == 'M' and Names.male or Names.female),
        lastname = surname or pick(Names.surnames),
        dob = dob(17, 78), sex = sex, address = address(),
    }
end

local function savePerson(p)
    local t = os.time()
    p.id = MySQL.insert.await([[INSERT INTO vpo_npc_people (firstname, lastname, dob, sex, address, licence, points, wanted, prior_record, created_at, last_seen)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)]],
        { p.firstname, p.lastname, p.dob, p.sex, p.address, p.licence, p.points or 0, p.wanted, p.prior_record and 1 or 0, t, t })
    return p
end

local function newPerson(surname)
    local p = N.MakeIdentity(surname)
    p.licence = N.Weighted(C.Licence)
    p.points = (p.licence == 'valid' and chance(25)) and pick({ 3, 3, 3, 6, 6, 9 }) or 0
    p.wanted = chance(C.WantedChance) and pick(Names.warrants) or nil
    p.prior_record = p.wanted ~= nil or p.licence == 'disqualified' or chance(C.PriorRecordChance)
    return savePerson(p)
end

--- A new saved NPC person (callouts use this for the people at a scene).
function N.NewPerson(surname) return newPerson(surname) end

function N.GetPerson(id)
    if not id then return nil end
    local p = MySQL.single.await('SELECT * FROM vpo_npc_people WHERE id = ?', { id })
    if p then p.prior_record = p.prior_record == 1 or p.prior_record == true end
    return p
end

function N.FullName(p) return p and ('%s %s'):format(p.firstname, p.lastname) or nil end

---------------------------------------------------------------------------
-- Vehicles
---------------------------------------------------------------------------
--- Record for an NPC vehicle, creating it the first time. Returns { vehicle, driver, keeper }.
function N.ForVehicle(plate, model)
    local t = os.time()
    local v = MySQL.single.await('SELECT * FROM vpo_npc_vehicles WHERE plate = ?', { plate })
    if v then
        MySQL.update('UPDATE vpo_npc_vehicles SET last_seen = ? WHERE plate = ?', { t, plate })
        local driver = N.GetPerson(v.driver_id)
        if not driver then
            driver = newPerson()
            MySQL.update('UPDATE vpo_npc_vehicles SET driver_id = ? WHERE plate = ?', { driver.id, plate })
            v.driver_id = driver.id
        end
        MySQL.update('UPDATE vpo_npc_people SET last_seen = ? WHERE id IN (?, ?)', { t, v.driver_id, v.keeper_id or 0 })
        return { vehicle = v, driver = driver, keeper = v.keeper_id and N.GetPerson(v.keeper_id) or nil }
    end

    local driver = newPerson()
    local kind = N.Weighted(C.Keeper)
    local keeper, keeperName
    if kind == 'driver' then keeper = driver
    elseif kind == 'family' then keeper = newPerson(driver.lastname)
    elseif kind == 'company' then keeperName = pick(Names.companies)
    else keeper = newPerson() end -- recentSale, stolen

    v = {
        plate = plate, model = tostring(model or ''), keeper_type = kind,
        keeper_id = keeper and keeper.id or nil, keeper_name = keeperName or N.FullName(keeper), driver_id = driver.id,
        insurance = N.Weighted(C.Insurance), mot = N.Weighted(C.MOT), tax = N.Weighted(C.Tax),
        stolen = kind == 'stolen' and 1 or 0, defect = chance(C.DefectChance) and pick(Names.defects) or nil,
    }
    -- A stolen car's policy belongs to its owner, never the thief
    if kind == 'stolen' and v.insurance == 'insured' then v.insurance = 'notCovered' end
    MySQL.insert.await([[INSERT INTO vpo_npc_vehicles (plate, model, keeper_id, keeper_type, keeper_name, driver_id, insurance, mot, tax, stolen, defect, created_at, last_seen)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)]],
        { v.plate, v.model, v.keeper_id, v.keeper_type, v.keeper_name, v.driver_id, v.insurance, v.mot, v.tax, v.stolen, v.defect, t, t })
    return { vehicle = v, driver = driver, keeper = keeper }
end

--- A vehicle reported stolen (callouts): the keeper is the victim, the driver is the thief.
function N.CreateStolen(plate, model)
    local thief = newPerson()
    if not thief.prior_record then
        thief.prior_record = chance(70)
        MySQL.update('UPDATE vpo_npc_people SET prior_record = ? WHERE id = ?', { thief.prior_record and 1 or 0, thief.id })
    end
    local keeper = newPerson()
    local t = os.time()
    MySQL.insert.await([[INSERT INTO vpo_npc_vehicles (plate, model, keeper_id, keeper_type, keeper_name, driver_id, insurance, mot, tax, stolen, defect, keep, created_at, last_seen)
        VALUES (?, ?, ?, 'stolen', ?, ?, 'notCovered', 'valid', 'taxed', 1, NULL, 1, ?, ?)
        ON DUPLICATE KEY UPDATE keeper_id = VALUES(keeper_id), keeper_type = 'stolen', keeper_name = VALUES(keeper_name), driver_id = VALUES(driver_id),
        insurance = 'notCovered', stolen = 1, keep = 1, last_seen = VALUES(last_seen)]],
        { plate, tostring(model or ''), keeper.id, N.FullName(keeper), thief.id, t, t })
    return { keeper = keeper, driver = thief }
end

--- UK-style registration, e.g. LS21 KVN
function N.Plate()
    local L = 'ABCDEFGHJKLMNPRSTUVWXYZ'
    local function c() local i = math.random(1, #L); return L:sub(i, i) end
    return ('%s%s%02d %s%s%s'):format(c(), c(), math.random(10, 26), c(), c(), c())
end

--- Keep a person / vehicle forever (arrested, wanted, failed to stop).
function N.Keep(personId, plate)
    if personId then MySQL.update('UPDATE vpo_npc_people SET keep = 1 WHERE id = ?', { personId }) end
    if plate then MySQL.update('UPDATE vpo_npc_vehicles SET keep = 1 WHERE plate = ?', { plate }) end
end

--- PNC check on details given: exact name and date of birth.
function N.FindByDetails(first, last, dateOfBirth)
    return MySQL.single.await('SELECT * FROM vpo_npc_people WHERE LOWER(firstname) = LOWER(?) AND LOWER(lastname) = LOWER(?) AND dob = ? LIMIT 1',
        { first or '', last or '', dateOfBirth or '' })
end

---------------------------------------------------------------------------
-- Clean-up of records nobody has met for a while
---------------------------------------------------------------------------
AddEventHandler(VPO.Events.ready, function()
    local cutoff = os.time() - (C.ForgetAfterDays or 7) * 86400
    local v = MySQL.update.await('DELETE FROM vpo_npc_vehicles WHERE keep = 0 AND last_seen < ?', { cutoff }) or 0
    local p = MySQL.update.await([[DELETE FROM vpo_npc_people WHERE keep = 0 AND wanted IS NULL AND last_seen < ?
        AND id NOT IN (SELECT keeper_id FROM vpo_npc_vehicles WHERE keeper_id IS NOT NULL)
        AND id NOT IN (SELECT driver_id FROM vpo_npc_vehicles WHERE driver_id IS NOT NULL)]], { cutoff }) or 0
    if v + p > 0 then VPO.Log.info('Forgot %d NPC vehicles and %d NPC people not seen for %d days', v, p, C.ForgetAfterDays or 7) end
end)
