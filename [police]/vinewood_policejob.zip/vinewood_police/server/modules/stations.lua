-- Station lookups by position (server-side, from the player's real ped position).
VPO.Stations = {}

local function pos(src)
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return nil end
    return GetEntityCoords(ped)
end

--- Station whose sign-on point the player is standing at, or nil.
function VPO.Stations.AtSignOn(src)
    local p = pos(src); if not p then return nil end
    for _, st in ipairs(Config.Stations or {}) do
        if st.signOn and #(p - st.signOn.coords) <= (Config.Duty.PointRadius or 3.0) then return st end
    end
    return nil
end

--- Station whose locker the player is standing at, or nil.
function VPO.Stations.AtLocker(src)
    local p = pos(src); if not p then return nil end
    for _, st in ipairs(Config.Stations or {}) do
        for _, l in ipairs(st.lockers or {}) do
            if #(p - l.coords) <= (Config.LockerRadius or 3.0) then return st end
        end
    end
    return nil
end

--- Station whose armoury the player is standing at, or nil.
function VPO.Stations.AtArmoury(src)
    local p = pos(src); if not p then return nil end
    for _, st in ipairs(Config.Stations or {}) do
        for _, a in ipairs(st.armouries or {}) do
            if #(p - a.coords) <= (Config.LockerRadius or 3.0) then return st end
        end
    end
    return nil
end

--- Station whose changing room the player is standing in, or nil.
function VPO.Stations.AtChangingRoom(src)
    local p = pos(src); if not p then return nil end
    for _, st in ipairs(Config.Stations or {}) do
        for _, a in ipairs(st.changingRooms or {}) do
            if #(p - a.coords) <= (Config.LockerRadius or 3.0) + 1.0 then return st end
        end
    end
    return nil
end

function VPO.Stations.Get(id)
    for _, st in ipairs(Config.Stations or {}) do if st.id == id then return st end end
    return nil
end
