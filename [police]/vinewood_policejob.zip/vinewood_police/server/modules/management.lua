-- Management (boss menu): hire, promote and demote, suspend, dismiss and set collar numbers.
-- Rank limits apply to everything: nobody acts on someone of their own rank or above, and nobody
-- promotes anyone to their own rank or above.
VPO.Management = {}
local Cfg = Config.Management
local L = VPO.L

local function label(o) return VPO.Officers.Label(o) end

--- Everyone in every police job, online or not, with rank and officer record.
local function staff()
    local out = {}
    for job in pairs(Config.Jobs) do
        for _, m in ipairs(VPO.Bridge.JobMembers(job)) do
            local rank = VPO.Ranks.FromJob(job, m.grade)
            local rec = MySQL.single.await('SELECT collar_number, callsign, suspended_at, suspended_reason, suspended_by FROM vpo_officers WHERE identifier = ?', { m.identifier }) or {}
            local src = VPO.Bridge.GetSource(m.identifier)
            out[#out + 1] = {
                identifier = m.identifier, name = m.name or VPO.Bridge.GetNameByIdentifier(m.identifier) or m.identifier, job = job, grade = m.grade,
                rank = rank and rank.id, rankLabel = rank and rank.label or ('Grade ' .. m.grade), level = rank and rank.level or 0,
                collar = rec.collar_number, callsign = rec.callsign, online = src ~= nil, onDuty = src ~= nil and VPO.IsOnDuty(src) == true,
                suspended = rec.suspended_at ~= nil, suspendedReason = rec.suspended_reason, suspendedBy = rec.suspended_by,
            }
        end
    end
    table.sort(out, function(a, b) if a.level ~= b.level then return a.level > b.level end return (a.name or '') < (b.name or '') end)
    return out
end

local function find(identifier)
    for _, m in ipairs(staff()) do if m.identifier == identifier then return m end end
    return nil
end

--- The manager may act on this member at all?
local function outranks(o, m)
    if not m then return false, L('manage_not_found') end
    if m.identifier == o.identifier then return false, L('manage_not_self') end
    if m.level >= o.rank.level then return false, L('manage_rank_limit') end
    return true
end

VPO.Net.Callback('manage:panel', { permission = 'manage.view', rate = 'manage' }, function(src, o)
    local out = VPO.Hub.Header(src, o)
    out.ok = true
    out.staff = staff()
    out.myLevel = o.rank.level
    out.ranks = {}
    for _, r in ipairs(Config.Ranks) do out.ranks[#out.ranks + 1] = { id = r.id, label = r.label, level = r.level } end
    -- People close by who aren't police (for hiring)
    out.nearby = {}
    local me = GetEntityCoords(GetPlayerPed(src))
    for _, id in ipairs(GetPlayers()) do
        local p = tonumber(id)
        if p ~= src then
            local job = VPO.Bridge.GetJob(p)
            if not (job and Config.Jobs[job.name]) and #(GetEntityCoords(GetPlayerPed(p)) - me) <= Cfg.HireDistance then
                out.nearby[#out.nearby + 1] = { src = p, name = VPO.Bridge.GetName(p) or GetPlayerName(p) }
            end
        end
    end
    out.can = {
        hire = VPO.Permissions.Check(src, 'manage.hire') == true,
        promote = VPO.Permissions.Check(src, 'manage.promote') == true,
        discipline = VPO.Permissions.Check(src, 'manage.discipline') == true,
        fire = VPO.Permissions.Check(src, 'manage.fire') == true,
    }
    out.jobs = {}
    for job, j in pairs(Config.Jobs) do out.jobs[#out.jobs + 1] = { id = job, label = j.label or job } end
    return out
end)

VPO.Net.Callback('manage:hire', { permission = 'manage.hire', rate = 'manage' }, function(src, o, d)
    d = type(d) == 'table' and d or {}
    local target = tonumber(d.target)
    if not target or not GetPlayerName(target) then return { error = L('restraint_no_target') } end
    if #(GetEntityCoords(GetPlayerPed(src)) - GetEntityCoords(GetPlayerPed(target))) > Cfg.HireDistance + 1.0 then return { error = L('restraint_too_far') } end
    local current = VPO.Bridge.GetJob(target)
    if current and Config.Jobs[current.name] then return { error = L('manage_already_police') } end
    local job = Config.Jobs[d.job] and d.job or next(Config.Jobs)
    local grade = VPO.Ranks.GradeFor(job, Cfg.HireRank) or 0
    local identifier = VPO.Bridge.GetIdentifier(target)
    if not identifier or not VPO.Bridge.SetJob(identifier, job, grade) then return { error = L('manage_failed') } end
    SetTimeout(1000, function() VPO.Officers.Ensure(target) end)
    VPO.Audit.Log({ action = 'manage.hire', actor = src, targetType = 'officer', targetId = identifier, new = { job = job, grade = grade } })
    VPO.Notify(target, L('manage_hired_target', Config.Force.name, VPO.Ranks.Get(Cfg.HireRank).label), 'success', 10000)
    return { ok = true, message = L('manage_hired', VPO.Bridge.GetName(target) or '?') }
end)

VPO.Net.Callback('manage:rank', { permission = 'manage.promote', rate = 'manage' }, function(src, o, d)
    d = type(d) == 'table' and d or {}
    local m = find(d.identifier)
    local ok, err = outranks(o, m)
    if not ok then return { error = err } end
    local rank = VPO.Ranks.Get(d.rank)
    if not rank then return { error = L('manage_bad_rank') } end
    if rank.level >= o.rank.level then return { error = L('manage_rank_limit') } end
    local grade = VPO.Ranks.GradeFor(m.job, rank.id)
    if not grade then return { error = L('manage_rank_not_in_job', rank.label) } end
    if grade == m.grade then return { error = L('manage_same_rank') } end
    if not VPO.Bridge.SetJob(m.identifier, m.job, grade, m.job) then return { error = L('manage_failed') } end
    local up = rank.level > m.level
    VPO.Audit.Log({ action = up and 'manage.promote' or 'manage.demote', actor = src, targetType = 'officer', targetId = m.identifier,
        previous = { rank = m.rank, grade = m.grade }, new = { rank = rank.id, grade = grade }, reason = VPO.Util.Trim(d.reason, 255) })
    local tsrc = VPO.Bridge.GetSource(m.identifier)
    if tsrc then VPO.Notify(tsrc, L(up and 'manage_promoted_target' or 'manage_demoted_target', rank.label), up and 'success' or 'inform', 10000) end
    return { ok = true, message = L(up and 'manage_promoted' or 'manage_demoted', m.name, rank.label) }
end)

VPO.Net.Callback('manage:suspend', { permission = 'manage.discipline', rate = 'manage' }, function(src, o, d)
    d = type(d) == 'table' and d or {}
    local m = find(d.identifier)
    local ok, err = outranks(o, m)
    if not ok then return { error = err } end
    local by = label(o)
    if d.lift then
        MySQL.update.await('UPDATE vpo_officers SET suspended_at = NULL, suspended_reason = NULL, suspended_by = NULL WHERE identifier = ?', { m.identifier })
        VPO.Audit.Log({ action = 'manage.unsuspend', actor = src, targetType = 'officer', targetId = m.identifier })
        local tsrc = VPO.Bridge.GetSource(m.identifier)
        if tsrc then VPO.Notify(tsrc, L('manage_unsuspended_target'), 'success', 10000) end
        return { ok = true, message = L('manage_unsuspended', m.name) }
    end
    local reason = VPO.Util.Trim(d.reason, 255)
    if not reason or #reason < 5 then return { error = L('manage_need_reason') } end
    MySQL.insert.await([[INSERT INTO vpo_officers (identifier, display_name, suspended_at, suspended_reason, suspended_by, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE suspended_at = VALUES(suspended_at), suspended_reason = VALUES(suspended_reason),
        suspended_by = VALUES(suspended_by)]], { m.identifier, m.name, os.time(), reason, by, os.time(), os.time() })
    VPO.Officers.Forget(m.identifier)
    local tsrc = VPO.Bridge.GetSource(m.identifier)
    if tsrc then
        if VPO.Duty.Get(tsrc) then VPO.Duty.End(tsrc, 'suspended') end
        VPO.Notify(tsrc, L('manage_suspended_target', reason), 'error', 15000)
    end
    VPO.Audit.Log({ action = 'manage.suspend', actor = src, targetType = 'officer', targetId = m.identifier, reason = reason })
    return { ok = true, message = L('manage_suspended', m.name) }
end)

VPO.Net.Callback('manage:fire', { permission = 'manage.fire', rate = 'manage' }, function(src, o, d)
    d = type(d) == 'table' and d or {}
    local m = find(d.identifier)
    local ok, err = outranks(o, m)
    if not ok then return { error = err } end
    local reason = VPO.Util.Trim(d.reason, 255)
    if not reason or #reason < 5 then return { error = L('manage_need_reason') } end
    local tsrc = VPO.Bridge.GetSource(m.identifier)
    if tsrc and VPO.Duty.Get(tsrc) then VPO.Duty.End(tsrc, 'dismissed') end
    if not VPO.Bridge.SetJob(m.identifier, Cfg.UnemployedJob, 0, m.job) then return { error = L('manage_failed') } end
    VPO.Audit.Log({ action = 'manage.dismiss', actor = src, targetType = 'officer', targetId = m.identifier,
        previous = { job = m.job, rank = m.rank }, reason = reason })
    if tsrc then VPO.Notify(tsrc, L('manage_dismissed_target', Config.Force.name, reason), 'error', 15000) end
    return { ok = true, message = L('manage_dismissed', m.name) }
end)

VPO.Net.Callback('manage:collar', { permission = 'manage.promote', rate = 'manage' }, function(src, o, d)
    d = type(d) == 'table' and d or {}
    local m = find(d.identifier)
    if not m then return { error = L('manage_not_found') } end
    if m.identifier ~= o.identifier and m.level >= o.rank.level then return { error = L('manage_rank_limit') } end
    local collar = tostring(d.collar or '')
    if not collar:match('^%d+$') or #collar > Config.CollarMaxDigits then return { error = L('collar_invalid', Config.CollarMaxDigits) } end
    local good, prev = VPO.Officers.SetCollar(m.identifier, collar)
    if not good then return { error = L('collar_taken', collar) } end
    VPO.Audit.Log({ action = 'officer.collar', actor = src, targetType = 'officer', targetId = m.identifier, previous = prev, new = collar })
    return { ok = true, message = L('collar_set', m.name, collar) }
end)

--- Suspended officers can't sign on.
function VPO.Management.Suspended(identifier)
    local r = MySQL.single.await('SELECT suspended_at, suspended_reason FROM vpo_officers WHERE identifier = ?', { identifier })
    return r and r.suspended_at ~= nil and (r.suspended_reason or '') or nil
end

---------------------------------------------------------------------------
-- Qualifications from the management panel. The usual sign-off rules apply (rank per qualification,
-- prerequisites, no signing off your own, granterNeeds); admins can grant anything as in /qualgrant.
---------------------------------------------------------------------------
local function qualActor(src, perm)
    local ok, why, extra = VPO.Permissions.Check(src, perm)
    if ok then return { source = 'player', src = src } end
    if VPO.Permissions.IsAdmin(src) and Config.AllowAdminQualifications then
        return { source = 'admin', src = src, identifier = VPO.Bridge.GetIdentifier(src), name = ('%s (admin)'):format(GetPlayerName(src)) }
    end
    return nil, VPO.Permissions.Message(why, extra)
end

VPO.Net.Callback('manage:quals', { permission = 'manage.view', rate = 'manage' }, function(src, o, d)
    local m = find(type(d) == 'table' and d.identifier or nil)
    if not m then return { error = L('manage_not_found') } end
    local defs = {}
    for _, q in ipairs(Config.Qualifications) do
        defs[#defs + 1] = { id = q.id, label = q.label, validDays = q.validDays, grantRank = q.grantRank and VPO.Ranks.Get(q.grantRank).label or nil }
    end
    return { ok = true, held = VPO.Qualifications.List(m.identifier), defs = defs,
        canGrant = qualActor(src, 'qual.grant') ~= nil, canRevoke = qualActor(src, 'qual.revoke') ~= nil }
end)

VPO.Net.Callback('manage:qualGrant', { permission = 'manage.view', rate = 'manage' }, function(src, o, d)
    d = type(d) == 'table' and d or {}
    local m = find(d.identifier)
    if not m then return { error = L('manage_not_found') } end
    local actor, err = qualActor(src, 'qual.grant')
    if not actor then return { error = err } end
    local days = tonumber(d.days)
    local ok, msg = VPO.Qualifications.Grant(actor, m.identifier, d.qual, days and days > 0 and days or nil, VPO.Util.Trim(d.notes, 255))
    if not ok then return { error = msg } end
    return { ok = true, message = L('qual_granted', VPO.Qualifications.Def(d.qual).label, m.name), held = VPO.Qualifications.List(m.identifier) }
end)

VPO.Net.Callback('manage:qualRevoke', { permission = 'manage.view', rate = 'manage' }, function(src, o, d)
    d = type(d) == 'table' and d or {}
    local m = find(d.identifier)
    if not m then return { error = L('manage_not_found') } end
    local actor, err = qualActor(src, 'qual.revoke')
    if not actor then return { error = err } end
    local ok, msg = VPO.Qualifications.Revoke(actor, m.identifier, d.qual, d.reason)
    if not ok then return { error = msg } end
    return { ok = true, message = L('qual_revoked', VPO.Qualifications.Def(d.qual).label, m.name), held = VPO.Qualifications.List(m.identifier) }
end)
