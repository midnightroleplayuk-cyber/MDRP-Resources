-- NPC traffic stops. The server decides what the NPC does (from its record and a behaviour picked when
-- it's stopped); the officer's client moves the ped. Each decision point is where real stops go
-- wrong: when the lights go on, when they're asked for details, and when they're asked to step out.
VPO.NpcStops = {}
local NS = VPO.NpcStops
local C = Config.NPC
local Roads = VPO.Roads
local L = VPO.L
local cooldown = {} -- [officer] = os.time() of their last NPC stop

local function chance(pct) return math.random(1, 100) <= (pct or 0) end

local function entity(net)
    net = tonumber(net)
    local e = net and NetworkGetEntityFromNetworkId(net) or 0
    return (e and e ~= 0 and DoesEntityExist(e)) and e or nil
end

local function ped(src)
    local p = GetPlayerPed(src)
    return (p and p ~= 0) and p or nil
end

local function dist(a, b)
    if not a or not b then return math.huge end
    return #(GetEntityCoords(a) - GetEntityCoords(b))
end

--- Send the controlling officer's client an instruction for the NPC.
local function control(s, action, extra)
    local n = s.npc
    if not n.controller or not GetPlayerName(n.controller) then
        -- Hand control to another officer on the stop
        n.controller = nil
        for src in pairs(s.officers) do if GetPlayerName(src) then n.controller = src; break end end
        if not n.controller then return end
    end
    local msg = { stop = s.id, veh = s.net, ped = n.pedNet, action = action }
    if extra then for k, v in pairs(extra) do msg[k] = v end end
    TriggerClientEvent('vinewood_police:client:npc:control', n.controller, msg)
end

local function setState(s, st)
    s.npc.state = st
    local peds = GlobalState.vpo_npc_peds or {}
    if st == 'ended' then peds[tostring(s.npc.pedNet)] = nil else peds[tostring(s.npc.pedNet)] = s.net end
    GlobalState.vpo_npc_peds = peds
end

local function setCuffed(s, on)
    local list = GlobalState.vpo_npc_cuffed or {}
    list[tostring(s.npc.pedNet)] = on or nil
    GlobalState.vpo_npc_cuffed = list
end

--- Is the officer close to the NPC driver (for stops where the driver has left the car)?
function NS.NearPed(src, s)
    local p = entity(s.npc and s.npc.pedNet)
    return p ~= nil and dist(ped(src), p) <= Config.Roads.PanelDistance + 4.0
end

---------------------------------------------------------------------------
-- Hostile behaviour is only allowed away from busy places
---------------------------------------------------------------------------
local function hostileAllowed(s)
    if not C.AllowHostile then return false end
    local p = entity(s.npc.pedNet) or entity(s.net)
    if not p then return false end
    local c = GetEntityCoords(p)
    for _, z in ipairs(C.NoHostileZones or {}) do
        if #(c - z.coords) <= z.radius then return false end
    end
    local nearby = 0
    for _, id in ipairs(GetPlayers()) do
        local pp = ped(tonumber(id))
        if pp and #(GetEntityCoords(pp) - c) <= 60.0 then nearby = nearby + 1 end
    end
    return nearby <= (C.HostileMaxPlayersNearby or 6)
end

---------------------------------------------------------------------------
-- Picking behaviour
---------------------------------------------------------------------------
local function pickBehaviour(profile, enc)
    local w = VPO.Util.Copy(C.Behaviour.weights)
    local function add(mods) for k, v in pairs(mods or {}) do w[k] = (w[k] or 0) + v end end
    local m = C.Behaviour.modifiers or {}
    if profile.driver.wanted then add(m.wanted) end
    if profile.vehicle.stolen == 1 or profile.vehicle.stolen == true then add(m.stolen) end
    if enc.drink then add(m.drink) end
    if profile.driver.licence == 'disqualified' then add(m.disqualified) end
    return VPO.NPC.Weighted(w)
end

local function falseDetailsChance(driver)
    local f = C.FalseDetails
    if driver.wanted then return f.wanted end
    if driver.licence == 'disqualified' then return f.disqualified end
    if driver.licence == 'none' or driver.licence == 'expired' then return f.noLicence end
    return f.base
end

---------------------------------------------------------------------------
-- Start
---------------------------------------------------------------------------
function NS.Begin(src, o, veh, net, location)
    if not C.Enabled then return { error = L('npc_disabled') } end
    local active, mine = 0, 0
    for _, st in pairs(Roads.All()) do
        if st.npc then
            active = active + 1
            if st.officer == src then mine = mine + 1 end
        end
    end
    if active >= C.MaxActive then return { error = L('npc_busy') } end
    if mine >= C.PerOfficer then return { error = L('npc_one_at_a_time') } end
    if cooldown[src] and os.time() - cooldown[src] < C.Cooldown then return { error = L('rate_limited') } end

    local driverPed = GetPedInVehicleSeat(veh, -1)
    if not driverPed or driverPed == 0 then return { error = L('roads_no_driver') } end
    local pedNet = NetworkGetNetworkIdFromEntity(driverPed)
    local plate = (GetVehicleNumberPlateText(veh) or ''):upper():gsub('^%s+', ''):gsub('%s+$', '')

    local profile = VPO.NPC.ForVehicle(plate, GetEntityModel(veh))
    local enc = { drink = chance(C.DrinkChance), drug = chance(C.DrugChance) }
    enc.falseDetails = chance(falseDetailsChance(profile.driver))
    enc.fake = enc.falseDetails and VPO.NPC.MakeIdentity() or nil
    enc.behaviour = pickBehaviour(profile, enc)

    local s = Roads.NewStop(src, o, veh, net, nil, location)
    if not s then return { error = L('qual_failed') } end
    cooldown[src] = os.time()
    s.npc = {
        profile = profile, enc = enc, pedNet = pedNet, controller = src,
        refusals = 0, warned = false, identified = false, lostFor = 0, lastGiveUpRoll = os.time(),
    }
    s.driverName = nil
    MySQL.update('UPDATE vpo_traffic_stops SET npc = 1 WHERE id = ?', { s.id })

    if enc.behaviour == 'flee_vehicle' then
        setState(s, 'fleeing_vehicle')
        control(s, 'flee_vehicle')
    else
        setState(s, 'stopping')
        control(s, 'pull_over')
    end
    return { ok = true, ref = s.ref, plate = s.plate, npc = true }
end

---------------------------------------------------------------------------
-- What the panel shows
---------------------------------------------------------------------------
local STATE_TEXT = {
    stopping = 'Pulling over', stopped = 'In the vehicle', out = 'Out of the vehicle', fleeing_vehicle = 'Failing to stop',
    fleeing_foot = 'Running off', hostile = 'Violent', surrendered = 'Detained', arrested = 'Under arrest', ended = 'Gone',
}

function NS.VehicleView(s)
    local v, keeper = s.npc.profile.vehicle, s.npc.profile.keeper
    local insurance = v.insurance == 'notCovered' and 'insured' or v.insurance
    local rows = Roads.StatusRows({ status = insurance }, { status = v.mot }, { status = v.tax })
    local out = { plate = s.plate, registered = true, source = 'npc', flags = {}, markers = {} }
    for k, val in pairs(rows) do out[k] = val end
    out.keeper = { name = v.keeper_name or VPO.NPC.FullName(keeper) or 'Unknown' }
    if keeper then out.keeper.licence = keeper.licence; out.keeper.points = keeper.points; out.keeper.wanted = keeper.wanted ~= nil end
    if v.keeper_type == 'company' then out.keeper.note = 'Company vehicle' end
    if v.keeper_type == 'recentSale' then out.flags[#out.flags + 1] = { label = 'Keeper change notified recently', level = 'amber' } end
    if v.stolen == 1 or v.stolen == true then out.flags[#out.flags + 1] = { label = 'REPORTED STOLEN', level = 'red' } end
    return out
end

function NS.PanelData(s)
    local n = s.npc
    return {
        state = n.state, stateText = STATE_TEXT[n.state] or n.state,
        given = n.given, pnc = n.pnc, fingerprint = n.fingerprint,
        defect = n.profile.vehicle.defect,
        offences = (function()
            return VPO.ArrestOffences()
        end)(),
        caution = Config.Arrest.Caution,
        canFingerprint = C.FingerprintItem == false or C.FingerprintItem == nil,
    }
end

local function panel(s) return { ok = true, npc = NS.PanelData(s) } end

local function npcStop(src, d)
    local s, err = Roads.Own(src, d)
    if not s then return nil, err end
    if not s.npc then return nil, L('npc_not_npc') end
    if s.npc.state == 'ended' then return nil, L('roads_no_stop') end
    return s
end

local function canTalk(s)
    local st = s.npc.state
    return st == 'stopped' or st == 'out' or st == 'surrendered' or st == 'arrested'
end

---------------------------------------------------------------------------
-- Details
---------------------------------------------------------------------------
VPO.Net.Callback('roads:npcAsk', { permission = 'roads.stop', rate = 'roads' }, function(src, _, d)
    local s, err = npcStop(src, d)
    if not s then return { error = err } end
    local n = s.npc
    if not canTalk(s) then return { error = L('npc_cant_talk') } end
    local b = n.enc.behaviour
    if (b == 'uncooperative' or b == 'aggressive') and not n.warned and n.state ~= 'arrested' then
        n.refusals = n.refusals + 1
        return { ok = true, said = L('npc_refuses_details'), npc = NS.PanelData(s) }
    end
    local who = n.enc.fake or n.profile.driver
    n.given = { name = VPO.NPC.FullName(who), firstname = who.firstname, lastname = who.lastname, dob = who.dob, address = who.address, false_ = n.enc.fake ~= nil }
    s.driverName = n.given.name
    local said = b == 'nervous' and L('npc_gives_details_nervous') or L('npc_gives_details')
    local p = panel(s); p.said = said
    p.npc.given = { name = n.given.name, dob = n.given.dob, address = n.given.address }
    return p
end)

VPO.Net.Callback('roads:npcWarn', { permission = 'roads.stop', rate = 'roads' }, function(src, _, d)
    local s, err = npcStop(src, d)
    if not s then return { error = err } end
    local n = s.npc
    n.warned = true
    if n.enc.behaviour == 'aggressive' and n.state == 'out' and hostileAllowed(s) and chance(50) then
        setState(s, 'hostile')
        control(s, 'hostile')
        local p = panel(s); p.said = L('npc_goes_for_you')
        return p
    end
    local p = panel(s); p.said = L('npc_warned')
    return p
end)

VPO.Net.Callback('roads:npcPnc', { permission = 'roads.stop', rate = 'roads' }, function(src, _, d)
    local s, err = npcStop(src, d)
    if not s then return { error = err } end
    local n = s.npc
    if not n.given then return { error = L('npc_need_details') } end
    local p = VPO.NPC.FindByDetails(n.given.firstname, n.given.lastname, n.given.dob)
    if not p then
        n.pnc = { found = false, name = n.given.name, dob = n.given.dob }
    else
        local v = n.profile.vehicle
        local insured
        if v.insurance == 'insured' then insured = (v.keeper_type ~= 'stolen') and (p.id == v.driver_id)
        else insured = false end
        n.pnc = {
            found = true, name = VPO.NPC.FullName(p), dob = p.dob, address = p.address, licence = p.licence,
            points = p.points, wanted = p.wanted, insured = insured,
        }
    end
    s.checks.driver = { at = os.time(), pnc = n.pnc.found, wanted = n.pnc.wanted ~= nil }
    return panel(s)
end)

VPO.Net.Callback('roads:npcFingerprint', { permission = 'roads.stop', rate = 'roads' }, function(src, _, d)
    local s, err = npcStop(src, d)
    if not s then return { error = err } end
    local n = s.npc
    if C.FingerprintItem and not VPO.Inventory.Has(src, C.FingerprintItem, 1) then return { error = L('npc_need_scanner') } end
    if n.state == 'fleeing_foot' or n.state == 'fleeing_vehicle' or n.state == 'hostile' then return { error = L('npc_cant_talk') } end
    local p = n.profile.driver
    if p.prior_record then
        n.identified = true
        n.fingerprint = { match = true, name = VPO.NPC.FullName(p), dob = p.dob, wanted = p.wanted,
            mismatch = n.given ~= nil and n.given.false_ == true }
        s.driverName = n.fingerprint.name
    else
        n.fingerprint = { match = false }
    end
    return panel(s)
end)

---------------------------------------------------------------------------
-- Step out
---------------------------------------------------------------------------
VPO.Net.Callback('roads:npcStepOut', { permission = 'roads.stop', rate = 'roads' }, function(src, _, d)
    local s, err = npcStop(src, d)
    if not s then return { error = err } end
    local n = s.npc
    if n.state ~= 'stopped' then return { error = L('npc_not_in_vehicle') } end
    local b = n.enc.behaviour
    local said
    if b == 'flee_foot' or (b == 'nervous' and chance(C.Behaviour.NervousBolt)) then
        setState(s, 'fleeing_foot')
        control(s, 'flee_foot')
        said = L('npc_bolts')
    elseif b == 'aggressive' and hostileAllowed(s) then
        setState(s, 'hostile')
        control(s, 'hostile')
        said = L('npc_goes_for_you')
    elseif (b == 'uncooperative' or b == 'aggressive') and not n.warned then
        n.refusals = n.refusals + 1
        said = L('npc_refuses_out')
    else
        setState(s, 'out')
        control(s, 'step_out')
        said = L('npc_steps_out')
    end
    local p = panel(s); p.said = said
    return p
end)

---------------------------------------------------------------------------
-- Arrest and hand over
---------------------------------------------------------------------------
local function allowedOffences(list)
    local set = {}
    for _, a in ipairs(list or {}) do for _, it in ipairs(a.items or {}) do set[('%s, %s'):format(it, a.act)] = true end end
    return set
end

VPO.Net.Callback('roads:npcArrest', { permission = 'arrest.make', rate = 'arrest' }, function(src, o, d)
    local s, err = npcStop(src, d)
    if not s then return { error = err } end
    local n = s.npc
    if n.state == 'arrested' then return { error = L('arrest_already') } end
    if n.state ~= 'stopped' and n.state ~= 'out' and n.state ~= 'surrendered' then return { error = L('npc_detain_first') } end
    local p = entity(n.pedNet)
    if not p or dist(ped(src), p) > 4.0 then return { error = L('restraint_too_far') } end

    local allowed, offences = allowedOffences(NS.PanelData(s).offences), {}
    for _, off in ipairs(type(d.offences) == 'table' and d.offences or {}) do
        if allowed[off] and not VPO.Util.Contains(offences, off) then offences[#offences + 1] = off end
    end
    if #offences == 0 then return { error = L('arrest_need_offence') } end
    local grounds = VPO.Util.Trim(d.grounds, 2000)
    if not grounds or #grounds < Config.Arrest.GroundsMinLength then return { error = L('arrest_need_grounds', Config.Arrest.GroundsMinLength) } end
    if d.cautioned ~= true then return { error = L('arrest_need_caution') } end

    local truth = n.profile.driver
    local known = (n.identified and VPO.NPC.FullName(truth)) or (n.given and n.given.name) or L('npc_unknown_person')
    local id = MySQL.insert.await([[INSERT INTO vpo_arrests (identifier, subject_name, offences, grounds, necessity, cautioned, location,
        officer_identifier, officer_name, created_at) VALUES (?, ?, ?, ?, ?, 1, ?, ?, ?, ?)]],
        { ('npc:%d'):format(truth.id), known, json.encode(offences), grounds, json.encode({ 'NPC' }), s.location, o.identifier, VPO.Officers.Label(o), os.time() })
    if not id then return { error = L('qual_failed') } end
    local ref = ('%s/%s/%05d'):format(Config.Force.short, os.date('%y%m'), id)
    MySQL.update.await('UPDATE vpo_arrests SET ref = ? WHERE id = ?', { ref, id })
    VPO.NPC.Keep(truth.id, s.plate)

    n.arrest = { id = id, ref = ref, offences = offences, by = VPO.Officers.Label(o), at = os.time(), model = GetEntityModel(p), name = known }
    setState(s, 'arrested')
    setCuffed(s, true)
    control(s, 'cuff')
    VPO.Duty.AddStat(src, 'arrests', 1)
    if Config.Standards.PromptOnCuff then VPO.Standards.Prompt(src, 'Handcuffing', known, ref) end
    VPO.Audit.Log({ action = 'arrest.make', actor = src, targetType = 'npc', targetId = ('npc:%d'):format(truth.id),
        new = { ref = ref, offences = offences, name = known }, reason = grounds })
    local out = panel(s); out.said = L('npc_arrested', ref)
    return out
end)

-- Prisoner transport takes the arrested NPC to a custody suite, where they wait to be booked in.
VPO.Net.Callback('roads:npcHandover', { permission = 'arrest.make', rate = 'arrest' }, function(src, _, d)
    local s, err = npcStop(src, d)
    if not s then return { error = err } end
    if s.npc.state ~= 'arrested' then return { error = L('npc_not_arrested') } end
    local suite = VPO.CustodyNpc.Receive(src, s)
    control(s, 'handover')
    setCuffed(s, false)
    s.npc.handedOver = true
    Roads.Close(s.id, 'Arrest', ('Prisoner %s taken to %s'):format(s.npc.arrest.ref, suite and suite.label or 'custody'), src)
    return { ok = true, ref = s.ref, suite = suite and suite.label or nil }
end)

--- Points on the record the given name belongs to (a false name means they land on someone else's
--- record, or nowhere).
function NS.Ticketed(s, kind, list, points)
    local n = s.npc
    if kind ~= 'FPN' or (points or 0) <= 0 or not n.given then return end
    local p = VPO.NPC.FindByDetails(n.given.firstname, n.given.lastname, n.given.dob)
    if p then MySQL.update('UPDATE vpo_npc_people SET points = LEAST(points + ?, 24) WHERE id = ?', { points, p.id }) end
end

---------------------------------------------------------------------------
-- Reports from the controlling client
---------------------------------------------------------------------------
VPO.Net.On('npc:event', { permission = 'roads.stop', rate = 'roads', silent = true }, function(src, _, stopId, event)
    local s = Roads.All()[tonumber(stopId) or 0]
    if not s or not s.npc or not s.officers[src] then return end
    local n = s.npc
    if event == 'stopped' and n.state == 'stopping' then
        if n.afterGiveUp == 'flee_foot' then
            setState(s, 'fleeing_foot')
            control(s, 'flee_foot')
        else
            setState(s, 'stopped')
        end
    elseif event == 'surrendered' and (n.state == 'fleeing_foot' or n.state == 'hostile') then
        local p = entity(n.pedNet)
        -- The server checks someone is actually with them
        local near = false
        for officer in pairs(s.officers) do if p and dist(ped(officer), p) <= 8.0 then near = true end end
        if near then
            setState(s, 'surrendered')
            for officer in pairs(s.officers) do VPO.Notify(officer, L('npc_surrendered'), 'success') end
        end
    end
end)

---------------------------------------------------------------------------
-- Pursuits: lost, gave up, or the NPC vanished
---------------------------------------------------------------------------
local function closest(s, ent)
    local best = math.huge
    for officer in pairs(s.officers) do best = math.min(best, dist(ped(officer), ent)) end
    return best
end

local function failed(s, outcome)
    local officer = s.npc.controller or s.officer
    if C.AddToANPR and VPO.Integrations.Get('mdt') and VPO.Integrations.Get('mdt').canWrite and GetPlayerName(officer) then
        CreateThread(function()
            VPO.Integrations.Call('mdt', 'Request', officer, 'anprAdd', {
                plate = s.plate, reason = outcome == 'Failed to stop' and 'Failed to stop for police' or 'Driver made off from police',
                action = 'Stop vehicle', note = ('Vehicle stop %s'):format(s.ref), hours = C.ANPRHours, _reason = 'Vehicle stop',
            })
        end)
    end
    VPO.NPC.Keep(s.npc.profile.driver.id, s.plate)
    for o in pairs(s.officers) do VPO.Notify(o, L('npc_lost', s.plate), 'error') end
    Roads.Close(s.id, outcome, nil, nil)
end

CreateThread(function()
    while true do
        Wait(5000)
        local now = os.time()
        for _, s in pairs(Roads.All()) do
            local n = s.npc
            if n and n.state ~= 'ended' then
                local veh, p = entity(s.net), entity(n.pedNet)
                if n.state == 'fleeing_vehicle' then
                    if not veh then failed(s, 'Failed to stop')
                    else
                        if closest(s, veh) > C.LostDistance then n.lostFor = n.lostFor + 5 else n.lostFor = 0 end
                        if n.lostFor >= C.LostSeconds then failed(s, 'Failed to stop')
                        elseif now - n.lastGiveUpRoll >= 15 then
                            n.lastGiveUpRoll = now
                            if chance(C.GiveUpChance) then
                                n.afterGiveUp = chance(50) and 'flee_foot' or 'stop'
                                setState(s, 'stopping')
                                control(s, 'pull_over')
                            end
                        end
                    end
                elseif n.state == 'fleeing_foot' then
                    if not p then failed(s, 'Made off on foot')
                    else
                        if closest(s, p) > C.LostDistance / 2 then n.lostFor = n.lostFor + 5 else n.lostFor = 0 end
                        if n.lostFor >= C.LostSeconds then failed(s, 'Made off on foot') end
                    end
                elseif not p and n.state ~= 'arrested' then
                    Roads.Close(s.id, s.outcome or 'Not recorded', nil, nil)
                end
            end
        end
    end
end)

-- When the stop ends, let the NPC go (or clear it away if it was handed over).
Roads.OnClose(function(s)
    if not s.npc then return end
    if s.npc.state == 'arrested' and not s.npc.handedOver then
        -- Ended without handing over: transport still takes them to custody.
        VPO.CustodyNpc.Receive(s.npc.controller or s.officer, s)
        s.npc.handedOver = true
        control(s, 'handover')
    elseif not s.npc.handedOver and s.npc.state ~= 'fleeing_vehicle' and s.npc.state ~= 'fleeing_foot' then
        control(s, 'release')
    elseif s.npc.state == 'fleeing_vehicle' or s.npc.state == 'fleeing_foot' then
        control(s, 'forget')
    end
    setCuffed(s, false)
    setState(s, 'ended')
end)

AddEventHandler('playerDropped', function() cooldown[source] = nil end)
