-- Station armouries: Tasers, firearms and ammunition. Qualified officers sign kit out themselves (serials
-- as before) and hand it all back in one go. Rounds that don't come back (counting what's still loaded in
-- the firearms) are a discharge: the officer gives an account, and it's kept for review.
VPO.Armoury = {}
local AR = VPO.Armoury
local E = VPO.Equipment
local L = VPO.L

local function armouryItems()
    local out = {}
    for _, it in ipairs(Config.Equipment.Items) do if it.armoury then out[#out + 1] = it end end
    return out
end

local function outstanding(identifier)
    local out = {}
    for _, r in ipairs(E.Outstanding(identifier)) do
        local def = E.Item(r.item)
        if def and def.armoury then out[#out + 1] = r end
    end
    return out
end

--- Rounds still loaded in the officer's issued firearms, by ammo item: { ['ammo-9'] = 12 }, and which
--- serials they're carrying.
local function loaded(src, rows)
    local bySerial = {}
    for _, it in ipairs(VPO.Inventory.List(src)) do
        local md = type(it.metadata) == 'table' and it.metadata or {}
        if md.serial then bySerial[md.serial] = { ammo = tonumber(md.ammo) or 0, name = it.name } end
    end
    local rounds, held = {}, {}
    for _, r in ipairs(rows) do
        if r.serial and bySerial[r.serial] then
            held[r.serial] = true
            local def = E.Item(r.item)
            if def and def.ammo then rounds[def.ammo] = (rounds[def.ammo] or 0) + bySerial[r.serial].ammo end
        end
    end
    return rounds, held
end

--- Issued and accounted-for rounds per ammo item: { [ammo] = { label, issued, inHand, inWeapons, short } }
local function accounting(src, rows)
    local inWeapons = loaded(src, rows)
    local out = {}
    for _, r in ipairs(rows) do
        local def = E.Item(r.item)
        if def and not def.serial then
            local a = out[r.item] or { item = r.item, label = def.label, issued = 0 }
            a.issued = a.issued + r.count
            out[r.item] = a
        end
    end
    for item, a in pairs(out) do
        a.inWeapons = math.min(inWeapons[item] or 0, a.issued)
        a.inHand = math.min(VPO.Inventory.Count(src, item), a.issued - a.inWeapons)
        a.short = a.issued - a.inWeapons - a.inHand
    end
    return out
end

---------------------------------------------------------------------------
-- Armoury panel
---------------------------------------------------------------------------
VPO.Net.Callback('armoury:view', { permission = 'equipment.basic', rate = 'hub' }, function(src, o)
    local station = VPO.Stations.AtArmoury(src)
    if not station then return { error = L('armoury_go_to') } end
    local items = {}
    for _, it in ipairs(armouryItems()) do
        local ok, why = E.Allowed(src, o, it)
        items[#items + 1] = { item = it.item, label = it.label, max = it.max or 1, count = it.count or 1,
            held = VPO.Inventory.Count(src, it.item), allowed = ok, needs = not ok and why or nil, serial = it.serial == true }
    end
    local rows = outstanding(o.identifier)
    local acc = {}
    for _, a in pairs(accounting(src, rows)) do acc[#acc + 1] = a end
    table.sort(acc, function(a, b) return a.label < b.label end)
    local out = VPO.Hub.Header(src, o)
    out.ok, out.station, out.items, out.outstanding, out.rounds = true, station.label, items, rows, acc
    return out
end)

VPO.Net.Callback('armoury:draw', { permission = 'equipment.basic', rate = 'equipment' }, function(src, o, d)
    if not VPO.Stations.AtArmoury(src) then return { error = L('armoury_go_to') } end
    local it = E.Item(type(d) == 'table' and d.item or '')
    if not it or not it.armoury then return { error = L('equipment_unknown') } end
    return E.Draw(src, o, it)
end)

---------------------------------------------------------------------------
-- Handing in
---------------------------------------------------------------------------
--- Hands in everything signed out from the armoury. account: the officer's account of missing rounds
--- (required unless auto). auto: sign-off with no account given (marked unaccounted for review).
--- Returns result table, or { needAccount, short } when rounds are missing and no account was given.
function AR.HandIn(src, o, account, auto)
    local rows = outstanding(o.identifier)
    if #rows == 0 then return { ok = true, nothing = true } end
    local acc = accounting(src, rows)
    local short = {}
    for _, a in pairs(acc) do if a.short > 0 then short[#short + 1] = { label = a.label, rounds = a.short, item = a.item } end end
    account = VPO.Util.Trim(account, 1000)
    if #short > 0 and not auto and (not account or #account < 10) then
        return { needAccount = true, short = short }
    end

    local session = VPO.Duty.Get(src)
    local station = VPO.Stations.AtArmoury(src)
    local missing = {}
    -- Firearms and Tasers by serial (loaded rounds come back inside them)
    for _, r in ipairs(rows) do
        local def = E.Item(r.item)
        if def and def.serial then
            if not E.TakeBack(src, r, auto and 'signed_off' or 'handed_in') then
                missing[#missing + 1] = ('%s (%s)'):format(r.label or r.item, r.serial or '?')
                VPO.Audit.Log({ action = 'equipment.missing', actor = src, targetType = 'equipment', targetId = r.serial,
                    new = { item = r.item }, reason = auto and 'not held at sign-off' or 'not handed in' })
            end
        end
    end
    -- Ammunition: take back what's in hand, close the issue rows
    for item, a in pairs(acc) do
        if a.inHand > 0 then VPO.Inventory.Remove(src, item, a.inHand) end
        for _, r in ipairs(rows) do
            if r.item == item then
                MySQL.update.await('UPDATE vpo_equipment_issue SET returned_at = ?, return_reason = ? WHERE id = ? AND returned_at IS NULL',
                    { os.time(), a.short > 0 and 'discharged' or (auto and 'signed_off' or 'handed_in'), r.id })
            end
        end
    end
    -- Discharges
    for _, sh in ipairs(short) do
        MySQL.insert.await([[INSERT INTO vpo_discharges (identifier, officer_name, session_id, station, ammo, label, rounds, account, unaccounted, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)]],
            { o.identifier, VPO.Officers.Label(o), session and session.id or nil, station and station.label or nil, sh.item, sh.label, sh.rounds,
              account or L('armoury_no_account'), (auto or not account) and 1 or 0, os.time() })
        VPO.Audit.Log({ action = 'armoury.discharge', actor = src, targetType = 'officer', targetId = o.identifier,
            new = { ammo = sh.item, rounds = sh.rounds }, reason = account or 'unaccounted at sign-off' })
        VPO.Duty.AddStat(src, 'roundsDischarged', sh.rounds)
    end
    if #short > 0 then
        -- Supervisors on duty are told
        for s in pairs(VPO.Duty.All()) do
            if s ~= src and VPO.Permissions.Check(s, 'audit.view') then
                VPO.Notify(s, L('armoury_discharge_alert', VPO.Officers.Label(o), short[1].rounds, short[1].label), 'inform', 10000)
            end
        end
    end
    return { ok = true, short = short, missing = missing }
end

VPO.Net.Callback('armoury:handIn', { permission = 'equipment.basic', rate = 'equipment' }, function(src, o, d)
    if not VPO.Stations.AtArmoury(src) then return { error = L('armoury_go_to') } end
    return AR.HandIn(src, o, type(d) == 'table' and d.account or nil, false)
end)

VPO.Duty.OnSignOff(function(src, session, gone)
    if gone or Config.Equipment.OnSignOff ~= 'return' then return nil end
    local o = VPO.Officers.Get(src)
    if not o then return nil end
    local res = AR.HandIn(src, o, nil, true)
    if res.short and #res.short > 0 then VPO.Notify(src, L('armoury_unaccounted'), 'error', 10000) end
    if res.missing and #res.missing > 0 then VPO.Notify(src, L('equipment_missing', table.concat(res.missing, ', ')), 'error', 10000) end
    return nil
end)

--- Discharges for review (professional standards, phase 5). filters: { unreviewed = true, identifier }
function AR.Discharges(f)
    f = f or {}
    local where, args = {}, {}
    if f.unreviewed then where[#where + 1] = 'reviewed_at IS NULL' end
    if f.identifier then where[#where + 1] = 'identifier = ?'; args[#args + 1] = f.identifier end
    local sql = 'SELECT * FROM vpo_discharges' .. (#where > 0 and (' WHERE ' .. table.concat(where, ' AND ')) or '') .. ' ORDER BY id DESC LIMIT 100'
    return MySQL.query.await(sql, args) or {}
end
