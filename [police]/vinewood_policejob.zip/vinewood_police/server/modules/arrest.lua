-- Arrest, person search and stop and search. With vinewood-mdt 2.18+ every record is made in the MDT
-- as the officer (its checks, references and audit apply); vinewood_police keeps a copy with the
-- MDT reference. Without the MDT, vinewood_police keeps the records itself in the same formats.
VPO.Arrest = {}
local A = VPO.Arrest
local L = VPO.L
local grants = {} -- [target] = { officer, expires } after a yes to a search

---------------------------------------------------------------------------
-- Helpers
---------------------------------------------------------------------------
local function ped(src)
    local p = GetPlayerPed(src)
    return (p and p ~= 0 and DoesEntityExist(p)) and p or nil
end

local function near(a, b, max)
    local pa, pb = ped(a), ped(b)
    return pa and pb and #(GetEntityCoords(pa) - GetEntityCoords(pb)) <= max or false
end

local function coordsOf(src)
    local p = ped(src)
    if not p then return nil end
    local c = GetEntityCoords(p)
    return { x = math.floor(c.x * 10) / 10, y = math.floor(c.y * 10) / 10, z = math.floor(c.z * 10) / 10 }
end

local function targetFrom(src, d, max)
    local target = tonumber(type(d) == 'table' and d.target or nil)
    if not target or target == src or not GetPlayerName(target) then return nil, L('restraint_no_target') end
    if not near(src, target, max) then return nil, L('restraint_too_far') end
    if not VPO.Bridge.GetIdentifier(target) then return nil, L('restraint_no_target') end
    return target
end

--- The MDT adapter if it can take records (2.18+), else nil.
local function mdt()
    local a = VPO.Integrations.Get('mdt')
    return a and a.canWrite and a or nil
end

local function mdtRequest(src, action, data)
    local res, err = VPO.Integrations.Call('mdt', 'Request', src, action, data)
    if type(res) ~= 'table' then return { error = L('mdt_no_answer', tostring(err or '?')) } end
    return res
end

--- The arrest form's offences: this job's list merged with the MDT's (when it's running), so an offence
--- in either always shows. Same Act names are joined; duplicates are dropped.
function VPO.ArrestOffences()
    local m = VPO.Integrations.Get('mdt')
    local o = m and m.GetFormOptions and m.GetFormOptions() or nil
    local out, byAct = {}, {}
    local function add(list)
        for _, g in ipairs(type(list) == 'table' and list or {}) do
            if type(g) == 'table' and g.act then
                local grp = byAct[g.act]
                if not grp then grp = { act = g.act, items = {}, seen = {} }; byAct[g.act] = grp; out[#out + 1] = grp end
                for _, it in ipairs(g.items or {}) do
                    if not grp.seen[it] then grp.seen[it] = true; grp.items[#grp.items + 1] = it end
                end
            end
        end
    end
    add(Config.Arrest.Offences)
    add(o and o.offences)
    for _, g in ipairs(out) do g.seen = nil end
    return out
end

local function options()
    local m = mdt()
    local o = m and m.GetFormOptions and m.GetFormOptions() or nil
    return {
        mdt = m ~= nil,
        offences = VPO.ArrestOffences(),
        outcomes = o and o.outcomes or { 'In custody' },
        powers = o and o.stopSearch and o.stopSearch.powers or Config.StopSearch.Powers,
        objects = o and o.stopSearch and o.stopSearch.objects or Config.StopSearch.Objects,
        ssOutcomes = o and o.stopSearch and o.stopSearch.outcomes or Config.StopSearch.Outcomes,
        ssEnabled = not o or not o.stopSearch or o.stopSearch.enabled ~= false,
        incidentTypes = o and o.incidentTypes or {},
        evidenceTypes = o and o.evidenceTypes or {},
        forceShort = o and o.forceShort or Config.Force.short,
    }
end

local function openIncidents(src)
    if not mdt() then return {} end
    local res = mdtRequest(src, 'searchIncidents', { status = 'Open' })
    local out = {}
    for i, r in ipairs(res.results or {}) do
        if i > 25 then break end
        out[#out + 1] = { id = r.id, ref = r.ref, type = r.type, location = r.location, at = r.created_at }
    end
    return out
end

--- Picks or creates the MDT incident for a record.
--- Returns id, ref (ref only for a new one), or nil, nil, error. nil, nil, nil = not linked.
local function incidentFor(src, d, cid, location, coords, narrative)
    local id = tonumber(d.incidentId)
    if id then return id, nil end
    local kind = VPO.Util.Trim(d.newIncidentType, 64)
    if not kind then return nil end
    local res = mdtRequest(src, 'createIncident', {
        type = kind, location = location, coords = coords, narrative = narrative,
        linkKind = cid and 'person' or nil, linkId = cid, linkRole = cid and 'Suspect' or nil,
    })
    if res.error then return nil, nil, res.error end
    return res.id, res.ref
end

local function localRef(prefix, id)
    return ('%s%s/%s/%05d'):format(prefix or '', Config.Force.short, os.date('%y%m'), id)
end

function A.InCustody(src) return VPO.State.Get(src, 'custody') end

---------------------------------------------------------------------------
-- Consent to be searched
---------------------------------------------------------------------------
local function askConsent(target, o)
    local choice = VPO.AskPlayer(target, L('search_prompt_title'), L('search_prompt_text', VPO.Officers.Label(o)),
        { { id = 'yes', label = L('search_prompt_accept') }, { id = 'no', label = L('search_prompt_decline') } },
        Config.Search.ConsentTimeout)
    return choice == 'yes'
end

--- Why this officer may search this person right now: 'cuffed' | 'custody' | 'consent', or nil.
local function searchBasis(src, target)
    if VPO.Restraint.IsCuffed(target) then return 'cuffed' end
    if A.InCustody(target) then return 'custody' end
    local g = grants[target]
    if g and g.officer == src and g.expires > os.time() then return 'consent' end
    return nil
end

---------------------------------------------------------------------------
-- Person search
---------------------------------------------------------------------------
local function itemsFor(target)
    local out = {}
    for _, it in ipairs(VPO.Inventory.List(target)) do
        local md = type(it.metadata) == 'table' and it.metadata or {}
        out[#out + 1] = {
            slot = it.slot, name = it.name, label = it.label, count = it.count,
            note = md.serial and ('Serial ' .. tostring(md.serial)) or md.description or nil,
        }
    end
    return out
end

VPO.Net.Callback('search:open', { permission = 'search.person', rate = 'search' }, function(src, o, d)
    local target, err = targetFrom(src, d, Config.Search.Distance)
    if not target then return { error = err } end
    local basis = searchBasis(src, target)
    if not basis then
        local yes = askConsent(target, o)
        if not yes then return { error = L('search_refused') } end
        grants[target] = { officer = src, expires = os.time() + Config.Search.ConsentLasts }
        basis = 'consent'
        if not near(src, target, Config.Search.Distance + 1.0) then return { error = L('restraint_too_far') } end
    end
    VPO.Audit.Log({ action = 'search.person', actor = src, targetType = 'player', targetId = VPO.Bridge.GetIdentifier(target), meta = { basis = basis } })
    VPO.Duty.AddStat(src, 'personSearches', 1)
    local opts = options()
    local out = VPO.Hub.Header(src, o)
    out.ok = true
    out.subject = { name = VPO.Bridge.GetName(target), basis = basis }
    out.items = itemsFor(target)
    out.canOpen = Config.Search.AllowOpenInventory and VPO.Inventory.CanForceOpen()
    -- With the MDT: MDT evidence bags on an incident. Without it: vinewood_police exhibits.
    out.localEvidence = not opts.mdt and VPO.Inventory.CanStash()
    out.canSeize = (opts.mdt and #opts.evidenceTypes > 0) or out.localEvidence
    out.incidents = (opts.mdt and out.canSeize) and openIncidents(src) or {}
    out.incidentTypes = opts.incidentTypes
    out.evidenceTypes = opts.mdt and opts.evidenceTypes or Config.Evidence.Types
    out.inCustody = A.InCustody(target) ~= nil
    out.ssEnabled = opts.ssEnabled
    return out
end)

VPO.Net.Callback('search:openInventory', { permission = 'search.person', rate = 'search' }, function(src, _, d)
    if not Config.Search.AllowOpenInventory then return { error = L('no_permission') } end
    local target, err = targetFrom(src, d, Config.Search.Distance)
    if not target then return { error = err } end
    if not searchBasis(src, target) then return { error = L('search_need_basis') } end
    if not VPO.Inventory.ForceOpen(src, target) then return { error = L('search_cant_open') } end
    return { ok = true }
end)

VPO.Net.Callback('search:seize', { permission = 'search.seize', rate = 'search' }, function(src, o, d)
    d = type(d) == 'table' and d or {}
    local target, err = targetFrom(src, d, Config.Search.Distance)
    if not target then return { error = err } end
    if not searchBasis(src, target) then return { error = L('search_need_basis') } end

    local items = {}
    for _, it in ipairs(type(d.items) == 'table' and d.items or {}) do
        local slot, count = tonumber(it.slot), math.floor(tonumber(it.count) or 0)
        if slot and count > 0 then items[#items + 1] = { slot = slot, count = count } end
    end
    if #items == 0 then return { error = L('search_tick_items') } end

    if not mdt() then
        -- No MDT: vinewood_police keeps the exhibit, linked to their custody reference if they have one.
        if not VPO.Util.Contains(Config.Evidence.Types, d.type) then return { error = L('evidence_pick_type') } end
        local c = A.InCustody(target)
        local ref, names = VPO.Evidence.SeizeFromPlayer(o, target, items, d.type, c and c.ref or VPO.Util.Trim(d.linkedRef, 32), VPO.Util.Trim(d.description, 255))
        if not ref then return { error = names } end
        return { ok = true, ref = ref, moved = names, items = itemsFor(target) }
    end

    local cid = VPO.Bridge.GetIdentifier(target)
    local location = VPO.Util.Trim(d.location, 160)
    local incidentId, _, e2 = incidentFor(src, d, cid, location, coordsOf(src), 'Created from a person search.')
    if not incidentId then return { error = e2 or L('search_pick_incident') } end

    local res = mdtRequest(src, 'seizeItems', {
        incidentId = incidentId, cid = cid, items = items, type = d.type, foundAt = location,
        description = VPO.Util.Trim(d.description, 255),
    })
    if res.error then return { error = res.error } end
    VPO.Audit.Log({ action = 'search.seize', actor = src, targetType = 'player', targetId = cid, new = { exhibit = res.ref, items = res.moved } })
    return { ok = true, ref = res.ref, moved = res.moved, items = itemsFor(target) }
end)

---------------------------------------------------------------------------
-- Arrest
---------------------------------------------------------------------------
local function allowedOffences(list)
    local set = {}
    for _, a in ipairs(list or {}) do
        for _, item in ipairs(a.items or {}) do set[('%s, %s'):format(item, a.act)] = true end
    end
    return set
end

VPO.Net.Callback('arrest:prepare', { permission = 'arrest.make', rate = 'arrest' }, function(src, o, d)
    local target, err = targetFrom(src, d, Config.Restraint.Distance + 1.0)
    if not target then return { error = err } end
    if Config.Arrest.RequireCuffs and not VPO.Restraint.IsCuffed(target) then return { error = L('arrest_cuff_first') } end
    if A.InCustody(target) then return { error = L('arrest_already') } end
    local opts = options()
    local out = VPO.Hub.Header(src, o)
    out.ok = true
    out.subject = { name = VPO.Bridge.GetName(target) }
    out.offences = opts.offences
    out.necessity = Config.Arrest.Necessity
    out.caution = Config.Arrest.Caution
    out.groundsMin = Config.Arrest.GroundsMinLength
    out.mdt = opts.mdt
    out.incidents = opts.mdt and openIncidents(src) or {}
    out.incidentTypes = opts.incidentTypes
    return out
end)

VPO.Net.Callback('arrest:showCaution', { permission = 'arrest.make', rate = 'arrest' }, function(src, o, d)
    local target, err = targetFrom(src, d, 6.0)
    if not target then return { error = err } end
    TriggerClientEvent('vinewood_police:client:notice', target, { title = L('caution_title'), text = Config.Arrest.Caution, from = VPO.Officers.Label(o) })
    return { ok = true }
end)

VPO.Net.Callback('arrest:submit', { permission = 'arrest.make', rate = 'arrest' }, function(src, o, d)
    d = type(d) == 'table' and d or {}
    local target, err = targetFrom(src, d, Config.Restraint.Distance + 1.0)
    if not target then return { error = err } end
    if Config.Arrest.RequireCuffs and not VPO.Restraint.IsCuffed(target) then return { error = L('arrest_cuff_first') } end
    if A.InCustody(target) then return { error = L('arrest_already') } end

    local opts = options()
    local allowed, offences = allowedOffences(opts.offences), {}
    for _, off in ipairs(type(d.offences) == 'table' and d.offences or {}) do
        if allowed[off] and not VPO.Util.Contains(offences, off) then offences[#offences + 1] = off end
    end
    if #offences == 0 then return { error = L('arrest_need_offence') } end

    local grounds = VPO.Util.Trim(d.grounds, 2000)
    if not grounds or #grounds < Config.Arrest.GroundsMinLength then return { error = L('arrest_need_grounds', Config.Arrest.GroundsMinLength) } end

    local necessity = {}
    for _, i in ipairs(type(d.necessity) == 'table' and d.necessity or {}) do
        local n = Config.Arrest.Necessity[tonumber(i) or 0]
        if n and not VPO.Util.Contains(necessity, n) then necessity[#necessity + 1] = n end
    end
    if #necessity == 0 then return { error = L('arrest_need_necessity') } end
    if d.cautioned ~= true then return { error = L('arrest_need_caution') } end

    local cid = VPO.Bridge.GetIdentifier(target)
    local name = VPO.Bridge.GetName(target)
    local location = VPO.Util.Trim(d.location, 160)
    local coords = coordsOf(src)
    local narrative = ('%s\n\nNecessity: %s.\nCautioned: yes.%s'):format(grounds, table.concat(necessity, '; '),
        location and ('\nLocation: ' .. location) or '')

    local ref, recordId, incidentId, incidentRef
    if opts.mdt then
        local e2
        incidentId, incidentRef, e2 = incidentFor(src, d, cid, location, coords, narrative)
        if e2 then return { error = e2 } end
        if incidentId and not incidentRef then
            for _, i in ipairs(openIncidents(src)) do if i.id == incidentId then incidentRef = i.ref end end
        end
        local res = mdtRequest(src, 'createRecord', {
            cid = cid, offences = offences, outcome = opts.outcomes[1], narrative = narrative, incidentId = incidentId,
        })
        if res.error then return { error = res.error } end
        ref, recordId = res.ref, res.id
    else
        incidentRef = VPO.Util.Trim(d.incidentRef, 32)
    end

    local id = MySQL.insert.await([[INSERT INTO vpo_arrests (ref, identifier, subject_name, offences, grounds, necessity, cautioned,
        incident_ref, mdt_record_id, mdt_incident_id, location, coords, officer_identifier, officer_name, created_at)
        VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?)]],
        { ref, cid, name, json.encode(offences), grounds, json.encode(necessity), incidentRef, recordId, incidentId,
          location, coords and json.encode(coords) or nil, o.identifier, VPO.Officers.Label(o), os.time() })
    if not id then return { error = L('qual_failed') } end
    if not ref then
        ref = localRef('', id)
        MySQL.update.await('UPDATE vpo_arrests SET ref = ? WHERE id = ?', { ref, id })
    end

    VPO.State.Set(target, 'custody', {
        arrestId = id, ref = ref, mdtRecordId = recordId, name = name, at = os.time(),
        by = o.identifier, byLabel = VPO.Officers.Label(o), offences = offences,
    })
    VPO.Duty.AddStat(src, 'arrests', 1)
    VPO.Audit.Log({ action = 'arrest.make', actor = src, targetType = 'player', targetId = cid,
        new = { ref = ref, offences = offences }, reason = grounds })
    TriggerClientEvent('vinewood_police:client:notice', target, {
        title = L('arrest_notice_title'), from = VPO.Officers.Label(o),
        text = L('arrest_notice_text', table.concat(offences, '; '), Config.Arrest.Caution),
    })
    TriggerEvent('vinewood_police:server:arrested', target, { ref = ref, arrestId = id, officer = src, offences = offences, mdtRecordId = recordId })
    return { ok = true, ref = ref }
end)

VPO.Net.Callback('arrest:releasePrepare', { permission = 'arrest.release', rate = 'arrest' }, function(src, o, d)
    local target, err = targetFrom(src, d, 4.0)
    if not target then return { error = err } end
    local c = A.InCustody(target)
    if not c then return { error = L('arrest_not_under') } end
    local out = VPO.Hub.Header(src, o)
    out.ok = true
    out.subject = { name = VPO.Bridge.GetName(target) }
    out.custody = { ref = c.ref, at = c.at, byLabel = c.byLabel, offences = c.offences }
    return out
end)

VPO.Net.Callback('arrest:release', { permission = 'arrest.release', rate = 'arrest' }, function(src, _, d)
    d = type(d) == 'table' and d or {}
    local target, err = targetFrom(src, d, 4.0)
    if not target then return { error = err } end
    local c = A.InCustody(target)
    if not c then return { error = L('arrest_not_under') } end
    if c.booked then return { error = L('custody_use_panel') } end
    local reason = VPO.Util.Trim(d.reason, 255)
    if not reason or #reason < 5 then return { error = L('arrest_release_reason') } end
    MySQL.update.await('UPDATE vpo_arrests SET released_at = ?, release_reason = ? WHERE id = ?', { os.time(), reason, c.arrestId })
    VPO.State.Set(target, 'custody', nil)
    VPO.Audit.Log({ action = 'arrest.release', actor = src, targetType = 'player', targetId = VPO.Bridge.GetIdentifier(target), previous = c, reason = reason })
    VPO.Notify(target, L('arrest_released_target'), 'inform')
    return { ok = true, message = L('arrest_released', c.ref or '') }
end)

---------------------------------------------------------------------------
-- Stop and search record
---------------------------------------------------------------------------
local function findById(list, id)
    for _, p in ipairs(list or {}) do if p.id == id then return p end end
    return nil
end

VPO.Net.Callback('stopsearch:prepare', { permission = 'stopsearch.record', rate = 'search' }, function(src, o, d)
    local opts = options()
    if not opts.ssEnabled then return { error = L('ss_disabled') } end
    local target = tonumber(type(d) == 'table' and d.target or nil)
    if target and (not GetPlayerName(target) or not near(src, target, 8.0)) then target = nil end
    local out = VPO.Hub.Header(src, o)
    out.ok = true
    out.subject = target and { name = VPO.Bridge.GetName(target) } or nil
    out.powers, out.objects, out.outcomes = opts.powers, opts.objects, opts.ssOutcomes
    out.mdt = opts.mdt
    return out
end)

VPO.Net.Callback('stopsearch:submit', { permission = 'stopsearch.record', rate = 'search' }, function(src, o, d)
    d = type(d) == 'table' and d or {}
    local opts = options()
    if not opts.ssEnabled then return { error = L('ss_disabled') } end
    local power = findById(opts.powers, d.power)
    if not power then return { error = L('ss_need_power') } end
    if not VPO.Util.Contains(opts.objects, d.object) then return { error = L('ss_need_object') } end
    if not VPO.Util.Contains(opts.ssOutcomes, d.outcome) then return { error = L('ss_need_outcome') } end
    local grounds = VPO.Util.Trim(d.grounds, 2000)
    if not power.authorisation and (not grounds or #grounds < 20) then return { error = L('ss_need_grounds') } end
    local authorisation = VPO.Util.Trim(d.authorisation, 160)
    if power.authorisation and not authorisation then return { error = L('ss_need_authorisation') } end
    if d.gowisely ~= true then return { error = L('ss_need_gowisely') } end

    local target = tonumber(d.target)
    if target and (not GetPlayerName(target) or not near(src, target, 8.0)) then target = nil end
    local cid = target and VPO.Bridge.GetIdentifier(target) or nil
    local description = VPO.Util.Trim(d.description, 255)
    if not cid and not description then return { error = L('ss_need_person') } end
    local location, coords = VPO.Util.Trim(d.location, 160), coordsOf(src)
    local found = VPO.Util.Trim(d.found, 1000)

    local ref
    if opts.mdt then
        local res = mdtRequest(src, 'stopSearchCreate', {
            cid = cid, description = description, power = power.id, authorisation = authorisation, object = d.object,
            grounds = grounds, location = location, coords = coords, found = found, outcome = d.outcome, gowisely = true,
        })
        if res.error then return { error = res.error } end
        ref = res.ref
    end

    local id = MySQL.insert.await([[INSERT INTO vpo_stop_search (ref, identifier, subject_name, power, authorisation, object, grounds, found,
        outcome, location, coords, officer_identifier, officer_name, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)]],
        { ref, cid, cid and VPO.Bridge.GetName(target) or description, power.id, authorisation, d.object, grounds, found,
          d.outcome, location, coords and json.encode(coords) or nil, o.identifier, VPO.Officers.Label(o), os.time() })
    if not id then return { error = L('qual_failed') } end
    if not ref then
        ref = localRef('SS/', id)
        MySQL.update.await('UPDATE vpo_stop_search SET ref = ? WHERE id = ?', { ref, id })
        VPO.Audit.Log({ action = 'stopsearch.record', actor = src, targetType = 'player', targetId = cid, new = { ref = ref, power = power.id, outcome = d.outcome } })
        -- The MDT gives the person their record itself; without it, we do.
        if target then
            VPO.Documents.Give(target, {
                title = L('ss_notice_title'), from = VPO.Officers.Label(o), ref = ref,
                text = L('ss_notice_text', ref, power.label, d.object, d.outcome, os.date('%d/%m/%Y %H:%M')),
            })
        end
    end
    VPO.Duty.AddStat(src, 'searches', 1)
    return { ok = true, ref = ref }
end)

---------------------------------------------------------------------------
-- Clean-up
---------------------------------------------------------------------------
AddEventHandler('playerDropped', function()
    local src = source
    grants[src] = nil
    for t, g in pairs(grants) do if g.officer == src then grants[t] = nil end end
end)
