-- Exhibits kept by vinewood_police. Each gets a reference in the seizing officer's initials (JS/1, JS/2...)
-- and a continuity log of every move. Player items live in a police-only bag (ox_inventory stash);
-- NPC finds are records with a description.
VPO.Evidence = {}
local E = VPO.Evidence
local L = VPO.L

local function initials(name)
    local out = ''
    for w in tostring(name or ''):gmatch('%a+') do out = out .. w:sub(1, 1):upper() end
    return out ~= '' and out:sub(1, 3) or 'XX'
end

--- Next exhibit reference for an officer.
local function nextRef(o)
    local pre = initials(o.name)
    local n = MySQL.scalar.await('SELECT COUNT(*) FROM vpo_exhibits WHERE officer_identifier = ?', { o.identifier }) or 0
    return ('%s/%d'):format(pre, n + 1)
end

local function continuity(list, text, by)
    list = list or {}
    list[#list + 1] = { at = os.time(), text = text, by = by }
    return list
end

--- Creates an exhibit. data = { description, type, fromName, fromIdentifier, linkedRef, stash, items }
--- Returns id, ref.
function E.Create(o, data)
    local ref = nextRef(o)
    local label = VPO.Officers.Label(o)
    local id = MySQL.insert.await([[INSERT INTO vpo_exhibits (ref, description, type, from_name, from_identifier, linked_ref, stash, items,
        continuity, officer_identifier, officer_name, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)]],
        { ref, tostring(data.description):sub(1, 255), data.type, data.fromName, data.fromIdentifier, data.linkedRef, data.stash,
          data.items and json.encode(data.items) or nil, json.encode(continuity(nil, 'Seized', label)), o.identifier, label, os.time() })
    if not id then return nil end
    VPO.Audit.Log({ action = 'evidence.seize', actor = o.src, targetType = 'exhibit', targetId = ref,
        new = { description = data.description, from = data.fromName, linked = data.linkedRef } })
    return id, ref
end

--- Seize items (by slot) from a player into a new exhibit bag. Needs ox_inventory.
function E.SeizeFromPlayer(o, target, picks, kind, linkedRef, description)
    if not VPO.Inventory.CanStash() then return nil, L('custody_no_property_system') end
    local have = {}
    for _, it in ipairs(VPO.Inventory.List(target)) do have[it.slot] = it end
    local chosen = {}
    for _, p in ipairs(picks) do
        local it = have[p.slot]
        if it then chosen[#chosen + 1] = { slot = it.slot, name = it.name, label = it.label, count = math.min(p.count, it.count), metadata = it.metadata } end
    end
    if #chosen == 0 then return nil, L('search_tick_items') end
    local moved = {}
    -- Move only the chosen slots
    for _, c in ipairs(chosen) do
        if VPO.Inventory.Remove(target, c.name, c.count, c.metadata, c.slot) then moved[#moved + 1] = c end
    end
    if #moved == 0 then return nil, L('qual_failed') end
    local names = {}
    for _, m in ipairs(moved) do names[#names + 1] = ('%dx %s'):format(m.count, m.label) end
    local id, ref = E.Create(o, {
        description = description or table.concat(names, ', '), type = kind, fromName = VPO.Bridge.GetName(target),
        fromIdentifier = VPO.Bridge.GetIdentifier(target), linkedRef = linkedRef, items = names,
    })
    if not id then
        for _, m in ipairs(moved) do VPO.Inventory.Add(target, m.name, m.count, m.metadata) end
        return nil, L('qual_failed')
    end
    local stash = ('vpo_exhibit_%d'):format(id)
    exports.ox_inventory:RegisterStash(stash, ('Exhibit %s'):format(ref), 30, 200000, false, (function()
        local g = {} for job in pairs(Config.Jobs) do g[job] = 0 end return g end)())
    for _, m in ipairs(moved) do exports.ox_inventory:AddItem(stash, m.name, m.count, m.metadata) end
    MySQL.update('UPDATE vpo_exhibits SET stash = ? WHERE id = ?', { stash, id })
    VPO.Notify(target, L('evidence_seized_target', table.concat(names, ', '), ref), 'inform', 10000)
    return ref, names
end

---------------------------------------------------------------------------
-- The evidence store (panel)
---------------------------------------------------------------------------
local function atStore(src)
    local Cfg = Config.Evidence
    if Cfg.AtCustodyDesk and VPO.Custody and VPO.Custody.SuiteAt(src) then return true end
    if Cfg.AtLocker and VPO.Stations.AtLocker(src) then return true end
    return false
end

local function view(r)
    return {
        id = r.id, ref = r.ref, description = r.description, type = r.type, from = r.from_name, linked = r.linked_ref,
        status = r.status, officer = r.officer_name, at = r.created_at, bag = r.stash ~= nil,
        continuity = r.continuity and json.decode(r.continuity) or {},
    }
end

VPO.Net.Callback('evidence:list', { permission = 'evidence.view', rate = 'custody' }, function(src, o, d)
    if not atStore(src) then return { error = L('evidence_go_to_store') } end
    local q = VPO.Util.Trim(type(d) == 'table' and d.q or nil, 60)
    local rows
    if q then
        local like = '%' .. q:gsub('[%%_]', '') .. '%'
        rows = MySQL.query.await([[SELECT * FROM vpo_exhibits WHERE ref LIKE ? OR description LIKE ? OR from_name LIKE ? OR linked_ref LIKE ?
            ORDER BY id DESC LIMIT 50]], { like, like, like, like })
    else
        rows = MySQL.query.await('SELECT * FROM vpo_exhibits ORDER BY id DESC LIMIT 30')
    end
    local out = VPO.Hub.Header(src, o)
    out.ok = true
    out.exhibits = {}
    for _, r in ipairs(rows or {}) do out.exhibits[#out.exhibits + 1] = view(r) end
    out.canManage = VPO.Permissions.Check(src, 'evidence.manage') == true
    out.q = q
    return out
end)

VPO.Net.Callback('evidence:open', { permission = 'evidence.view', rate = 'custody' }, function(src, o, d)
    if not atStore(src) then return { error = L('evidence_go_to_store') } end
    local r = MySQL.single.await('SELECT * FROM vpo_exhibits WHERE id = ?', { tonumber(type(d) == 'table' and d.id or 0) })
    if not r or not r.stash then return { error = L('evidence_no_bag') } end
    local list = continuity(json.decode(r.continuity or '[]'), 'Bag opened', VPO.Officers.Label(o))
    MySQL.update('UPDATE vpo_exhibits SET continuity = ? WHERE id = ?', { json.encode(list), r.id })
    VPO.Inventory.OpenStash(src, r.stash, ('Exhibit %s'):format(r.ref))
    return { ok = true }
end)

VPO.Net.Callback('evidence:status', { permission = 'evidence.view', rate = 'custody' }, function(src, o, d)
    if not atStore(src) then return { error = L('evidence_go_to_store') } end
    d = type(d) == 'table' and d or {}
    local r = MySQL.single.await('SELECT * FROM vpo_exhibits WHERE id = ?', { tonumber(d.id) })
    if not r then return { error = L('equipment_not_found') } end
    local status = d.status
    local allowed = { ['property store'] = 'evidence.view', forensics = 'evidence.view', returned = 'evidence.manage', destroyed = 'evidence.manage' }
    if not allowed[status] then return { error = L('evidence_bad_status') } end
    if allowed[status] == 'evidence.manage' and not VPO.Permissions.Check(src, 'evidence.manage') then return { error = L('perm_rank') } end
    if r.status == 'returned' or r.status == 'destroyed' then return { error = L('evidence_closed') } end
    local note = VPO.Util.Trim(d.note, 200)

    if status == 'returned' and r.stash then
        local owner = r.from_identifier and VPO.Bridge.GetSource(r.from_identifier)
        if not owner then return { error = L('evidence_owner_here') } end
        local p1, p2 = GetPlayerPed(src), GetPlayerPed(owner)
        if #(GetEntityCoords(p1) - GetEntityCoords(p2)) > 5.0 then return { error = L('evidence_owner_here') } end
        local back, left = VPO.Inventory.ReturnFromStash(r.stash, owner)
        if left and left > 0 then note = ((note and note .. '. ') or '') .. ('%d items could not be carried and stay in the bag'):format(left) end
        if back and #back == 0 and (left or 0) > 0 then return { error = L('evidence_cant_carry') } end
    elseif status == 'destroyed' and r.stash then
        exports.ox_inventory:ClearInventory(r.stash)
    end

    local list = continuity(json.decode(r.continuity or '[]'), ({ ['property store'] = 'Booked into property store', forensics = 'Sent for forensic examination',
        returned = 'Returned to owner', destroyed = 'Destroyed' })[status] .. (note and (': ' .. note) or ''), VPO.Officers.Label(o))
    MySQL.update('UPDATE vpo_exhibits SET status = ?, continuity = ? WHERE id = ?', { status, json.encode(list), r.id })
    VPO.Audit.Log({ action = 'evidence.' .. status:gsub(' ', '_'), actor = src, targetType = 'exhibit', targetId = r.ref, previous = r.status, new = status, reason = note })
    return { ok = true }
end)
