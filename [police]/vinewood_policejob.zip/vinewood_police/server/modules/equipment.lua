-- Equipment lockers: draw and return kit, serial numbers for weapons, accountability at sign-off.
-- Uniforms are checked here and put on by the client.
VPO.Equipment = {}
local E = VPO.Equipment
local L = VPO.L
local itemByName = {}
for _, it in ipairs(Config.Equipment.Items) do itemByName[it.item] = it end
-- Uniforms can be edited in game, so they're looked up from the live config.
local function outfitFind(id)
    for _, u in ipairs(Config.Uniforms.Outfits or {}) do if u.id == id then return u end end
    return nil
end

function E.Outstanding(identifier)
    return MySQL.query.await('SELECT id, item, label, count, serial, issued_at, return_reason FROM vpo_equipment_issue WHERE identifier = ? AND returned_at IS NULL ORDER BY id',
        { identifier }) or {}
end

--- Can this officer draw this item right now? true, or false + reason.
local function allowed(src, o, it)
    if it.permission then
        local ok, why, extra = VPO.Permissions.Check(src, it.permission)
        if not ok then return false, VPO.Permissions.Message(why, extra) end
    end
    if it.units then
        local s = VPO.Duty.Get(src)
        if not s or not VPO.Util.Contains(it.units, s.unit) then return false, L('equipment_unit_only') end
    end
    return true
end

local function outfitAllowed(src, o, u)
    if u.minRank and o.rank.level < VPO.Ranks.Level(u.minRank) then return false end
    if u.units then
        local s = VPO.Duty.Get(src)
        if not s or not VPO.Util.Contains(u.units, s.unit) then return false end
    end
    for _, q in ipairs(u.qualifications or {}) do
        if not VPO.Qualifications.Has(o.identifier, q) then return false end
    end
    return true
end

local function newSerial()
    for _ = 1, 10 do
        local serial = ('%s%07d'):format((Config.Force.short or 'POL'):upper():sub(1, 4), math.random(0, 9999999))
        if not MySQL.scalar.await('SELECT id FROM vpo_equipment_issue WHERE serial = ?', { serial }) then return serial end
    end
    return nil
end

local function audit(src, action, it, row, reason)
    if not it.serial and not Config.Equipment.AuditAll then return end
    VPO.Audit.Log({ action = action, actor = src, targetType = 'equipment', targetId = row.serial or row.id,
        new = { item = it.item, count = row.count, serial = row.serial }, reason = reason })
end

---------------------------------------------------------------------------
-- Locker view
---------------------------------------------------------------------------
VPO.Net.Callback('equipment:locker', { permission = 'equipment.basic', rate = 'hub' }, function(src, o)
    local station = VPO.Stations.AtLocker(src)
    if not station then return { error = L('equipment_go_to_locker') } end
    local items = {}
    for _, it in ipairs(Config.Equipment.Items) do
        if it.armoury then goto continue end
        local ok, why = allowed(src, o, it)
        items[#items + 1] = {
            item = it.item, label = it.label, max = it.max or 1, count = it.count or 1,
            held = VPO.Inventory.Count(src, it.item), allowed = ok, needs = not ok and why or nil, serial = it.serial == true,
        }
        ::continue::
    end
    local outfits = {}
    for _, u in ipairs(Config.Uniforms.Outfits or {}) do
        if outfitAllowed(src, o, u) then outfits[#outfits + 1] = { id = u.id, label = u.label } end
    end
    local outstanding = {}
    for _, r in ipairs(E.Outstanding(o.identifier)) do
        if not (itemByName[r.item] and itemByName[r.item].armoury) then outstanding[#outstanding + 1] = r end
    end
    return { ok = true, station = station.label, items = items, outstanding = outstanding, outfits = outfits, armouryOut = #outstanding < #E.Outstanding(o.identifier) }
end)

---------------------------------------------------------------------------
-- Draw
---------------------------------------------------------------------------
--- Issues an item (checks done by the caller: where they're standing).
function E.Draw(src, o, it)
    local ok, why = allowed(src, o, it)
    if not ok then return { error = why } end

    local max = it.max or 1
    local held = VPO.Inventory.Count(src, it.item)
    local give = math.min(it.count or 1, max - held)
    if give <= 0 then return { error = L('equipment_at_max', it.label) } end
    if it.serial then give = 1 end

    local serial = it.serial and newSerial() or nil
    if it.serial and not serial then return { error = L('qual_failed') } end
    local metadata = serial and { serial = serial, registered = VPO.Officers.Label(o) } or nil
    if not VPO.Inventory.CanCarry(src, it.item, give, metadata) then return { error = L('equipment_cant_carry') } end

    local session = VPO.Duty.Get(src)
    local id = MySQL.insert.await([[INSERT INTO vpo_equipment_issue (identifier, session_id, item, label, count, serial, issued_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)]], { o.identifier, session and session.id or nil, it.item, it.label, give, serial, os.time() })
    if not id then return { error = L('qual_failed') } end

    if not VPO.Inventory.Add(src, it.item, give, metadata) then
        MySQL.update.await("UPDATE vpo_equipment_issue SET returned_at = ?, return_reason = 'not_issued' WHERE id = ?", { os.time(), id })
        return { error = L('equipment_issue_failed', it.label) }
    end
    audit(src, 'equipment.issue', it, { id = id, count = give, serial = serial })
    return { ok = true, issued = { id = id, label = it.label, count = give, serial = serial } }
end

VPO.Net.Callback('equipment:draw', { permission = 'equipment.basic', rate = 'equipment' }, function(src, o, d)
    if not VPO.Stations.AtLocker(src) then return { error = L('equipment_go_to_locker') } end
    local it = itemByName[type(d) == 'table' and d.item or '']
    if not it then return { error = L('equipment_unknown') } end
    if it.armoury then return { error = L('equipment_use_armoury') } end
    return E.Draw(src, o, it)
end)

---------------------------------------------------------------------------
-- Return
---------------------------------------------------------------------------
--- Takes an issued item back. Returns true, or false + reason.
local function takeBack(src, row, reason)
    local it = itemByName[row.item] or { item = row.item, label = row.label }
    local removed
    if row.serial and VPO.Inventory.Name == 'ox' then
        removed = VPO.Inventory.Remove(src, row.item, 1, { serial = row.serial })
    else
        local held = VPO.Inventory.Count(src, row.item)
        if held < row.count then return false, 'not_held' end
        removed = VPO.Inventory.Remove(src, row.item, row.count)
    end
    if not removed then return false, 'not_held' end
    MySQL.update.await('UPDATE vpo_equipment_issue SET returned_at = ?, return_reason = ? WHERE id = ? AND returned_at IS NULL', { os.time(), reason, row.id })
    audit(src, 'equipment.return', it, row, reason)
    return true
end

VPO.Net.Callback('equipment:return', { permission = 'equipment.basic', rate = 'equipment' }, function(src, o, d)
    if not VPO.Stations.AtLocker(src) then return { error = L('equipment_go_to_locker') } end
    local id = tonumber(type(d) == 'table' and d.id or nil)
    local row = id and MySQL.single.await('SELECT * FROM vpo_equipment_issue WHERE id = ? AND identifier = ? AND returned_at IS NULL', { id, o.identifier })
    if not row then return { error = L('equipment_not_found') } end
    if itemByName[row.item] and itemByName[row.item].armoury then return { error = L('equipment_use_armoury') } end
    local ok = takeBack(src, row, 'returned')
    if not ok then return { error = L('equipment_not_held', row.label or row.item) } end
    return { ok = true }
end)

---------------------------------------------------------------------------
-- Changing room: just the uniforms
---------------------------------------------------------------------------
VPO.Net.Callback('equipment:changing', { permission = 'equipment.basic', rate = 'hub' }, function(src, o)
    local station = VPO.Stations.AtChangingRoom(src) or VPO.Stations.AtLocker(src)
    if not station then return { error = L('uniform_go_to_changing') } end
    local outfits = {}
    for _, u in ipairs(Config.Uniforms.Outfits or {}) do
        if outfitAllowed(src, o, u) then outfits[#outfits + 1] = { id = u.id, label = u.label } end
    end
    local out = VPO.Hub.Header(src, o)
    out.ok, out.station, out.outfits = true, station.label, outfits
    return out
end)

---------------------------------------------------------------------------
-- Uniform (the client puts it on; the server only says whether it's allowed)
---------------------------------------------------------------------------
VPO.Net.Callback('equipment:uniform', { permission = 'equipment.basic', rate = 'equipment' }, function(src, o, d)
    if not VPO.Stations.AtLocker(src) and not VPO.Stations.AtChangingRoom(src) then return { error = L('equipment_go_to_locker') } end
    local id = type(d) == 'table' and d.id or nil
    if id == 'own' then return { ok = true, id = 'own' } end
    local u = outfitFind(id or '')
    if not u or not outfitAllowed(src, o, u) then return { error = L('equipment_uniform_not_allowed') } end
    return { ok = true, id = u.id }
end)

---------------------------------------------------------------------------
-- Sign-off: take back kit still held, flag anything missing
---------------------------------------------------------------------------
E.Allowed, E.TakeBack, E.Audit = allowed, takeBack, audit
function E.Item(name) return itemByName[name] end

VPO.Duty.OnSignOff(function(src, session, gone)
    -- Armoury kit is handed in by the armoury module (it accounts for ammunition)
    local rows = {}
    for _, r in ipairs(E.Outstanding(session.identifier)) do
        if not (itemByName[r.item] and itemByName[r.item].armoury) then rows[#rows + 1] = r end
    end
    if #rows == 0 then return { outstanding = 0 } end
    if gone or Config.Equipment.OnSignOff ~= 'return' then return { outstanding = #rows } end
    local missing = {}
    for _, row in ipairs(rows) do
        local ok = takeBack(src, row, 'signed_off')
        if not ok then
            missing[#missing + 1] = row.serial and ('%s (%s)'):format(row.label or row.item, row.serial) or (row.label or row.item)
            if row.serial then
                VPO.Audit.Log({ action = 'equipment.missing', actor = src, targetType = 'equipment', targetId = row.serial,
                    new = { item = row.item }, reason = 'not held at sign-off' })
            end
        end
    end
    if #missing > 0 then VPO.Notify(src, L('equipment_missing', table.concat(missing, ', ')), 'error', 10000) end
    return { outstanding = #missing, missing = missing }
end)
