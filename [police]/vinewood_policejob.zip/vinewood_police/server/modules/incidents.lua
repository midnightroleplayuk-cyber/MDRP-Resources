-- Major incidents: a declared scene with inner and outer cordons, roles and a scene log.
-- Who goes in and out of the inner cordon is logged automatically.
VPO.Incidents = {}
local MI = VPO.Incidents
local Cfg = Config.Incidents
local L = VPO.L
local active = {} -- [id] = incident

local function ped(src) local p = GetPlayerPed(src); return (p and p ~= 0) and p or nil end
local function v3(c) return vector3(c.x, c.y, c.z) end
local function label(src) return VPO.Officers.Label(VPO.Officers.Get(src)) end

local function publish()
    local list = {}
    for id, i in pairs(active) do
        list[tostring(id)] = { id = id, ref = i.ref, label = i.label, type = i.type, x = i.coords.x, y = i.coords.y, z = i.coords.z, inner = i.inner, outer = i.outer }
    end
    GlobalState.vpo_incidents = list
end

function MI.Log(i, kind, text, officer)
    i.log[#i.log + 1] = { at = os.time(), kind = kind, text = text, by = officer }
    if #i.log > 200 then table.remove(i.log, 1) end
    MySQL.insert('INSERT INTO vpo_incident_log (incident_id, created_at, kind, text, officer) VALUES (?, ?, ?, ?, ?)',
        { i.id, os.time(), kind, tostring(text):sub(1, 1000), officer })
end

local function saveRoles(i)
    MySQL.update('UPDATE vpo_incidents SET roles = ?, inner_r = ?, outer_r = ?, coords = ? WHERE id = ?',
        { json.encode(i.roles), i.inner, i.outer, json.encode(i.coords), i.id })
end

local function notifyScene(i, msg, kind)
    for src in pairs(i.members) do if GetPlayerName(src) then VPO.Notify(src, msg, kind or 'inform', 8000) end end
end

---------------------------------------------------------------------------
-- Declare / join / roles / cordons / stand down
---------------------------------------------------------------------------
local function view(i, src)
    local members = {}
    for m in pairs(i.members) do
        if GetPlayerName(m) then members[#members + 1] = { src = m, label = label(m), role = i.roles[tostring(m)], inside = i.inside[m] == true } end
    end
    table.sort(members, function(a, b) return a.label < b.label end)
    local p = ped(src)
    local log = {}
    for k = #i.log, math.max(1, #i.log - 60), -1 do log[#log + 1] = i.log[k] end
    return {
        id = i.id, ref = i.ref, type = i.type, label = i.label, linked = i.linked, inner = i.inner, outer = i.outer,
        createdAt = i.createdAt, declaredBy = i.declaredBy, members = members, log = log, member = i.members[src] == true,
        role = i.roles[tostring(src)], distance = p and math.floor(#(GetEntityCoords(p) - v3(i.coords))) or nil,
    }
end

local function nearest(src)
    local p = ped(src)
    if not p then return nil end
    local best, bestD
    for _, i in pairs(active) do
        local d = #(GetEntityCoords(p) - v3(i.coords))
        if d <= i.outer + 50 and (not bestD or d < bestD) then best, bestD = i, d end
    end
    return best
end

VPO.Net.Callback('incident:panel', { permission = 'incident.join', rate = 'incident' }, function(src, o, d)
    local out = VPO.Hub.Header(src, o)
    out.ok = true
    local want = type(d) == 'table' and tonumber(d.id) or nil
    local i = want and active[want] or nearest(src)
    out.incident = i and view(i, src) or nil
    out.list = {}
    for _, x in pairs(active) do out.list[#out.list + 1] = { id = x.id, ref = x.ref, label = x.label, type = x.type } end
    out.types, out.roles = Cfg.Types, Cfg.Roles
    out.canDeclare = VPO.Permissions.Check(src, 'incident.declare') == true
    out.defaults = { inner = Cfg.DefaultInner, outer = Cfg.DefaultOuter, max = Cfg.MaxRadius }
    return out
end)

VPO.Net.Callback('incident:declare', { permission = 'incident.declare', rate = 'incident' }, function(src, o, d)
    d = type(d) == 'table' and d or {}
    local n = 0
    for _ in pairs(active) do n = n + 1 end
    if n >= Cfg.MaxActive then return { error = L('incident_too_many') } end
    if not VPO.Util.Contains(Cfg.Types, d.type) then return { error = L('incident_pick_type') } end
    local name = VPO.Util.Trim(d.label, 120)
    if not name then return { error = L('incident_need_label') } end
    local p = ped(src)
    local c = GetEntityCoords(p)
    local inner = math.floor(math.min(math.max(tonumber(d.inner) or Cfg.DefaultInner, 5), Cfg.MaxRadius))
    local outer = math.floor(math.min(math.max(tonumber(d.outer) or Cfg.DefaultOuter, inner + 5), Cfg.MaxRadius))
    local coords = { x = math.floor(c.x * 10) / 10, y = math.floor(c.y * 10) / 10, z = math.floor(c.z * 10) / 10 }
    local by = VPO.Officers.Label(o)
    local id = MySQL.insert.await([[INSERT INTO vpo_incidents (type, label, coords, inner_r, outer_r, linked, declared_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)]],
        { d.type, name, json.encode(coords), inner, outer, VPO.Util.Trim(d.linked, 160), by, os.time() })
    if not id then return { error = L('qual_failed') } end
    local ref = ('MI/%s/%s/%05d'):format(Config.Force.short, os.date('%y%m'), id)
    MySQL.update('UPDATE vpo_incidents SET ref = ? WHERE id = ?', { ref, id })
    local i = { id = id, ref = ref, type = d.type, label = name, coords = coords, inner = inner, outer = outer, linked = VPO.Util.Trim(d.linked, 160),
        declaredBy = by, createdAt = os.time(), members = { [src] = true }, roles = { [tostring(src)] = 'Bronze commander' }, inside = {}, log = {} }
    active[id] = i
    saveRoles(i)
    publish()
    MI.Log(i, 'declared', ('%s declared by %s. Inner cordon %d m, outer %d m.%s'):format(d.type, by, inner, outer, i.linked and (' Linked to ' .. i.linked .. '.') or ''), by)
    MI.Log(i, 'role', ('%s is Bronze commander'):format(by), by)
    VPO.Audit.Log({ action = 'incident.declare', actor = src, targetType = 'incident', targetId = ref, new = { type = d.type, label = name } })
    for s in pairs(VPO.Duty.All()) do if s ~= src then VPO.Notify(s, L('incident_declared', d.type, name), 'inform', 8000) end end
    return { ok = true, incident = view(i, src) }
end)

local function own(src, d)
    local i = active[tonumber(type(d) == 'table' and d.id or nil) or 0]
    if not i then return nil, L('incident_gone') end
    return i
end

local function canCommand(src, i)
    local role = i.roles[tostring(src)]
    return role == 'Bronze commander' or role == 'Silver commander' or VPO.Permissions.Check(src, 'incident.declare') == true
end

VPO.Net.Callback('incident:join', { permission = 'incident.join', rate = 'incident' }, function(src, _, d)
    local i, err = own(src, d)
    if not i then return { error = err } end
    local p = ped(src)
    if not p or #(GetEntityCoords(p) - v3(i.coords)) > i.outer + 100 then return { error = L('incident_go_there') } end
    if not i.members[src] then
        i.members[src] = true
        MI.Log(i, 'joined', ('%s booked on to the incident'):format(label(src)), label(src))
    end
    return { ok = true, incident = view(i, src) }
end)

VPO.Net.Callback('incident:leave', { permission = 'incident.join', rate = 'incident' }, function(src, _, d)
    local i, err = own(src, d)
    if not i then return { error = err } end
    if i.members[src] then
        i.members[src] = nil
        i.roles[tostring(src)] = nil
        saveRoles(i)
        MI.Log(i, 'left', ('%s booked off the incident'):format(label(src)), label(src))
    end
    return { ok = true }
end)

VPO.Net.Callback('incident:role', { permission = 'incident.join', rate = 'incident' }, function(src, _, d)
    local i, err = own(src, d)
    if not i then return { error = err } end
    if not canCommand(src, i) then return { error = L('incident_commander_only') } end
    local target = tonumber(d.target)
    if not target or not i.members[target] then return { error = L('incident_not_member') } end
    local role = d.role ~= '' and d.role or nil
    if role and not VPO.Util.Contains(Cfg.Roles, role) then return { error = L('incident_bad_role') } end
    if role == 'Silver commander' then
        local o = VPO.Officers.Get(target)
        if not o or o.rank.level < VPO.Ranks.Level(Cfg.SilverRank) then return { error = L('incident_silver_rank', VPO.Ranks.Get(Cfg.SilverRank).label) } end
    end
    if role == 'Bronze commander' then
        for k, r in pairs(i.roles) do if r == 'Bronze commander' then i.roles[k] = nil end end
    end
    i.roles[tostring(target)] = role
    saveRoles(i)
    MI.Log(i, 'role', role and ('%s is %s'):format(label(target), role) or ('%s has no role'):format(label(target)), label(src))
    if role and target ~= src then VPO.Notify(target, L('incident_role_given', role, i.label), 'inform') end
    return { ok = true, incident = view(i, src) }
end)

VPO.Net.Callback('incident:cordon', { permission = 'incident.join', rate = 'incident' }, function(src, _, d)
    local i, err = own(src, d)
    if not i then return { error = err } end
    if not canCommand(src, i) then return { error = L('incident_commander_only') } end
    local inner = math.floor(math.min(math.max(tonumber(d.inner) or i.inner, 5), Cfg.MaxRadius))
    local outer = math.floor(math.min(math.max(tonumber(d.outer) or i.outer, inner + 5), Cfg.MaxRadius))
    local text = ('Cordons set: inner %d m, outer %d m'):format(inner, outer)
    if d.here then
        local c = GetEntityCoords(ped(src))
        i.coords = { x = math.floor(c.x * 10) / 10, y = math.floor(c.y * 10) / 10, z = math.floor(c.z * 10) / 10 }
        text = text .. ', centred where ' .. label(src) .. ' stood'
    end
    i.inner, i.outer = inner, outer
    saveRoles(i)
    publish()
    MI.Log(i, 'cordon', text, label(src))
    return { ok = true, incident = view(i, src) }
end)

VPO.Net.Callback('incident:note', { permission = 'incident.join', rate = 'incident' }, function(src, _, d)
    local i, err = own(src, d)
    if not i then return { error = err } end
    if not i.members[src] then return { error = L('incident_not_member') } end
    local text = VPO.Util.Trim(d.text, 1000)
    if not text then return { error = L('notebook_empty') } end
    MI.Log(i, 'note', text, label(src))
    return { ok = true, incident = view(i, src) }
end)

VPO.Net.Callback('incident:standDown', { permission = 'incident.join', rate = 'incident' }, function(src, _, d)
    local i, err = own(src, d)
    if not i then return { error = err } end
    if not canCommand(src, i) then return { error = L('incident_commander_only') } end
    local summary = VPO.Util.Trim(d.summary, 2000)
    MI.Log(i, 'stood_down', ('Stood down by %s.%s'):format(label(src), summary and (' ' .. summary) or ''), label(src))
    MySQL.update("UPDATE vpo_incidents SET status = 'closed', summary = ?, closed_at = ? WHERE id = ?", { summary, os.time(), i.id })
    active[i.id] = nil
    publish()
    notifyScene(i, L('incident_stood_down', i.label))
    VPO.Audit.Log({ action = 'incident.stand_down', actor = src, targetType = 'incident', targetId = i.ref })
    return { ok = true, ref = i.ref }
end)

---------------------------------------------------------------------------
-- Inner cordon log: everyone who goes in or out, and alerts for people not on the incident
---------------------------------------------------------------------------
CreateThread(function()
    while true do
        Wait(2000)
        if Cfg.WatchInnerCordon then
            for _, i in pairs(active) do
                local centre = v3(i.coords)
                local now = {}
                for _, id in ipairs(GetPlayers()) do
                    local src = tonumber(id)
                    local p = ped(src)
                    if p and #(GetEntityCoords(p) - centre) <= i.inner then now[src] = true end
                end
                for src in pairs(now) do
                    if not i.inside[src] then
                        i.inside[src] = true
                        if i.members[src] then
                            MI.Log(i, 'entry', ('%s entered the inner cordon'):format(label(src)), nil)
                        else
                            local who = VPO.IsOnDuty(src) == true and label(src) or (VPO.Bridge.GetName(src) or GetPlayerName(src))
                            MI.Log(i, 'breach', ('NOT ON THE INCIDENT: %s entered the inner cordon'):format(who), nil)
                            notifyScene(i, L('incident_breach', who), 'error')
                        end
                    end
                end
                for src in pairs(i.inside) do
                    if not now[src] then
                        i.inside[src] = nil
                        if GetPlayerName(src) then MI.Log(i, 'exit', ('%s left the inner cordon'):format(i.members[src] and label(src) or (VPO.Bridge.GetName(src) or GetPlayerName(src))), nil) end
                    end
                end
            end
        end
    end
end)

-- Load running incidents after a restart
AddEventHandler(VPO.Events.ready, function()
    for _, r in ipairs(MySQL.query.await("SELECT * FROM vpo_incidents WHERE status = 'active'") or {}) do
        local ok, c = pcall(json.decode, r.coords)
        local okR, roles = pcall(json.decode, r.roles or '{}')
        active[r.id] = { id = r.id, ref = r.ref, type = r.type, label = r.label, coords = ok and c or { x = 0, y = 0, z = 0 }, inner = r.inner_r, outer = r.outer_r,
            linked = r.linked, declaredBy = r.declared_by, createdAt = r.created_at, members = {}, roles = {}, inside = {}, log = {} }
        local rows = MySQL.query.await('SELECT created_at, kind, text, officer FROM vpo_incident_log WHERE incident_id = ? ORDER BY id DESC LIMIT 60', { r.id }) or {}
        for k = #rows, 1, -1 do local x = rows[k]; active[r.id].log[#active[r.id].log + 1] = { at = x.created_at, kind = x.kind, text = x.text, by = x.officer } end
        -- Roles are kept by name for the record; members re-join after a restart
        active[r.id].previousRoles = okR and roles or {}
    end
    publish()
end)

AddEventHandler('playerDropped', function()
    local src = source
    for _, i in pairs(active) do i.members[src] = nil; i.inside[src] = nil; i.roles[tostring(src)] = nil end
end)

function MI.Active() return active end
