-- NPC detainees. Transport brings an arrested NPC to a custody suite; from there they're dealt with in the
-- custody panel like anyone else, except that outcomes stay here (an NPC can't go to the MDT, CPS or
-- court). In a cell they're a real ped, so officers can see and visit them; it is server-created and
-- kept through restarts.
VPO.CustodyNpc = {}
local CN = VPO.CustodyNpc
local Cfg = Config.Custody
local L = VPO.L
local open = {}            -- [arrestId] = row
local overdueNotified = {}

local obsByLevel = {}
-- Suites can be edited in game, so they're always looked up from the live config.
local function suiteById(id)
    for _, s in ipairs(Config.Custody.Suites) do if s.id == id then return s end end
    return nil
end
for _, o in ipairs(Cfg.Observation) do obsByLevel[o.level] = o end

local function cellDef(row)
    local s = suiteById(row.suite)
    if not s or not row.cell then return nil end
    for _, c in ipairs(s.cells) do if c.id == row.cell then return c, s end end
    return nil
end

local function persist(row)
    MySQL.update([[UPDATE vpo_npc_custody SET status = ?, booked_at = ?, booked_by = ?, grounds = ?, risk = ?, observation = ?, cell = ?,
        out_reason = ?, next_welfare = ?, interview = ?, outcome = ?, released_at = ? WHERE arrest_id = ?]],
        { row.status, row.booked_at, row.booked_by, row.grounds, row.risk, row.observation, row.cell, row.out_reason, row.next_welfare,
          row.interview and json.encode(row.interview) or nil, row.outcome, row.released_at, row.arrest_id })
end

---------------------------------------------------------------------------
-- The ped in the cell
---------------------------------------------------------------------------
local function despawn(row)
    if row.ped and DoesEntityExist(row.ped) then DeleteEntity(row.ped) end
    row.ped = nil
end

local function spawn(row)
    despawn(row)
    local cell = cellDef(row)
    if not cell or row.out_reason then return end
    local model = tonumber(row.model) or GetHashKey(Cfg.NpcFallbackModel)
    local c = cell.coords
    local ped = CreatePed(4, model, c.x, c.y, c.z - 1.0, c.w or 0.0, true, true)
    local deadline = GetGameTimer() + 3000
    while not DoesEntityExist(ped) and GetGameTimer() < deadline do Wait(20) end
    if not DoesEntityExist(ped) then
        if model ~= GetHashKey(Cfg.NpcFallbackModel) then row.model = nil; return spawn(row) end
        return
    end
    SetEntityOrphanMode(ped, 2) -- keep it even when no player is near
    FreezeEntityPosition(ped, true)
    Entity(ped).state:set('vpo_npc_detainee', { id = row.arrest_id, name = row.name }, true)
    row.ped = ped
end

---------------------------------------------------------------------------
-- Arrival
---------------------------------------------------------------------------
local function nearestSuite(src)
    local p = GetPlayerPed(src)
    local here = p and p ~= 0 and GetEntityCoords(p) or nil
    local best, bestD
    for _, s in ipairs(Config.Custody.Suites) do
        local dd = here and #(here - s.desk.coords) or 0
        if not bestD or dd < bestD then best, bestD = s, dd end
    end
    return best
end

--- A detainee brought in by transport. data = {
---   arrest = { id, ref, name, model, offences, by, at }, personId, evidence = { exhibits, tests, details, fingerprint },
---   sourceRef (stop or call reference) }
function CN.ReceiveFrom(officer, data)
    local a = data.arrest
    if not a then return nil end
    if open[a.id] then return suiteById(open[a.id].suite) end
    local suite = nearestSuite(officer)
    if not suite then return nil end
    local row = {
        arrest_id = a.id, ref = a.ref, person_id = data.personId, name = a.name, model = a.model, suite = suite.id,
        status = 'awaiting', offences = a.offences, arrested_by = a.by, arrested_at = a.at, stop_ref = data.sourceRef, evidence = data.evidence or {},
    }
    MySQL.insert.await([[INSERT INTO vpo_npc_custody (arrest_id, ref, person_id, name, model, suite, status, offences, arrested_by, arrested_at, stop_ref, evidence)
        VALUES (?, ?, ?, ?, ?, ?, 'awaiting', ?, ?, ?, ?, ?)]],
        { a.id, a.ref, data.personId, a.name, a.model, suite.id, json.encode(a.offences), a.by, a.at, data.sourceRef, json.encode(row.evidence) })
    -- Exhibits found before the arrest move onto the custody reference
    for _, e in ipairs(row.evidence.exhibits or {}) do
        MySQL.update('UPDATE vpo_exhibits SET linked_ref = ? WHERE ref = ? AND linked_ref = ?', { a.ref, e.ref, data.sourceRef })
    end
    open[a.id] = row
    VPO.Custody.Log(a.id, 'transport', ('Arrived at %s by prisoner transport (%s)'):format(suite.label, data.sourceRef or '-'), a.by)
    for _, id in ipairs(GetPlayers()) do
        local p = tonumber(id)
        if VPO.IsOnDuty(p) == true and VPO.Custody.SuiteAt(p) == suite then VPO.Notify(p, L('npc_custody_arrived', a.name or '?', suite.label), 'inform') end
    end
    return suite
end

--- From a roads NPC stop whose driver has been arrested.
function CN.Receive(officer, stop)
    local n = stop.npc
    if not n.arrest then return nil end
    return CN.ReceiveFrom(officer, {
        arrest = n.arrest, personId = n.profile.driver.id, sourceRef = stop.ref,
        evidence = { exhibits = n.exhibits or {}, tests = stop.checks.tests or {}, details = n.given, fingerprint = n.fingerprint },
    })
end

---------------------------------------------------------------------------
-- Panel
---------------------------------------------------------------------------
local function hours(at) return math.floor((os.time() - (at or os.time())) / 60 / (Cfg.HourLength or 2) * 10) / 10 end

--- NPC detainees for the custody panel, in the shape detaineeView uses.
function CN.ForSuite(suite)
    local out, now = {}, os.time()
    for _, r in pairs(open) do
        if r.suite == suite.id then
            local cell = cellDef(r)
            out[#out + 1] = {
                npc = true, key = 'npc:' .. r.arrest_id, id = r.arrest_id, name = r.name, ref = r.ref, at = r.arrested_at, byLabel = r.arrested_by,
                offences = r.offences, hours = hours(r.arrested_at), limit = Cfg.LimitHours,
                booked = r.booked_at and { risk = r.risk, observation = r.observation, grounds = r.grounds } or nil,
                cell = cell and cell.label or nil, cellId = r.cell, out = r.out_reason,
                welfareDue = r.next_welfare, welfareOverdue = r.next_welfare ~= nil and r.next_welfare < now and not r.out_reason,
                interview = r.interview, evidence = r.evidence,
            }
        end
    end
    return out
end

--- Cells taken by NPCs in a suite: { [cellId] = true }
function CN.Occupied(suite)
    local out = {}
    for _, r in pairs(open) do if r.suite == suite.id and r.cell then out[r.cell] = true end end
    return out
end

---------------------------------------------------------------------------
-- Interview: what they say depends on their record and the evidence against them
---------------------------------------------------------------------------
local function interview(row)
    local person = VPO.NPC.GetPerson(row.person_id) or {}
    local ev = row.evidence or {}
    local strong = #(ev.exhibits or {})
    for _, t in ipairs(ev.tests or {}) do if t.outcome == 'fail' then strong = strong + 1 end end
    local noComment = 30 + (person.prior_record and 30 or 0) - strong * 5
    local admit = 20 + strong * 20 - (person.prior_record and 10 or 0)
    local r = math.random(1, 100)
    local kind = r <= noComment and 'no_comment' or (r <= noComment + admit and 'admits' or 'denies')
    local lines = {
        no_comment = 'Answered "no comment" to every question.',
        admits = strong > 0 and 'Admitted the offences when shown the evidence.' or 'Admitted the offences, gave an account of why.',
        denies = strong > 0 and 'Denied the offences and could not explain the evidence.' or 'Denied the offences, gave an alternative account.',
    }
    return { result = kind, summary = lines[kind], solicitor = math.random(1, 100) <= 60, at = os.time() }
end

---------------------------------------------------------------------------
-- Actions
---------------------------------------------------------------------------
local function ownedRow(src, id)
    local row = open[tonumber(id) or 0]
    if not row then return nil, L('custody_not_detained') end
    local suite = VPO.Custody.SuiteAt(src)
    if not suite or suite.id ~= row.suite then return nil, L('custody_go_to_suite') end
    return row, suite
end

local function officerLabel(src) return VPO.Officers.Label(VPO.Officers.Get(src)) end

local function release(row, outcome, src)
    do local cell, s = cellDef(row); if cell then VPO.Custody.SetCellDoor(s, cell, false) end end
    despawn(row)
    row.status = outcome:find('^Charged') and 'charged' or 'released'
    row.outcome, row.released_at = outcome, os.time()
    persist(row)
    open[row.arrest_id] = nil
    MySQL.update('UPDATE vpo_arrests SET released_at = ?, release_reason = ? WHERE id = ?', { os.time(), outcome, row.arrest_id })
    VPO.Custody.Log(row.arrest_id, 'release', outcome, officerLabel(src))
    VPO.Audit.Log({ action = 'custody.npc_outcome', actor = src, targetType = 'npc', targetId = row.ref, new = { outcome = outcome } })
    if outcome:find('remanded') then VPO.NPC.Keep(row.person_id) end
end

VPO.Net.Callback('custody:npc', { permission = 'custody.view', rate = 'custody' }, function(src, o, d)
    d = type(d) == 'table' and d or {}
    local row, suite = ownedRow(src, d.id)
    if not row then return { error = suite } end
    local action = d.action
    local book = VPO.Permissions.Check(src, 'custody.book') == true
    local cells = VPO.Permissions.Check(src, 'custody.cells') == true
    local by = officerLabel(src)

    if action == 'bookIn' then
        if not book then return { error = L('perm_rank') } end
        if row.booked_at then return { error = L('custody_already_booked') } end
        if #(GetEntityCoords(GetPlayerPed(src)) - suite.desk.coords) > Cfg.DeskRadius then return { error = L('custody_at_desk') } end
        if d.authorise == false then
            release(row, 'Detention not authorised', src)
            return { ok = true }
        end
        if not VPO.Util.Contains(Cfg.DetentionGrounds, d.grounds) then return { error = L('custody_pick_grounds') } end
        local obs = obsByLevel[tonumber(d.observation) or 0]
        if not obs then return { error = L('custody_pick_observation') } end
        if d.rights ~= true then return { error = L('custody_need_rights') } end
        row.status, row.booked_at, row.booked_by, row.grounds = 'booked', os.time(), by, d.grounds
        row.risk = (d.risk == 'medium' or d.risk == 'high') and d.risk or 'low'
        row.observation, row.next_welfare = obs.level, os.time() + obs.minutes * 60
        persist(row)
        VPO.Custody.Log(row.arrest_id, 'booked', ('Detention authorised: %s. Risk %s, %s. Rights and entitlements given.'):format(d.grounds, row.risk, obs.label), by)
        return { ok = true }

    elseif action == 'cell' then
        if not cells then return { error = L('perm_rank') } end
        if not row.booked_at then return { error = L('custody_book_first') } end
        local cell
        for _, c in ipairs(suite.cells) do if c.id == d.cell then cell = c end end
        if not cell then return { error = L('custody_pick_cell') } end
        if VPO.Custody.CellTaken(suite, cell.id, row.arrest_id) then return { error = L('custody_cell_taken', cell.label) } end
        row.cell, row.out_reason = cell.id, nil
        persist(row)
        spawn(row)
        VPO.Custody.SetCellDoor(suite, cell, true)
        VPO.Custody.Log(row.arrest_id, 'cell', ('Placed in %s'):format(cell.label), by)
        return { ok = true }

    elseif action == 'out' then
        if not row.cell then return { error = L('custody_not_in_cell') } end
        row.out_reason = VPO.Util.Contains(Cfg.OutReasons, d.reason) and d.reason or 'Other'
        persist(row)
        despawn(row)
        do local cell, s = cellDef(row); if cell then VPO.Custody.SetCellDoor(s, cell, false) end end
        VPO.Custody.Log(row.arrest_id, 'out', ('Out of cell: %s'):format(row.out_reason), by)
        return { ok = true }

    elseif action == 'back' then
        if not row.cell then return { error = L('custody_not_in_cell') } end
        row.out_reason = nil
        persist(row)
        spawn(row)
        do local cell, s = cellDef(row); if cell then VPO.Custody.SetCellDoor(s, cell, true) end end
        VPO.Custody.Log(row.arrest_id, 'cell', 'Returned to cell', by)
        return { ok = true }

    elseif action == 'welfare' then
        if not row.booked_at then return { error = L('custody_book_first') } end
        local level = tonumber(d.observation)
        if level and level ~= row.observation then
            if not book then return { error = L('custody_sergeant_only') } end
            if not obsByLevel[level] then return { error = L('custody_pick_observation') } end
            row.observation = level
            VPO.Custody.Log(row.arrest_id, 'observation', ('Observation changed to %s'):format(obsByLevel[level].label), by)
        end
        row.next_welfare = os.time() + (obsByLevel[row.observation] or Cfg.Observation[1]).minutes * 60
        overdueNotified[row.arrest_id] = nil
        persist(row)
        local note = VPO.Util.Trim(d.note, 500)
        VPO.Custody.Log(row.arrest_id, 'welfare', 'Welfare check: roused and responsive. ' .. (note or ''), by)
        return { ok = true }

    elseif action == 'interview' then
        if row.out_reason ~= 'Interview' then return { error = L('npc_custody_take_to_interview') } end
        if not row.interview then row.interview = interview(row) end
        persist(row)
        VPO.Custody.Log(row.arrest_id, 'interview', ('Interviewed%s. %s'):format(row.interview.solicitor and ' with a solicitor' or ', declined a solicitor', row.interview.summary), by)
        return { ok = true, interview = row.interview }

    elseif action == 'outcome' then
        if not book then return { error = L('perm_rank') } end
        if not VPO.Util.Contains(Cfg.NpcOutcomes, d.outcome) then return { error = L('roads_pick_outcome') } end
        if (d.outcome == 'Simple caution' or d.outcome == 'Community resolution') and not (row.interview and row.interview.result == 'admits') then
            return { error = L('npc_custody_needs_admission') }
        end
        release(row, d.outcome, src)
        return { ok = true }
    end
    return { error = L('npc_custody_unknown') }
end)

---------------------------------------------------------------------------
-- Welfare reminders, and putting peds back after a restart
---------------------------------------------------------------------------
CreateThread(function()
    while true do
        Wait(60000)
        local now = os.time()
        for _, row in pairs(open) do
            if row.next_welfare and row.next_welfare < now and not row.out_reason
                and (not overdueNotified[row.arrest_id] or now - overdueNotified[row.arrest_id] >= 300) then
                overdueNotified[row.arrest_id] = now
                VPO.Custody.Log(row.arrest_id, 'overdue', 'Welfare check overdue', 'System')
                local cell = cellDef(row)
                for _, id in ipairs(GetPlayers()) do
                    local p = tonumber(id)
                    local s = VPO.IsOnDuty(p) == true and VPO.Custody.SuiteAt(p)
                    if s and s.id == row.suite then VPO.Notify(p, L('custody_welfare_overdue', row.name or '?', cell and cell.label or '?'), 'error', 10000) end
                end
            end
            -- A ped that went missing (deleted by something else) is put back
            if row.cell and not row.out_reason and (not row.ped or not DoesEntityExist(row.ped)) then spawn(row) end
        end
    end
end)

AddEventHandler(VPO.Events.ready, function()
    for _, r in ipairs(MySQL.query.await("SELECT * FROM vpo_npc_custody WHERE status IN ('awaiting', 'booked')") or {}) do
        r.offences = r.offences and json.decode(r.offences) or {}
        r.evidence = r.evidence and json.decode(r.evidence) or {}
        r.interview = r.interview and json.decode(r.interview) or nil
        open[r.arrest_id] = r
        if r.cell and not r.out_reason then spawn(r) end
    end
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= VPO.Resource then return end
    for _, row in pairs(open) do despawn(row) end
end)
