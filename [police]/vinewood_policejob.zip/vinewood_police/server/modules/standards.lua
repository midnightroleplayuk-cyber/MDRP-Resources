-- Professional standards: use of force forms, discharge reviews, public complaints and the audit viewer.
VPO.Standards = {}
local SF = VPO.Standards
local Cfg = Config.Standards
local L = VPO.L

local function dec(s, fb) local ok, v = pcall(json.decode, s or ''); return ok and v or fb end
local function label(o) return VPO.Officers.Label(o) end

---------------------------------------------------------------------------
-- Use of force: a pending form appears after force is used; the officer completes it.
---------------------------------------------------------------------------
--- Starts a pending form (deduplicated: same officer, trigger and subject within 10 minutes).
function SF.Prompt(src, trigger, subject, linkedRef)
    local o = VPO.Officers.Get(src)
    if not o then return end
    local recent = MySQL.scalar.await([[SELECT id FROM vpo_uof WHERE identifier = ? AND status = 'pending' AND `trigger` = ? AND (subject <=> ?) AND created_at > ? LIMIT 1]],
        { o.identifier, trigger, subject, os.time() - 600 })
    if recent then return end
    MySQL.insert.await([[INSERT INTO vpo_uof (identifier, officer, status, `trigger`, subject, linked_ref, created_at) VALUES (?, ?, 'pending', ?, ?, ?, ?)]],
        { o.identifier, label(o), trigger, subject, linkedRef, os.time() })
    VPO.Notify(src, L('uof_pending', trigger), 'inform', 7000)
end

-- Taser or firearm fired (reported by the officer's game; checked against what they were issued)
VPO.Net.On('standards:discharge', { permission = 'uof.submit', rate = 'discharge', silent = true }, function(src, o, weapon)
    weapon = tostring(weapon or ''):upper()
    local taser = VPO.Util.Contains(Cfg.TaserWeapons, weapon)
    local firearm = VPO.Util.Contains(Cfg.FirearmWeapons, weapon)
    if (taser and not Cfg.PromptOnTaser) or (firearm and not Cfg.PromptOnFirearm) or (not taser and not firearm) then return end
    if VPO.Inventory.Count(src, weapon) < 1 then return end
    SF.Prompt(src, taser and 'Taser fired' or 'Firearm fired', nil, nil)
end)

local function uofView(r)
    return { id = r.id, status = r.status, trigger = r.trigger, subject = r.subject, linked = r.linked_ref, tactics = dec(r.tactics, {}),
        reasons = dec(r.reasons, {}), subjectInjured = r.subject_injured == 1, officerInjured = r.officer_injured == 1, narrative = r.narrative,
        location = r.location, createdAt = r.created_at, submittedAt = r.submitted_at, officer = r.officer, reviewedBy = r.reviewed_by, reviewNote = r.review_note }
end

VPO.Net.Callback('uof:list', { permission = 'uof.submit', rate = 'standards' }, function(src, o)
    local rows = MySQL.query.await('SELECT * FROM vpo_uof WHERE identifier = ? ORDER BY (status = \'pending\') DESC, id DESC LIMIT 30', { o.identifier }) or {}
    local list = {}
    for _, r in ipairs(rows) do list[#list + 1] = uofView(r) end
    return { ok = true, forms = list, tactics = Cfg.Tactics, reasons = Cfg.Reasons }
end)

VPO.Net.Callback('uof:submit', { permission = 'uof.submit', rate = 'standards' }, function(src, o, d)
    d = type(d) == 'table' and d or {}
    local tactics, reasons = {}, {}
    for _, t in ipairs(type(d.tactics) == 'table' and d.tactics or {}) do if VPO.Util.Contains(Cfg.Tactics, t) then tactics[#tactics + 1] = t end end
    for _, r in ipairs(type(d.reasons) == 'table' and d.reasons or {}) do if VPO.Util.Contains(Cfg.Reasons, r) then reasons[#reasons + 1] = r end end
    if #tactics == 0 then return { error = L('uof_need_tactic') } end
    if #reasons == 0 then return { error = L('uof_need_reason') } end
    local narrative = VPO.Util.Trim(d.narrative, 3000)
    if not narrative or #narrative < 30 then return { error = L('uof_need_narrative') } end
    local values = { VPO.Util.Trim(d.subject, 120), VPO.Util.Trim(d.linked, 32), json.encode(tactics), json.encode(reasons),
        d.subjectInjured and 1 or 0, d.officerInjured and 1 or 0, narrative, VPO.Util.Trim(d.location, 160), os.time() }
    local id = tonumber(d.id)
    if id then
        local owner = MySQL.scalar.await("SELECT identifier FROM vpo_uof WHERE id = ? AND status = 'pending'", { id })
        if owner ~= o.identifier then return { error = L('uof_not_yours') } end
        values[#values + 1] = id
        MySQL.update.await([[UPDATE vpo_uof SET status = 'submitted', subject = COALESCE(?, subject), linked_ref = COALESCE(?, linked_ref), tactics = ?, reasons = ?,
            subject_injured = ?, officer_injured = ?, narrative = ?, location = ?, submitted_at = ? WHERE id = ?]], values)
    else
        table.insert(values, 1, label(o)); table.insert(values, 1, o.identifier)
        values[#values + 1] = os.time()
        id = MySQL.insert.await([[INSERT INTO vpo_uof (identifier, officer, status, subject, linked_ref, tactics, reasons, subject_injured, officer_injured, narrative, location, submitted_at, created_at)
            VALUES (?, ?, 'submitted', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)]], values)
    end
    VPO.Audit.Log({ action = 'uof.submit', actor = src, targetType = 'uof', targetId = id, new = { tactics = tactics, reasons = reasons } })
    return { ok = true }
end)

VPO.Duty.OnSignOff(function(src, session, gone)
    local n = MySQL.scalar.await("SELECT COUNT(*) FROM vpo_uof WHERE identifier = ? AND status = 'pending'", { session.identifier }) or 0
    if n > 0 and not gone then VPO.Notify(src, L('uof_outstanding', n), 'error', 10000) end
    return { uofPending = n }
end)

---------------------------------------------------------------------------
-- Complaints from the public
---------------------------------------------------------------------------
local lastComplaint = {}

local function findOfficer(text)
    text = VPO.Util.Trim(text, 60)
    if not text then return nil end
    local up = text:upper()
    local r = MySQL.single.await('SELECT identifier, display_name, collar_number FROM vpo_officers WHERE collar_number = ? OR UPPER(callsign) = ? LIMIT 1',
        { text:gsub('%D', ''), up })
    return r
end

VPO.Net.Callback('complaint:prepare', { rate = 'standards' }, function(src)
    return { ok = true, force = Config.Force.name, officer = { label = VPO.Bridge.GetName(src) or GetPlayerName(src) }, statuses = VPO.Hub.StatusList(),
        categories = Cfg.ComplaintCategories }
end)

VPO.Net.Callback('complaint:submit', { rate = 'standards' }, function(src, _, d)
    d = type(d) == 'table' and d or {}
    if lastComplaint[src] and os.time() - lastComplaint[src] < Cfg.ComplaintCooldown then return { error = L('complaint_wait') } end
    local details = VPO.Util.Trim(d.details, 3000)
    if not details or #details < 30 then return { error = L('complaint_need_details') } end
    local officer = findOfficer(d.officer)
    local t = os.time()
    local id = MySQL.insert.await([[INSERT INTO vpo_complaints (complainant, complainant_identifier, officer_text, officer_identifier, officer_name, happened, category, details, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)]],
        { VPO.Bridge.GetName(src) or GetPlayerName(src), VPO.Bridge.GetIdentifier(src), VPO.Util.Trim(d.officer, 120), officer and officer.identifier or nil,
          officer and officer.display_name or nil, VPO.Util.Trim(d.happened, 120),
          VPO.Util.Contains(Cfg.ComplaintCategories, d.category) and d.category or 'Other', details, t, t })
    if not id then return { error = L('qual_failed') } end
    local ref = ('PSD/%s/%s/%05d'):format(Config.Force.short, os.date('%y%m'), id)
    MySQL.update('UPDATE vpo_complaints SET ref = ? WHERE id = ?', { ref, id })
    lastComplaint[src] = t
    VPO.Audit.Log({ action = 'complaint.received', actor = src, source = 'player', targetType = 'complaint', targetId = ref })
    for s in pairs(VPO.Duty.All()) do
        if VPO.Permissions.Check(s, 'standards.view') then VPO.Notify(s, L('complaint_alert', ref), 'inform') end
    end
    return { ok = true, ref = ref }
end)

AddEventHandler('playerDropped', function() lastComplaint[source] = nil end)

---------------------------------------------------------------------------
-- Supervisors' panel
---------------------------------------------------------------------------
VPO.Net.Callback('standards:panel', { permission = 'standards.view', rate = 'standards' }, function(src, o)
    local out = VPO.Hub.Header(src, o)
    out.ok = true
    out.uof = {}
    for _, r in ipairs(MySQL.query.await("SELECT * FROM vpo_uof WHERE status = 'submitted' AND reviewed_at IS NULL ORDER BY id DESC LIMIT 40") or {}) do out.uof[#out.uof + 1] = uofView(r) end
    out.pendingForms = MySQL.query.await("SELECT officer, COUNT(*) n FROM vpo_uof WHERE status = 'pending' GROUP BY identifier, officer ORDER BY n DESC LIMIT 20") or {}
    out.discharges = VPO.Armoury.Discharges({ unreviewed = true })
    out.complaints = MySQL.query.await("SELECT * FROM vpo_complaints WHERE status IN ('Received', 'Under investigation') ORDER BY id DESC LIMIT 40") or {}
    out.complaintStatuses, out.dischargeOutcomes = Cfg.ComplaintStatuses, Cfg.DischargeOutcomes
    return out
end)

VPO.Net.Callback('standards:review', { permission = 'standards.view', rate = 'standards' }, function(src, o, d)
    d = type(d) == 'table' and d or {}
    local note = VPO.Util.Trim(d.note, 500)
    local by = label(o)
    if d.kind == 'uof' then
        local n = MySQL.update.await('UPDATE vpo_uof SET reviewed_by = ?, review_note = ?, reviewed_at = ? WHERE id = ? AND reviewed_at IS NULL', { by, note, os.time(), tonumber(d.id) })
        if not n or n == 0 then return { error = L('equipment_not_found') } end
    elseif d.kind == 'discharge' then
        if not VPO.Util.Contains(Cfg.DischargeOutcomes, d.outcome) then return { error = L('roads_pick_outcome') } end
        local n = MySQL.update.await('UPDATE vpo_discharges SET reviewed_by = ?, reviewed_at = ?, account = CONCAT(COALESCE(account, \'\'), ?) WHERE id = ? AND reviewed_at IS NULL',
            { by, os.time(), ('\n[Review: %s%s]'):format(d.outcome, note and (' - ' .. note) or ''), tonumber(d.id) })
        if not n or n == 0 then return { error = L('equipment_not_found') } end
    elseif d.kind == 'complaint' then
        if not VPO.Util.Contains(Cfg.ComplaintStatuses, d.status) then return { error = L('cid_bad_status') } end
        local c = MySQL.single.await('SELECT notes FROM vpo_complaints WHERE id = ?', { tonumber(d.id) })
        if not c then return { error = L('equipment_not_found') } end
        local notes = (c.notes and (c.notes .. '\n') or '') .. ('[%s] %s: %s%s'):format(os.date('%d/%m/%Y %H:%M'), by, d.status, note and (' - ' .. note) or '')
        MySQL.update.await('UPDATE vpo_complaints SET status = ?, investigator = COALESCE(investigator, ?), outcome = ?, notes = ?, updated_at = ? WHERE id = ?',
            { d.status, by, (d.status ~= 'Received' and d.status ~= 'Under investigation') and d.status or nil, notes, os.time(), tonumber(d.id) })
    else
        return { error = L('npc_custody_unknown') }
    end
    VPO.Audit.Log({ action = 'standards.review', actor = src, targetType = d.kind, targetId = d.id, new = { outcome = d.outcome or d.status }, reason = note })
    return { ok = true }
end)

--- Audit log search. q matches action, actor name, target id or reason.
VPO.Net.Callback('standards:audit', { permission = 'standards.view', rate = 'standards' }, function(src, o, d)
    d = type(d) == 'table' and d or {}
    local q = VPO.Util.Trim(d.q, 60)
    local where, args = {}, {}
    if q then
        local like = '%' .. q:gsub('[%%_]', '') .. '%'
        where[#where + 1] = '(action LIKE ? OR actor_name LIKE ? OR target_id LIKE ? OR reason LIKE ?)'
        args = { like, like, like, like }
    end
    if tonumber(d.beforeId) then where[#where + 1] = 'id < ?'; args[#args + 1] = tonumber(d.beforeId) end
    args[#args + 1] = 50
    local rows = MySQL.query.await('SELECT id, created_at, action, source, actor_name, target_type, target_id, reason FROM vpo_audit'
        .. (#where > 0 and (' WHERE ' .. table.concat(where, ' AND ')) or '') .. ' ORDER BY id DESC LIMIT ?', args) or {}
    VPO.Audit.Log({ action = 'audit.view', actor = src, reason = q })
    return { ok = true, rows = rows }
end)

--- One officer's record: forms, discharges, complaints, shifts.
VPO.Net.Callback('standards:officer', { permission = 'standards.view', rate = 'standards' }, function(src, o, d)
    local text = VPO.Util.Trim(type(d) == 'table' and d.q or nil, 60)
    if not text then return { error = L('standards_need_officer') } end
    local like = '%' .. text:gsub('[%%_]', '') .. '%'
    local off = MySQL.single.await('SELECT identifier, display_name, collar_number, callsign FROM vpo_officers WHERE collar_number = ? OR UPPER(callsign) = ? OR display_name LIKE ? LIMIT 1',
        { text, text:upper(), like })
    if not off then return { error = L('standards_no_officer') } end
    local id = off.identifier
    return { ok = true, officer = {
        name = off.display_name, collar = off.collar_number, callsign = off.callsign,
        qualifications = VPO.Qualifications.List(id),
        uof = MySQL.query.await('SELECT id, status, `trigger`, subject, tactics, created_at, reviewed_by FROM vpo_uof WHERE identifier = ? ORDER BY id DESC LIMIT 15', { id }) or {},
        discharges = MySQL.query.await('SELECT label, rounds, account, unaccounted, created_at, reviewed_by FROM vpo_discharges WHERE identifier = ? ORDER BY id DESC LIMIT 10', { id }) or {},
        complaints = MySQL.query.await('SELECT ref, category, status, created_at FROM vpo_complaints WHERE officer_identifier = ? ORDER BY id DESC LIMIT 10', { id }) or {},
        shifts = MySQL.query.await('SELECT callsign, unit, started_at, ended_at, end_reason FROM vpo_duty_sessions WHERE identifier = ? ORDER BY id DESC LIMIT 10', { id }) or {},
    } }
end)
