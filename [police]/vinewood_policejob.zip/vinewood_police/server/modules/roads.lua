-- Vehicle stops and roadside checks.
-- A stop is opened from a police vehicle (/stopvehicle) or at the roadside (the panel). One stop per
-- vehicle at a time; other officers who open the panel join it. Checks and tickets go through the MDT
-- when it's running (audited as the officer), otherwise straight to Licensing / Vehicle Services.
VPO.Roads = {}
local Roads = VPO.Roads
local Cfg = Config.Roads
local L = VPO.L

local stops = {}     -- [id] = stop
local byVehicle = {} -- [netId] = id

---------------------------------------------------------------------------
-- Helpers
---------------------------------------------------------------------------
local function ped(src)
    local p = GetPlayerPed(src)
    return (p and p ~= 0 and DoesEntityExist(p)) and p or nil
end

local function cleanPlate(p) return (tostring(p or ''):upper():gsub('^%s+', ''):gsub('%s+$', '')) end

local function vehicleFromNet(net)
    net = tonumber(net)
    local veh = net and NetworkGetEntityFromNetworkId(net) or 0
    if not veh or veh == 0 or not DoesEntityExist(veh) or GetEntityType(veh) ~= 2 then return nil end
    return veh, net
end

local function distTo(src, ent)
    local p = ped(src)
    if not p or not ent then return math.huge end
    return #(GetEntityCoords(p) - GetEntityCoords(ent))
end

local function coordsOf(ent)
    local c = GetEntityCoords(ent)
    return { x = math.floor(c.x * 10) / 10, y = math.floor(c.y * 10) / 10, z = math.floor(c.z * 10) / 10 }
end

--- Server id of the player in a seat, or nil.
local function playerInSeat(veh, seat)
    local p = GetPedInVehicleSeat(veh, seat)
    if not p or p == 0 then return nil, false end
    for _, id in ipairs(GetPlayers()) do
        local src = tonumber(id)
        if GetPlayerPed(src) == p then return src, true end
    end
    return nil, true -- someone is there, but not a player
end

local function mdt()
    local a = VPO.Integrations.Get('mdt')
    return a and a.canWrite and a or nil
end

local function mdtRequest(src, action, data)
    local res, err = VPO.Integrations.Call('mdt', 'Request', src, action, data)
    if type(res) ~= 'table' then return { error = L('mdt_no_answer', tostring(err or '?')) } end
    return res
end

local function fineList()
    local m = mdt()
    local o = m and m.GetFormOptions and m.GetFormOptions() or nil
    if o and o.fines then
        if o.fines.enabled == false then return nil end
        return o.fines.offences or {}, o.fines.currency or Cfg.Currency, 'mdt'
    end
    if m then return nil end -- an older MDT without the list: tickets are issued in the MDT itself
    return Cfg.Offences, Cfg.Currency, 'local'
end

---------------------------------------------------------------------------
-- Checks (common shape whichever source answers)
---------------------------------------------------------------------------
-- vehicle = { plate, registered, model, keeper = { name, licence, points, wanted }, insurance, mot, tax,
--             flags = { { label, level } }, markers = { label }, source }
local INS = { insured = 'Insured', void = 'Not insured (keeper changed)', expired = 'Insurance expired', none = 'No insurance', exempt = 'Exempt' }
local MOT = { valid = 'Valid', dangerous = 'Failed, dangerous defects', expired = 'Expired', failed = 'Failed', none = 'No MOT', exempt = 'Exempt' }
local VED = { taxed = 'Taxed', sorn = 'SORN', untaxed = 'Untaxed', none = 'Untaxed', exempt = 'Exempt' }

local function statusRows(mid, mot, ved)
    local out = {}
    if mid then
        out.insurance = { status = mid.status, text = INS[mid.status] or mid.status, ok = mid.status == 'insured' or mid.status == 'exempt',
            detail = mid.policyNo and ('%s, %s, %s %s'):format(mid.coverLabel or 'Policy', mid.holder or '?', mid.status == 'insured' and 'expires' or 'expired', mid.expires or '?') or nil }
    end
    if mot then
        out.mot = { status = mot.status, text = MOT[mot.status] or mot.status, ok = mot.status == 'valid' or mot.status == 'exempt',
            detail = mot.expires and ('Expiry ' .. mot.expires) or nil }
    end
    if ved then
        out.tax = { status = ved.status, text = VED[ved.status] or ved.status, ok = ved.status == 'taxed' or ved.status == 'exempt',
            detail = ved.status == 'taxed' and ved.expires and ('Until ' .. ved.expires) or (ved.status == 'sorn' and ved.since and ('Since ' .. ved.since)) or nil }
    end
    return out
end

local function vehicleCheck(src, plate)
    if mdt() then
        local res = mdtRequest(src, 'getVehicle', { plate = plate })
        if res.error then
            -- Not registered to anyone in the city
            local out = { plate = plate, registered = false, source = 'mdt', flags = {}, markers = {} }
            local vs = VPO.Integrations.Get('vehicleservices')
            if vs then
                local ok, s = pcall(vs.Status, plate)
                if ok and s then for k, v in pairs(statusRows(s.insurance, s.mot, s.tax)) do out[k] = v end end
            end
            return out
        end
        local v = res.vehicle or {}
        -- Insurance, MOT and tax have their own rows, so only ANPR entries go in the flags.
        local out = { plate = v.plate or plate, registered = true, model = v.model, source = 'mdt', flags = {}, markers = {} }
        for _, m in ipairs(v.markers or {}) do out.markers[#out.markers + 1] = m.marker .. (m.note and (': ' .. m.note) or '') end
        for _, a in ipairs(v.anpr or {}) do out.flags[#out.flags + 1] = { label = 'ANPR: ' .. (a.reason or 'marker'), level = 'red' } end
        if v.keeper then
            out.keeper = { name = v.keeper.name, licence = v.keeperLicence, points = v.keeperPoints, wanted = v.keeperWanted, bail = v.keeperBail ~= nil }
        end
        for k, val in pairs(statusRows(v.mid, v.mot, v.ved)) do out[k] = val end
        return out
    end

    local reg = VPO.Bridge.GetVehicleByPlate(plate)
    local out = { plate = reg and reg.plate or plate, registered = reg ~= nil, model = reg and reg.model, source = 'direct', flags = {}, markers = {} }
    if reg and reg.owner then
        out.keeper = { name = VPO.Bridge.GetNameByIdentifier(reg.owner) or 'Unknown' }
        local lic = VPO.Integrations.Get('licensing')
        if lic then
            local ok, s = pcall(lic.Summary, reg.owner)
            if ok and s then out.keeper.licence, out.keeper.points = s.status, s.points end
        end
    end
    local vs = VPO.Integrations.Get('vehicleservices')
    if vs then
        local ok, s = pcall(vs.Status, out.plate)
        if ok and s then
            for k, val in pairs(statusRows(s.insurance, s.mot, s.tax)) do out[k] = val end
        end
    end
    if not reg then out.flags[#out.flags + 1] = { label = 'No registered keeper', level = 'amber' } end
    return out
end

-- driver = { name, licence ('valid'|'provisional'|'disqualified'|'none'), categories, points, insured, wanted, bail, source }
local function driverCheck(src, plate, target)
    local cid = VPO.Bridge.GetIdentifier(target)
    if not cid then return { error = L('restraint_no_target') } end
    if mdt() then
        local res = mdtRequest(src, 'checkDriver', { plate = plate, cid = cid })
        if res.error then return res end
        local out = { name = res.name, licence = res.licence, points = res.points, insured = res.insured, wanted = res.wanted,
            bail = res.bail ~= nil, bailConditions = type(res.bail) == 'table' and (res.bail.conditions or res.bail.condition) or nil, source = 'mdt' }
        local lic = VPO.Integrations.Get('licensing')
        if lic then
            local ok, s = pcall(lic.Summary, target)
            if ok and s then out.categories, out.ban = s.categories, s.ban end
        end
        return out
    end
    local out = { name = VPO.Bridge.GetName(target), source = 'direct' }
    local lic = VPO.Integrations.Get('licensing')
    if lic then
        local ok, s = pcall(lic.Summary, target)
        if ok and s then out.licence, out.categories, out.points, out.ban = s.status, s.categories, s.points, s.ban end
    end
    local vs = VPO.Integrations.Get('vehicleservices')
    if vs then
        local ok, ins = pcall(vs.InsuredToDrive, plate, cid)
        if ok then out.insured = ins end
    end
    return out
end

---------------------------------------------------------------------------
-- Stops
---------------------------------------------------------------------------
local function newStop(src, o, veh, net, reason, location)
    local plate = cleanPlate(GetVehicleNumberPlateText(veh))
    local driver = playerInSeat(veh, -1)
    local t = os.time()
    local id = MySQL.insert.await([[INSERT INTO vpo_traffic_stops (plate, model, driver_identifier, driver_name, reason, location, coords,
        officer_identifier, officer_name, started_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)]],
        { plate, tostring(GetEntityModel(veh)), driver and VPO.Bridge.GetIdentifier(driver) or nil, driver and VPO.Bridge.GetName(driver) or nil,
          reason, location, json.encode(coordsOf(veh)), o.identifier, VPO.Officers.Label(o), t })
    if not id then return nil end
    local ref = ('VS/%s/%s/%05d'):format(Config.Force.short, os.date('%y%m'), id)
    MySQL.update('UPDATE vpo_traffic_stops SET ref = ? WHERE id = ?', { ref, id })
    local s = {
        id = id, ref = ref, net = net, plate = plate, officer = src, officers = { [src] = true }, driver = driver,
        reason = reason, location = location, startedAt = t, lastActive = t, checks = {}, tickets = {},
    }
    stops[id], byVehicle[net] = s, id
    VPO.Duty.AddStat(src, 'trafficStops', 1)
    return s
end

local closeCbs = {}
--- cb(stop, outcome) when a stop ends (NPC stops release or remove their NPC here).
function Roads.OnClose(cb) closeCbs[#closeCbs + 1] = cb end

function Roads.Close(id, outcome, notes, by)
    local s = stops[id]
    if not s then return end
    stops[id] = nil
    for _, cb in ipairs(closeCbs) do
        local ok, err = pcall(cb, s, outcome)
        if not ok then VPO.Log.error('stop close handler failed: %s', err) end
    end
    if byVehicle[s.net] == id then byVehicle[s.net] = nil end
    MySQL.update('UPDATE vpo_traffic_stops SET outcome = ?, notes = ?, reason = ?, npc = ?, driver_identifier = COALESCE(?, driver_identifier), driver_name = COALESCE(?, driver_name), checks = ?, tickets = ?, ended_at = ? WHERE id = ?',
        { outcome, notes, s.reason, s.npc and 1 or 0, s.driverIdentifier, s.driverName, json.encode(s.checks), json.encode(s.tickets), os.time(), id })
    VPO.Audit.Log({ action = 'roads.stop', actor = by, targetType = 'vehicle', targetId = s.plate,
        new = { ref = s.ref, outcome = outcome, tickets = #s.tickets }, reason = s.reason })
end

local function stopForVehicle(net)
    local id = byVehicle[net]
    return id and stops[id] or nil
end

--- People who could be the driver: whoever is in the driver's seat, the driver when the stop began,
--- and anyone else near the vehicle who isn't an on-duty officer.
local function candidates(s, veh)
    local seen, out = {}, {}
    local function add(src, note)
        if not src or seen[src] or not GetPlayerName(src) then return end
        if VPO.IsOnDuty(src) == true then return end
        seen[src] = true
        out[#out + 1] = { src = src, name = VPO.Bridge.GetName(src) or GetPlayerName(src), note = note }
    end
    add((playerInSeat(veh, -1)), L('roads_in_driver_seat'))
    add(s.driver, L('roads_was_driving'))
    local vc = GetEntityCoords(veh)
    for _, id in ipairs(GetPlayers()) do
        local src = tonumber(id)
        local p = ped(src)
        if p and #(GetEntityCoords(p) - vc) <= Cfg.DriverRange then add(src, nil) end
    end
    return out
end

---------------------------------------------------------------------------
-- Start a stop from a police vehicle
---------------------------------------------------------------------------
VPO.Net.Callback('roads:initiate', { permission = 'roads.stop', rate = 'roads' }, function(src, o, d)
    d = type(d) == 'table' and d or {}
    local veh, net = vehicleFromNet(d.net)
    if not veh then return { error = L('restraint_no_vehicle') } end
    local myPed = ped(src)
    local mine = myPed and GetVehiclePedIsIn(myPed, false) or 0
    if mine == 0 or GetPedInVehicleSeat(mine, -1) ~= myPed then return { error = L('roads_must_drive') } end
    if mine == veh then return { error = L('restraint_no_vehicle') } end
    if distTo(src, veh) > Cfg.StopRange + 15.0 then return { error = L('roads_too_far') } end

    local driver, occupied = playerInSeat(veh, -1)
    if not occupied then return { error = L('roads_no_driver') } end

    local s = stopForVehicle(net)
    if s then return { error = L('roads_already_stopped', s.ref) } end
    if not driver then return VPO.NpcStops.Begin(src, o, veh, net, VPO.Util.Trim(d.location, 160)) end
    s = newStop(src, o, veh, net, nil, VPO.Util.Trim(d.location, 160))
    if not s then return { error = L('qual_failed') } end

    TriggerClientEvent('vinewood_police:client:notice', driver, {
        title = L('roads_notice_title'), from = VPO.Officers.Label(o), text = L('roads_notice_text'),
    })
    TriggerClientEvent('vinewood_police:client:roads:signal', driver, net)
    return { ok = true, ref = s.ref, plate = s.plate }
end)

---------------------------------------------------------------------------
-- Roadside panel
---------------------------------------------------------------------------
local function publicStop(s)
    return { id = s.id, ref = s.ref, plate = s.plate, reason = s.reason, startedAt = s.startedAt, tickets = s.tickets,
        officer = VPO.Officers.Label(VPO.Officers.Get(s.officer) or {}) }
end

VPO.Net.Callback('roads:open', { permission = 'roads.stop', rate = 'roads' }, function(src, o, d)
    d = type(d) == 'table' and d or {}
    local veh, net = vehicleFromNet(d.net)
    if not veh then return { error = L('restraint_no_vehicle') } end
    local s = stopForVehicle(net)
    local near = distTo(src, veh) <= Cfg.PanelDistance or (s and s.npc and VPO.NpcStops.NearPed(src, s))
    if not near then return { error = L('restraint_vehicle_far') } end

    if not s then
        local driver, occupied = playerInSeat(veh, -1)
        if occupied and not driver then
            -- Walked up to an NPC's car without stopping it first: start an NPC stop here.
            local res = VPO.NpcStops.Begin(src, o, veh, net, VPO.Util.Trim(d.location, 160))
            if res.error then return res end
            s = stopForVehicle(net)
            if not s then return { error = L('qual_failed') } end
        else
            s = newStop(src, o, veh, net, nil, VPO.Util.Trim(d.location, 160))
            if not s then return { error = L('qual_failed') } end
        end
    end
    s.officers[src] = true
    s.lastActive = os.time()

    local vehicle = s.npc and VPO.NpcStops.VehicleView(s) or vehicleCheck(src, s.plate)
    s.checks.vehicle = { at = os.time(), by = VPO.Officers.Label(o), flags = #(vehicle.flags or {}) }

    local fines, currency, finesSource = fineList()
    if s.npc and not fines then fines, currency, finesSource = Cfg.Offences, Cfg.Currency, 'local' end
    local out = VPO.Hub.Header(src, o)
    out.ok = true
    out.stop = publicStop(s)
    out.vehicle = vehicle
    out.candidates = s.npc and {} or candidates(s, veh)
    out.npc = s.npc and VPO.NpcStops.PanelData(s) or nil
    out.seizurePowers = Cfg.Seizure.Powers
    out.seizure = s.seizure
    out.tests = s.checks.tests or {}
    out.canSeize = VPO.Permissions.Check(src, 'roads.seize') == true
    out.oxInventory = GetResourceState('ox_inventory') == 'started'
    out.reasons, out.outcomes = Cfg.Reasons, Cfg.Outcomes
    out.fines = fines
    out.currency = currency
    out.finesSource = finesSource
    out.mdt = mdt() ~= nil
    out.licensing = VPO.Integrations.Available('licensing')
    out.vehicleServices = VPO.Integrations.Available('vehicleservices')
    return out
end)

local function ownStop(src, d)
    local s = stops[tonumber(type(d) == 'table' and d.stop or nil) or 0]
    if not s then return nil, L('roads_no_stop') end
    if not s.officers[src] then return nil, L('roads_not_your_stop') end
    local veh = vehicleFromNet(s.net)
    local far = veh and distTo(src, veh) > Cfg.PanelDistance + 25.0
    if far and not (s.npc and VPO.NpcStops.NearPed(src, s)) then return nil, L('restraint_vehicle_far') end
    s.lastActive = os.time()
    return s
end

VPO.Net.Callback('roads:checkDriver', { permission = 'roads.stop', rate = 'roads' }, function(src, o, d)
    local s, err = ownStop(src, d)
    if not s then return { error = err } end
    local target = tonumber(d.target)
    if not target or not GetPlayerName(target) then return { error = L('restraint_no_target') } end
    local veh = vehicleFromNet(s.net)
    if not veh or distTo(target, veh) > Cfg.DriverRange + 5.0 then return { error = L('roads_driver_far') } end
    local res = driverCheck(src, s.plate, target)
    if res.error then return res end
    s.driverSrc = target
    s.driverIdentifier = VPO.Bridge.GetIdentifier(target)
    s.driverName = res.name
    s.checks.driver = { at = os.time(), by = VPO.Officers.Label(o), licence = res.licence, insured = res.insured, wanted = res.wanted }
    return { ok = true, driver = res }
end)

VPO.Net.Callback('roads:reason', { permission = 'roads.stop', rate = 'roads' }, function(src, _, d)
    local s, err = ownStop(src, d)
    if not s then return { error = err } end
    if not VPO.Util.Contains(Cfg.Reasons, d.reason) then return { error = L('roads_pick_reason') } end
    s.reason = d.reason
    return { ok = true }
end)

---------------------------------------------------------------------------
-- Tickets
---------------------------------------------------------------------------
VPO.Net.Callback('roads:ticket', { permission = 'roads.ticket', rate = 'roads' }, function(src, o, d)
    local s, err = ownStop(src, d)
    if not s then return { error = err } end
    if s.npc then
        if not s.npc.given then return { error = L('npc_need_details') } end
    elseif not s.driverSrc or not s.driverIdentifier then return { error = L('roads_check_driver_first') } end
    local fines, currency, source = fineList()
    if not fines and s.npc then fines, currency, source = Cfg.Offences, Cfg.Currency, 'local' end
    if not fines then return { error = L('roads_tickets_off') } end
    local kind = (d.kind == 'TOR') and 'TOR' or 'FPN'

    if source == 'mdt' and not s.npc then
        local res = mdtRequest(src, 'issueFine', {
            cid = s.driverIdentifier, type = kind, codes = type(d.codes) == 'table' and d.codes or {}, other = VPO.Util.Trim(d.other, 160),
            plate = s.plate, location = s.location, notes = VPO.Util.Trim(d.notes, 1000),
        })
        if res.error then return res end
        s.tickets[#s.tickets + 1] = { ref = res.ref, kind = kind, amount = res.amount }
        return { ok = true, ref = res.ref, amount = res.amount, endorsed = res.endorsed or {}, currency = currency }
    end

    -- Local ticket (no MDT): record it and endorse through vinewood_licensing.
    local list, amount, points = {}, 0, 0
    for _, code in ipairs(type(d.codes) == 'table' and d.codes or {}) do
        for _, f in ipairs(fines) do
            if f.code == code and (kind == 'TOR' or f.type == kind) then
                list[#list + 1] = { code = f.code, label = f.label, amount = f.amount, points = f.points or 0 }
                amount, points = amount + (f.amount or 0), points + (f.points or 0)
            end
        end
    end
    local other = VPO.Util.Trim(d.other, 160)
    if kind == 'TOR' and other then list[#list + 1] = { code = 'TOR', label = other, amount = 0, points = 0 } end
    if #list == 0 then return { error = L('roads_pick_offence') } end
    if kind == 'TOR' then amount, points = 0, 0 end

    local n = #s.tickets + 1
    local ref = ('%s/%s/%s/%05d-%d'):format(kind, Config.Force.short, os.date('%y%m'), s.id, n)
    local endorsed = {}
    local lic = VPO.Integrations.Get('licensing')
    if s.npc then
        -- NPCs: the ticket goes to the name they gave; points go on the record that name belongs to.
        VPO.NpcStops.Ticketed(s, kind, list, points)
        s.tickets[#s.tickets + 1] = { ref = ref, kind = kind, amount = amount, offences = list, to = s.npc.given.name }
        VPO.Audit.Log({ action = 'roads.ticket', actor = src, targetType = 'npc', targetId = s.npc.given.name,
            new = { ref = ref, kind = kind, offences = list, amount = amount, points = points } })
        return { ok = true, ref = ref, amount = amount, endorsed = {}, currency = currency }
    end
    if kind == 'FPN' then
        for _, f in ipairs(list) do
            if f.points > 0 then
                if lic then
                    -- AddPoints returns ok, total, autoBanned, status ('queued' if they went offline)
                    local pok, ok, _, banned, status = pcall(lic.AddPoints, s.driverIdentifier, f.points, f.code, f.label, VPO.Officers.Label(o))
                    endorsed[#endorsed + 1] = (pok and ok) and L('roads_endorsed', f.code, f.points, status == 'queued' and L('roads_queued') or '')
                        or L('roads_not_endorsed', f.code)
                    if pok and banned == true then endorsed[#endorsed + 1] = L('roads_totting') end
                else
                    endorsed[#endorsed + 1] = L('roads_no_licensing', f.code)
                end
            end
        end
    end
    s.tickets[#s.tickets + 1] = { ref = ref, kind = kind, amount = amount, offences = list }
    VPO.Audit.Log({ action = 'roads.ticket', actor = src, targetType = 'player', targetId = s.driverIdentifier,
        new = { ref = ref, kind = kind, offences = list, amount = amount, points = points } })
    if GetPlayerName(s.driverSrc) then
        VPO.Documents.Give(s.driverSrc, {
            title = kind == 'TOR' and L('roads_tor_title') or L('roads_fpn_title'), from = VPO.Officers.Label(o), ref = ref,
            text = L('roads_ticket_text', ref, (function() local t = {} for _, f in ipairs(list) do t[#t + 1] = f.code .. ' ' .. f.label end return table.concat(t, '\n') end)(),
                kind == 'TOR' and L('roads_tor_court') or L('roads_fpn_amount', currency, amount, points)),
        })
    end
    return { ok = true, ref = ref, amount = amount, endorsed = endorsed, currency = currency }
end)

VPO.Net.Callback('roads:close', { permission = 'roads.stop', rate = 'roads' }, function(src, _, d)
    local s, err = ownStop(src, d)
    if not s then return { error = err } end
    if not VPO.Util.Contains(Cfg.Outcomes, d.outcome) then return { error = L('roads_pick_outcome') } end
    if d.reason and VPO.Util.Contains(Cfg.Reasons, d.reason) then s.reason = d.reason end
    if not s.reason then return { error = L('roads_pick_reason') } end
    Roads.Close(s.id, d.outcome, VPO.Util.Trim(d.notes, 1000), src)
    return { ok = true, ref = s.ref }
end)

---------------------------------------------------------------------------
-- Shared with the NPC module
---------------------------------------------------------------------------
Roads.NewStop = newStop
Roads.ForVehicle = stopForVehicle
Roads.Own = ownStop
Roads.All = function() return stops end
Roads.VehicleFromNet = vehicleFromNet
Roads.StatusRows = statusRows
Roads.DistTo = distTo

---------------------------------------------------------------------------
-- Housekeeping
---------------------------------------------------------------------------
CreateThread(function()
    while true do
        Wait(60000)
        local now = os.time()
        for id, s in pairs(stops) do
            local veh = vehicleFromNet(s.net)
            -- A seized vehicle is taken away before the stop is finished, so that alone doesn't close it.
            if now - s.lastActive > Cfg.StopTimeout * 60 or (not veh and not s.seizure) then
                Roads.Close(id, s.outcome or 'Not recorded', nil, nil)
            end
        end
    end
end)

AddEventHandler('playerDropped', function()
    local src = source
    for _, s in pairs(stops) do
        s.officers[src] = nil
        if s.driverSrc == src then s.driverSrc = nil end
    end
end)
