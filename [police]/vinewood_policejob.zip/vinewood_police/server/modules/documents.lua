-- Paper documents and usable items: the police notice (read it again by using it) and the handcuffs.
VPO.Documents = {}
local L = VPO.L

--- Shows a notice and hands over the paper copy. n = { title, text, from, ref }
function VPO.Documents.Give(src, n)
    TriggerClientEvent('vinewood_police:client:notice', src, { title = n.title, text = n.text, from = n.from })
    if not Config.NoticeItem then return end
    local meta = {
        title = n.title, text = n.text, from = n.from, ref = n.ref, issued = os.date('%d/%m/%Y %H:%M'),
        description = ('%s%s, %s'):format(n.title or 'Notice', n.ref and (' ' .. n.ref) or '', os.date('%d/%m/%Y %H:%M')),
    }
    local ok = pcall(VPO.Inventory.Add, src, Config.NoticeItem, 1, meta)
    if not ok then VPO.Log.debug('Could not give %s', Config.NoticeItem) end
end

local function readNotice(src, meta)
    if type(meta) ~= 'table' or not meta.text then return VPO.Notify(src, L('notice_unreadable'), 'error') end
    TriggerClientEvent('vinewood_police:client:notice', src, { title = meta.title, text = meta.text, from = meta.from })
end

local function cuffsOut(src)
    if VPO.IsOnDuty(src) ~= true then return VPO.Notify(src, L('perm_off_duty'), 'error') end
    TriggerClientEvent('vinewood_police:client:cuffsOut', src)
end

local USES = {}
if Config.NoticeItem then USES[Config.NoticeItem] = readNotice end
local hc = Config.Restraint.HandcuffsItem
if hc and hc.Item then USES[hc.Item] = function(src) cuffsOut(src) end end

-- ox_inventory: items use server = { export = 'vinewood_police.useItem' } (see docs/ITEMS.md)
exports('useItem', function(event, item, inventory, slot)
    if event ~= 'usingItem' then return end
    local fn = USES[item and item.name]
    if not fn then return end
    local s = exports.ox_inventory:GetSlot(inventory.id, slot)
    fn(inventory.id, s and s.metadata or {})
    return false -- using them doesn't use them up
end)

-- qb-inventory and ESX inventories: the framework's usable items
AddEventHandler(VPO.Events.ready, function()
    if VPO.Inventory.Name == 'ox' then return end
    local fw = VPO.Bridge.Name
    for name, fn in pairs(USES) do
        local ok, err = pcall(function()
            local core = VPO.Bridge.Resource -- Qbox can live in a folder called qb-core
            if fw == 'qbox' then
                exports[core]:CreateUseableItem(name, function(src, item) fn(src, item and (item.metadata or item.info) or {}) end)
            elseif fw == 'qbcore' then
                exports[core]:GetCoreObject().Functions.CreateUseableItem(name, function(src, item) fn(src, item and item.info or {}) end)
            elseif fw == 'esx' then
                exports.es_extended:getSharedObject().RegisterUsableItem(name, function(src, _, item) fn(src, item and (item.metadata or item.info) or {}) end)
            end
        end)
        if not ok then VPO.Log.warn('Could not register usable item %s: %s', name, tostring(err)) end
    end
end)
