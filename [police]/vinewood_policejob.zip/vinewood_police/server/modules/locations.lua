-- In-game location editor (admins). Stations, custody suites, callout locations and no-hostile zones can be
-- set where you stand. Saved places override the config (which stays as the default to reset to), apply at
-- once on the server and on every client, and survive restarts.
VPO.Locations = {}
local LC = VPO.Loc
local L = VPO.L
local defaults = {} -- plain copies of the config, for "reset"
for key, k in pairs(LC.Keys) do defaults[key] = LC.Plain(k.get()) end

local function publish()
    local all = {}
    for key, k in pairs(LC.Keys) do all[key] = LC.Plain(k.get()) end
    GlobalState.vpo_locations = all
end

---------------------------------------------------------------------------
-- Checking what the editor sends
---------------------------------------------------------------------------
local function num(v, max)
    v = tonumber(v)
    if not v or v ~= v or math.abs(v) > (max or 20000) then return nil end
    return math.floor(v * 1000 + 0.5) / 1000
end

local function point(t, heading)
    if type(t) ~= 'table' then return nil end
    local x, y, z = num(t.x), num(t.y), num(t.z)
    if not x or not y or not z then return nil end
    local p = { x = x, y = y, z = z }
    if heading then p.w = (num(t.w, 3600) or 0.0) % 360.0 end
    return p
end

local function text(v, max) return VPO.Util.Trim(type(v) == 'string' and v or nil, max or 64) end

local function slug(v, fallback)
    local s = tostring(v or ''):lower():gsub('[^%w]+', '_'):gsub('^_+', ''):gsub('_+$', '')
    return s ~= '' and s:sub(1, 32) or fallback
end

local function box(t, defaultSize)
    if type(t) ~= 'table' then return nil end
    local c = point(t.coords)
    if not c then return nil end
    local size = point(t.size) or defaultSize
    size.x, size.y, size.z = math.min(math.max(size.x, 0.5), 10), math.min(math.max(size.y, 0.5), 10), math.min(math.max(size.z, 0.5), 10)
    return { coords = c, size = size, rotation = (num(t.rotation, 3600) or 0.0) % 360.0 }
end

local CHECK = {}

function CHECK.stations(data)
    local out, ids = {}, {}
    for i, st in ipairs(type(data) == 'table' and data or {}) do
        local label = text(st.label) or ('Station ' .. i)
        local id = slug(st.id or label, 'station_' .. i)
        if ids[id] then return nil, L('loc_duplicate', id) end
        ids[id] = true
        local s = { id = id, label = label, lockers = {} }
        if st.signOn then
            s.signOn = box(st.signOn, { x = 1.6, y = 1.0, z = 2.0 })
            if not s.signOn then return nil, L('loc_bad_point', label) end
        end
        for _, l in ipairs(type(st.lockers) == 'table' and st.lockers or {}) do
            local b = box(l, { x = 2.0, y = 1.0, z = 2.0 })
            if not b then return nil, L('loc_bad_point', label) end
            s.lockers[#s.lockers + 1] = b
        end
        s.changingRooms = {}
        for _, a in ipairs(type(st.changingRooms) == 'table' and st.changingRooms or {}) do
            local b = box(a, { x = 2.0, y = 2.0, z = 2.0 })
            if not b then return nil, L('loc_bad_point', label) end
            s.changingRooms[#s.changingRooms + 1] = b
        end
        s.armouries = {}
        for _, a in ipairs(type(st.armouries) == 'table' and st.armouries or {}) do
            local b = box(a, { x = 2.0, y = 1.2, z = 2.0 })
            if not b then return nil, L('loc_bad_point', label) end
            s.armouries[#s.armouries + 1] = b
        end
        out[#out + 1] = s
    end
    return out
end

function CHECK.custody(data)
    local out, ids = {}, {}
    for i, su in ipairs(type(data) == 'table' and data or {}) do
        local label = text(su.label) or ('Custody suite ' .. i)
        local id = slug(su.id or label, 'suite_' .. i)
        if ids[id] then return nil, L('loc_duplicate', id) end
        ids[id] = true
        local desk = box(su.desk, { x = 2.0, y = 1.2, z = 2.0 })
        local release = point(su.release, true)
        if not desk or not release then return nil, L('loc_suite_needs', label) end
        local s = { id = id, label = label, desk = desk, release = release, cells = {}, cameras = {} }
        for k, cam in ipairs(type(su.cameras) == 'table' and su.cameras or {}) do
            local cp = point(cam.coords)
            local rot = type(cam.rot) == 'table' and cam.rot or {}
            if cp then
                s.cameras[#s.cameras + 1] = { id = text(cam.id, 16) or ('K' .. k), label = text(cam.label, 40) or ('Camera ' .. k), cell = text(cam.cell, 16),
                    coords = cp, rot = { x = num(rot.x, 360) or 0.0, y = 0.0, z = num(rot.z, 3600) or 0.0 }, fov = math.min(math.max(num(cam.fov, 200) or 50.0, 10.0), 100.0) }
            end
        end
        local cellIds = {}
        for j, c in ipairs(type(su.cells) == 'table' and su.cells or {}) do
            local cid = text(c.id, 16) or ('C' .. j)
            if cellIds[cid] then return nil, L('loc_duplicate', cid) end
            cellIds[cid] = true
            local p = point(c.coords, true)
            if not p then return nil, L('loc_bad_point', label) end
            local cellOut = { id = cid, label = text(c.label, 32) or ('Cell ' .. j), coords = p }
            if type(c.door) == 'table' and tonumber(c.door.model) and point(c.door.coords) then
                cellOut.door = { model = math.floor(tonumber(c.door.model)), coords = point(c.door.coords) }
            end
            s.cells[#s.cells + 1] = cellOut
        end
        out[#out + 1] = s
    end
    return out
end

function CHECK.callouts(data)
    if type(data) ~= 'table' then return nil, L('loc_bad_data') end
    local out = {}
    for pool in pairs(defaults.callouts or {}) do
        out[pool] = {}
        for _, loc in ipairs(type(data[pool]) == 'table' and data[pool] or {}) do
            local p = point(loc.coords, true)
            if not p then return nil, L('loc_bad_point', pool) end
            out[pool][#out[pool] + 1] = { label = text(loc.label, 80) or 'Location', coords = p }
        end
    end
    return out
end

local function pieces(list, maxId)
    local out = {}
    for _, p in ipairs(type(list) == 'table' and list or {}) do
        local id, d, t = tonumber(p.id), tonumber(p.d), tonumber(p.t)
        if id and d and id >= 0 and id <= maxId and d >= -1 and d < 10000 then
            out[#out + 1] = { id = math.floor(id), d = math.floor(d), t = math.floor(t or 0) }
        end
    end
    return out
end

function CHECK.uniforms(data)
    local out, ids = {}, {}
    local units = {}
    for _, u in ipairs(Config.Duty.UnitTypes) do units[u.id] = true end
    for i, u in ipairs(type(data) == 'table' and data or {}) do
        local label = text(u.label, 48) or ('Uniform ' .. i)
        local id = slug(u.id or label, 'uniform_' .. i)
        if ids[id] then return nil, L('loc_duplicate', id) end
        ids[id] = true
        local x = { id = id, label = label }
        if u.minRank and u.minRank ~= '' then
            if not VPO.Ranks.Get(u.minRank) then return nil, L('loc_bad_data') end
            x.minRank = u.minRank
        end
        if type(u.units) == 'table' and #u.units > 0 then
            x.units = {}
            for _, un in ipairs(u.units) do if units[un] then x.units[#x.units + 1] = un end end
            if #x.units == 0 then x.units = nil end
        end
        for _, sex in ipairs({ 'male', 'female' }) do
            if type(u[sex]) == 'table' then
                local c = pieces(u[sex].components, 11)
                if #c > 0 then x[sex] = { components = c, props = pieces(u[sex].props, 7) } end
            end
        end
        if not x.male and not x.female then return nil, L('uniform_needs_clothes', label) end
        out[#out + 1] = x
    end
    return out
end

function CHECK.hostileZones(data)
    local out = {}
    for _, z in ipairs(type(data) == 'table' and data or {}) do
        local p = point(z.coords)
        if not p then return nil, L('loc_bad_data') end
        out[#out + 1] = { label = text(z.label, 64), coords = p, radius = math.min(math.max(num(z.radius, 2000) or 100.0, 10.0), 1500.0) }
    end
    return out
end

---------------------------------------------------------------------------
-- Loading, saving, resetting
---------------------------------------------------------------------------
AddEventHandler(VPO.Events.ready, function()
    for _, r in ipairs(MySQL.query.await('SELECT `key`, data FROM vpo_locations') or {}) do
        local ok, data = pcall(json.decode, r.data)
        if ok and LC.Keys[r.key] then
            LC.Apply(r.key, data)
            VPO.Log.info('Using in-game locations for %s', r.key)
        end
    end
    publish()
end)

local function admin(src)
    if not VPO.Permissions.IsAdmin(src) then return false end
    return true
end

VPO.Net.Callback('loc:get', { rate = 'custody' }, function(src, o, d)
    if not admin(src) then return { error = L('admin_needs_ace') } end
    local out = o and VPO.Hub.Header(src, o) or { force = Config.Force.name, officer = { label = GetPlayerName(src) }, statuses = VPO.Hub.StatusList() }
    out.ok = true
    out.locations = {}
    for key, k in pairs(LC.Keys) do out.locations[key] = LC.Plain(k.get()) end
    out.section = type(d) == 'table' and (d.section or (type(d.target) == 'string' and d.target)) or nil
    out.ranks, out.units = {}, {}
    for _, r in ipairs(Config.Ranks) do out.ranks[#out.ranks + 1] = { id = r.id, label = r.label } end
    for _, u in ipairs(Config.Duty.UnitTypes) do out.units[#out.units + 1] = { id = u.id, label = u.label } end
    out.saved = {}
    for _, r in ipairs(MySQL.query.await('SELECT `key`, updated_at, updated_by FROM vpo_locations') or {}) do
        out.saved[r.key] = { at = r.updated_at, by = r.updated_by }
    end
    return out
end)

VPO.Net.Callback('loc:save', { rate = 'custody' }, function(src, _, d)
    if not admin(src) then return { error = L('admin_needs_ace') } end
    d = type(d) == 'table' and d or {}
    local check = CHECK[d.key]
    if not check then return { error = L('loc_bad_data') } end
    local clean, err = check(d.data)
    if not clean then return { error = err } end
    local by = GetPlayerName(src)
    MySQL.insert.await([[INSERT INTO vpo_locations (`key`, data, updated_at, updated_by) VALUES (?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE data = VALUES(data), updated_at = VALUES(updated_at), updated_by = VALUES(updated_by)]],
        { d.key, json.encode(clean), os.time(), by })
    LC.Apply(d.key, clean)
    publish()
    TriggerEvent('vinewood_police:server:locationsChanged', d.key)
    VPO.Audit.Log({ action = 'locations.save', actor = src, source = 'admin', targetType = 'locations', targetId = d.key })
    return { ok = true, data = clean }
end)

VPO.Net.Callback('loc:reset', { rate = 'custody' }, function(src, _, d)
    if not admin(src) then return { error = L('admin_needs_ace') } end
    local key = type(d) == 'table' and d.key or nil
    if not LC.Keys[key] then return { error = L('loc_bad_data') } end
    MySQL.update.await('DELETE FROM vpo_locations WHERE `key` = ?', { key })
    LC.Apply(key, defaults[key])
    publish()
    TriggerEvent('vinewood_police:server:locationsChanged', key)
    VPO.Audit.Log({ action = 'locations.reset', actor = src, source = 'admin', targetType = 'locations', targetId = key })
    return { ok = true, data = defaults[key] }
end)
