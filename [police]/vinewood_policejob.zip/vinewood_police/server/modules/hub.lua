-- Everything the hub needs when it opens, in one round trip.
VPO.Hub = {}

local function forceName()
    local mdt = VPO.Integrations.Get('mdt')
    if mdt and mdt.GetFormOptions then
        local ok, opts = pcall(mdt.GetFormOptions)
        if ok and opts and opts.forceName then return opts.forceName end
    end
    return Config.Force.name
end

function VPO.Hub.StatusList()
    local out = {}
    for _, s in ipairs(Config.Duty.Statuses) do out[#out + 1] = { id = s.id, label = s.label, tone = s.tone } end
    return out
end

--- Header shown on every panel: force, officer, current shift and the status list.
function VPO.Hub.Header(src, o)
    local statuses = {}
    for _, s in ipairs(Config.Duty.Statuses) do statuses[#statuses + 1] = { id = s.id, label = s.label, tone = s.tone } end
    return {
        force = forceName(),
        officer = {
            label = VPO.Officers.Label(o), name = o.name, rank = o.rank.label, rankShort = o.rank.short,
            collar = o.collar, callsign = o.callsign,
        },
        duty = VPO.Duty.Public(src),
    }
end

VPO.Net.Callback('hub:open', { permission = 'duty.toggle', rate = 'hub' }, function(src, o)
    local station = VPO.Stations.AtSignOn(src)
    local out = VPO.Hub.Header(src, o)
    for k, v in pairs({
        ok = true,
        units = VPO.Duty.UnitsFor(o),
        station = station and station.label or nil,
        signOnAtStation = Config.Duty.SignOnAtStation,
        selfCollar = Config.Duty.SelfAssignCollar and not o.collar,
        callsignMax = Config.Duty.CallsignMaxLength,
        notebookMax = Config.Notebook.MaxLength,
        reportMax = Config.Duty.Report.MaxLength,
        reportRequired = Config.Duty.Report.Required,
        atLocker = VPO.Stations.AtLocker(src) ~= nil,
        dispatch = VPO.Integrations.Available('dispatch'),
        uofPending = MySQL.scalar.await("SELECT COUNT(*) FROM vpo_uof WHERE identifier = ? AND status = 'pending'", { o.identifier }) or 0,
    }) do out[k] = v end
    return out
end)
