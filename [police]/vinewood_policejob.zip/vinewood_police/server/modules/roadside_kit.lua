-- Roadside kit: searching vehicles (and NPCs), breath and drug tests, and seizing vehicles.
local Roads = VPO.Roads
local Cfg = Config.Roads
local L = VPO.L

local function chance(pct) return math.random(1, 100) <= (pct or 0) end
local function pick(list) return list[math.random(1, #list)] end

local function ped(src)
    local p = GetPlayerPed(src)
    return (p and p ~= 0) and p or nil
end

local function near(src, ent, max)
    local p = ped(src)
    return p and ent and #(GetEntityCoords(p) - GetEntityCoords(ent)) <= max or false
end

local function stopAndVehicle(src, d)
    local s, err = Roads.Own(src, d)
    if not s then return nil, nil, err end
    local veh = Roads.VehicleFromNet(s.net)
    return s, veh
end

local function addCheck(s, key, value)
    s.checks[key] = s.checks[key] or {}
    table.insert(s.checks[key], value)
end

---------------------------------------------------------------------------
-- Player vehicles: boot and glovebox (ox_inventory opens them on the officer's client)
---------------------------------------------------------------------------
VPO.Net.Callback('roads:searchVehicle', { permission = 'roads.search', rate = 'roads' }, function(src, o, d)
    local s, veh, err = stopAndVehicle(src, d)
    if not s then return { error = err } end
    if s.npc then return { error = L('npc_use_npc_search') } end
    if not veh or not near(src, veh, 5.0) then return { error = L('restraint_vehicle_far') } end
    local part = d.part == 'glovebox' and 'glovebox' or 'boot'
    if GetVehicleDoorLockStatus(veh) >= 2 then return { error = L('roads_locked') } end
    addCheck(s, 'searched', { part = part, at = os.time(), by = VPO.Officers.Label(o) })
    VPO.Audit.Log({ action = 'roads.search_vehicle', actor = src, targetType = 'vehicle', targetId = s.plate, meta = { part = part, stop = s.ref } })
    return { ok = true, part = part, net = s.net }
end)

VPO.Net.Callback('roads:forceEntry', { permission = 'roads.search', rate = 'roads' }, function(src, o, d)
    local s, veh, err = stopAndVehicle(src, d)
    if not s then return { error = err } end
    if not veh or not near(src, veh, 5.0) then return { error = L('restraint_vehicle_far') } end
    local reason = VPO.Util.Trim(d.reason, 255)
    if not reason or #reason < 5 then return { error = L('roads_force_reason') } end
    SetVehicleDoorsLocked(veh, 1)
    addCheck(s, 'forced', { at = os.time(), by = VPO.Officers.Label(o), reason = reason })
    VPO.Audit.Log({ action = 'roads.force_entry', actor = src, targetType = 'vehicle', targetId = s.plate, reason = reason, meta = { stop = s.ref } })
    return { ok = true, message = L('roads_forced') }
end)

---------------------------------------------------------------------------
-- NPC searches: what's found is decided once per stop from their record, so searching twice
-- finds the same things.
---------------------------------------------------------------------------
local FINDS = {
    drugs = { 'Small bag of cannabis', 'Cannabis grinder with residue', '5 wraps of white powder', 'Cannabis, three deal bags' },
    weapon = { 'Lock knife in the door pocket', 'Kitchen knife under the seat', 'Extendable baton' },
    theft = { 'Screwdriver and a broken ignition barrel', 'Three bank cards in other names', 'Bag of new clothes with security tags' },
    supply = { '£1,240 cash in mixed notes', 'Two phones, one buzzing constantly', 'Digital scales' },
    drink = { 'Half-empty bottle of vodka', 'Open cans of lager in the footwell' },
}

local function npcFinds(s, what)
    local n = s.npc
    n.finds = n.finds or {}
    if n.finds[what] then return n.finds[what] end
    local p, v, enc = n.profile.driver, n.profile.vehicle, n.enc
    local out = {}
    local function add(list) out[#out + 1] = { label = pick(list), seized = false } end
    if enc.drug and chance(70) then add(FINDS.drugs) end
    if enc.drug and chance(20) then add(FINDS.supply) end
    if enc.drink and what == 'vehicle' and chance(60) then add(FINDS.drink) end
    if (p.wanted or p.prior_record) and chance(15) then add(FINDS.weapon) end
    if (v.stolen == 1 or v.stolen == true) and what == 'vehicle' and chance(80) then add(FINDS.theft) end
    if p.prior_record and chance(10) then add(FINDS.theft) end
    n.finds[what] = out
    return out
end

VPO.Net.Callback('roads:npcSearch', { permission = 'roads.search', rate = 'roads' }, function(src, o, d)
    local s, veh, err = stopAndVehicle(src, d)
    if not s then return { error = err } end
    if not s.npc then return { error = L('npc_not_npc') } end
    local what = d.what == 'person' and 'person' or 'vehicle'
    local st = s.npc.state
    if what == 'person' and st ~= 'out' and st ~= 'surrendered' and st ~= 'arrested' then return { error = L('npc_get_them_out') } end
    if what == 'vehicle' and (not veh or not near(src, veh, 5.0)) then return { error = L('restraint_vehicle_far') } end
    local finds = npcFinds(s, what)
    addCheck(s, 'searched', { part = what, at = os.time(), by = VPO.Officers.Label(o), found = #finds })
    return { ok = true, what = what, finds = finds }
end)

VPO.Net.Callback('roads:npcSeize', { permission = 'search.seize', rate = 'roads' }, function(src, o, d)
    local s, _, err = stopAndVehicle(src, d)
    if not s then return { error = err } end
    if not s.npc or not s.npc.finds then return { error = L('npc_not_npc') } end
    local list = s.npc.finds[d.what == 'person' and 'person' or 'vehicle'] or {}
    local item = list[tonumber(d.index) or 0]
    if not item then return { error = L('equipment_not_found') } end
    if not item.seized then
        local n = s.npc
        local known = (n.identified and VPO.NPC.FullName(n.profile.driver)) or (n.given and n.given.name) or L('npc_unknown_person')
        local _, exhibit = VPO.Evidence.Create(o, {
            description = item.label, type = nil, fromName = known, linkedRef = (n.arrest and n.arrest.ref) or s.ref,
        })
        if not exhibit then return { error = L('qual_failed') } end
        item.seized, item.exhibit = true, exhibit
        n.exhibits = n.exhibits or {}
        n.exhibits[#n.exhibits + 1] = { ref = exhibit, label = item.label }
        addCheck(s, 'seized', { label = item.label, exhibit = exhibit, at = os.time(), by = VPO.Officers.Label(o) })
    end
    return { ok = true, finds = list }
end)

---------------------------------------------------------------------------
-- Breath and drug tests
---------------------------------------------------------------------------
local function breathResult(reading)
    return { outcome = reading > Cfg.Tests.BreathLimit and 'fail' or 'pass', reading = reading }
end

VPO.Net.Callback('roads:test', { permission = 'roads.test', rate = 'roads' }, function(src, o, d)
    local s, veh, err = stopAndVehicle(src, d)
    if not s then return { error = err } end
    local kind = d.kind == 'drug' and 'drug' or 'breath'
    local result

    if s.npc then
        local n = s.npc
        local st = n.state
        if st ~= 'stopped' and st ~= 'out' and st ~= 'surrendered' then return { error = L('npc_cant_talk') } end
        if (n.enc.behaviour == 'uncooperative' or n.enc.behaviour == 'aggressive') and not n.warned then
            result = { outcome = 'refused' }
        elseif kind == 'breath' then
            result = breathResult(n.enc.drink and math.random(38, 95) or (chance(20) and math.random(4, 22) or 0))
        else
            result = n.enc.drug and { outcome = 'fail', substance = pick(Cfg.Tests.DrugsTested) } or { outcome = 'pass' }
        end
    else
        local target = s.driverSrc or tonumber(d.target)
        if not target or not GetPlayerName(target) then return { error = L('roads_check_driver_first') } end
        if not veh or not near(target, veh, Cfg.DriverRange + 5.0) then return { error = L('roads_driver_far') } end
        local reading = Cfg.Tests.PlayerReading and kind == 'breath' and Cfg.Tests.PlayerReading(target) or nil
        if reading then
            result = breathResult(math.floor(reading))
        else
            local opts = kind == 'breath'
                and { { id = 'under', label = L('test_blow_under') }, { id = 'over', label = L('test_blow_over') }, { id = 'refuse', label = L('test_refuse') } }
                or { { id = 'clear', label = L('test_drug_clear') }, { id = 'positive', label = L('test_drug_positive') }, { id = 'refuse', label = L('test_refuse') } }
            local choice = VPO.AskPlayer(target, kind == 'breath' and L('test_breath_title') or L('test_drug_title'),
                L(kind == 'breath' and 'test_breath_text' or 'test_drug_text', VPO.Officers.Label(o)), opts, Cfg.Tests.PromptTimeout)
            if choice == 'under' then result = breathResult(math.random(0, Cfg.Tests.BreathLimit - 3))
            elseif choice == 'over' then result = breathResult(math.random(Cfg.Tests.BreathLimit + 3, 90))
            elseif choice == 'clear' then result = { outcome = 'pass' }
            elseif choice == 'positive' then result = { outcome = 'fail', substance = pick(Cfg.Tests.DrugsTested) }
            else result = { outcome = 'refused' } end
        end
    end

    result.kind, result.limit, result.at = kind, Cfg.Tests.BreathLimit, os.time()
    addCheck(s, 'tests', result)
    VPO.Audit.Log({ action = 'roads.test', actor = src, targetType = s.npc and 'npc' or 'player', targetId = s.driverIdentifier or s.driverName, new = result, meta = { stop = s.ref } })
    return { ok = true, result = result }
end)

---------------------------------------------------------------------------
-- Seizure and recovery
---------------------------------------------------------------------------
local function powerById(id)
    for _, p in ipairs(Cfg.Seizure.Powers) do if p.id == id then return p end end
    return nil
end

local function recover(seizureId, net, plate, info, tries)
    SetTimeout((tries == 0 and Cfg.Seizure.RecoveryDelay or 15) * 1000, function()
        local veh = net and NetworkGetEntityFromNetworkId(net) or 0
        if veh ~= 0 and DoesEntityExist(veh) then
            -- Don't take it away with someone sitting in it
            for seat = -1, 6 do
                local p = GetPedInVehicleSeat(veh, seat)
                if p and p ~= 0 and IsPedAPlayer(p) then
                    if tries < 20 then return recover(seizureId, net, plate, info, tries + 1) end
                    return
                end
            end
            DeleteEntity(veh)
        end
        MySQL.update("UPDATE vpo_vehicle_seizures SET status = 'recovered', recovered_at = ? WHERE id = ?", { os.time(), seizureId })
        if not info.npc then
            local ok, e = pcall(Cfg.Seizure.OnImpound, plate, info)
            if not ok then VPO.Log.error('OnImpound failed for %s: %s', plate, e) end
        end
    end)
end

VPO.Net.Callback('roads:seize', { permission = 'roads.seize', rate = 'roads' }, function(src, o, d)
    local s, veh, err = stopAndVehicle(src, d)
    if not s then return { error = err } end
    if s.seizure then return { error = L('roads_already_seized', s.seizure) } end
    if not veh or not near(src, veh, 15.0) then return { error = L('restraint_vehicle_far') } end
    local power = powerById(d.power)
    if not power then return { error = L('roads_pick_power') } end
    local reason = VPO.Util.Trim(d.reason, 1000)
    if not reason or #reason < 10 then return { error = L('roads_seize_reason') } end

    local id = MySQL.insert.await([[INSERT INTO vpo_vehicle_seizures (stop_id, plate, model, npc, power, reason, driver_name, location,
        officer_identifier, officer_name, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)]],
        { s.id, s.plate, tostring(GetEntityModel(veh)), s.npc and 1 or 0, power.id, reason, s.driverName, s.location,
          o.identifier, VPO.Officers.Label(o), os.time() })
    if not id then return { error = L('qual_failed') } end
    local ref = ('VSZ/%s/%s/%05d'):format(Config.Force.short, os.date('%y%m'), id)
    MySQL.update('UPDATE vpo_vehicle_seizures SET ref = ? WHERE id = ?', { ref, id })
    s.seizure = ref
    addCheck(s, 'seizure', { ref = ref, power = power.id, at = os.time(), by = VPO.Officers.Label(o) })
    VPO.Audit.Log({ action = 'roads.seize', actor = src, targetType = 'vehicle', targetId = s.plate, new = { ref = ref, power = power.id }, reason = reason })

    if s.driverSrc and GetPlayerName(s.driverSrc) then
        VPO.Documents.Give(s.driverSrc, {
            title = L('roads_seized_title'), from = VPO.Officers.Label(o), ref = ref,
            text = L('roads_seized_text', ref, s.plate, power.label, Config.Roads.Currency, Cfg.Seizure.Fee),
        })
    end
    recover(id, s.net, s.plate, { ref = ref, power = power.id, fee = Cfg.Seizure.Fee, npc = s.npc ~= nil, officer = o.identifier }, 0)
    return { ok = true, ref = ref, delay = Cfg.Seizure.RecoveryDelay }
end)
