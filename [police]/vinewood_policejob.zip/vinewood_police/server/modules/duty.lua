-- Duty: sign-on and sign-off, officer status, framework duty sync, shift reports.
--
-- VPO.Duty.Get(src)                  the live session or nil
-- VPO.Duty.AddStat(src, key, n)      counts something on the officer's shift report (arrests, searches...)
-- VPO.Duty.OnSignOff(cb)             cb(src, session) before a session closes; may return a table merged into stats
-- Server event: vinewood_police:server:dutyChanged (src, onDuty, publicDuty)
VPO.Duty = {}
local Duty = VPO.Duty
local L = VPO.L
local sessions = {}     -- [src] = session
local signOffCbs = {}
local syncing = {}      -- [src] = true while we change the framework flag ourselves

local unitById, statusById = {}, {}
for _, u in ipairs(Config.Duty.UnitTypes) do unitById[u.id] = u end
for _, s in ipairs(Config.Duty.Statuses) do statusById[s.id] = s end

function Duty.Get(src) return sessions[tonumber(src)] end
function Duty.All() return sessions end
function Duty.OnSignOff(cb) signOffCbs[#signOffCbs + 1] = cb end

function Duty.AddStat(src, key, n)
    local s = sessions[tonumber(src)]
    if not s then return end
    s.stats[key] = (s.stats[key] or 0) + (n or 1)
end

--- What everyone can see (statebag, roster, exports).
local function public(s)
    return {
        callsign = s.callsign, collar = s.collar, unit = s.unit, unitLabel = unitById[s.unit] and unitById[s.unit].label or s.unit,
        vehicle = s.vehicle, station = s.station, status = s.status, since = s.startedAt, name = s.officerLabel,
    }
end
Duty.Public = function(src) local s = sessions[tonumber(src)]; return s and public(s) or nil end

local function setFramework(src, on)
    syncing[src] = true
    VPO.Bridge.SetFrameworkDuty(src, on)
    syncing[src] = nil
    local d = VPO.Integrations.Get('dispatch')
    if d then d.RefreshClient(src) end
end

local function announce(src, s)
    if s then VPO.State.Set(src, 'duty', public(s)) else VPO.State.Set(src, 'duty', nil) end
    TriggerEvent('vinewood_police:server:dutyChanged', src, s ~= nil, s and public(s) or nil)
end

VPO.Permissions.SetDutyProvider(function(src) return sessions[src] ~= nil end)

--- Units this officer may sign on as.
function Duty.UnitsFor(o)
    local out = {}
    for _, u in ipairs(Config.Duty.UnitTypes) do
        local ok, why = true, nil
        if u.minRank and o.rank.level < VPO.Ranks.Level(u.minRank) then ok, why = false, VPO.Ranks.Get(u.minRank).label .. '+' end
        for _, q in ipairs(u.qualifications or {}) do
            if ok and not VPO.Qualifications.Has(o.identifier, q) then
                ok, why = false, (VPO.Qualifications.Def(q) or {}).label or q
            end
        end
        out[#out + 1] = { id = u.id, label = u.label, allowed = ok, needs = why }
    end
    return out
end

local function unitAllowed(o, unitId)
    for _, u in ipairs(Duty.UnitsFor(o)) do if u.id == unitId then return u.allowed, u.needs end end
    return false
end

local function normaliseCallsign(cs)
    cs = VPO.Util.Trim(cs, 32)
    return cs and cs:upper() or nil
end

local function callsignInUse(src, cs)
    for other, s in pairs(sessions) do
        if other ~= src and s.callsign == cs then return true end
    end
    return false
end

---------------------------------------------------------------------------
-- Sign on
---------------------------------------------------------------------------
function Duty.SignOn(src, o, d)
    if sessions[src] then return { error = L('duty_already_on') } end
    d = type(d) == 'table' and d or {}
    local suspended = VPO.Management and VPO.Management.Suspended(o.identifier)
    if suspended then return { error = L('duty_suspended', suspended) } end

    local station
    if Config.Duty.SignOnAtStation then
        station = VPO.Stations.AtSignOn(src)
        if not station then return { error = L('duty_go_to_station') } end
    else
        station = VPO.Stations.AtSignOn(src)
    end

    local unit = unitById[d.unit] and d.unit or nil
    if not unit then return { error = L('duty_pick_unit') } end
    local ok, needs = unitAllowed(o, unit)
    if not ok then return { error = L('duty_unit_needs', unitById[unit].label, needs or '?') } end

    -- Collar number
    local collar = o.collar
    if not collar then
        local wanted = VPO.Util.Trim(tostring(d.collar or ''), 10)
        if wanted and Config.Duty.SelfAssignCollar then
            if not wanted:match('^%d+$') or #wanted > Config.CollarMaxDigits then
                return { error = L('collar_invalid', Config.CollarMaxDigits) }
            end
            local good = VPO.Officers.SetCollar(o.identifier, wanted)
            if not good then return { error = L('collar_taken', wanted) } end
            VPO.Audit.Log({ action = 'officer.collar', actor = src, targetType = 'officer', targetId = o.identifier, new = wanted, reason = 'self-assigned at sign-on' })
            collar = wanted
        elseif Config.Duty.RequireCollar then
            return { error = Config.Duty.SelfAssignCollar and L('duty_need_collar') or L('duty_need_collar_sergeant') }
        end
    end

    -- Callsign: the dispatch owns it when it's running, so every resource shows the same one.
    local callsign = normaliseCallsign(d.callsign)
    if not callsign and Config.Duty.RequireCallsign then return { error = L('duty_need_callsign') } end
    if callsign then
        if VPO.Integrations.Available('dispatch') then
            local good, result = VPO.Integrations.Call('dispatch', 'SetCallsign', src, callsign)
            if good == nil and result == 'timeout' then return { error = L('duty_dispatch_timeout') } end
            if not good then return { error = tostring(result or L('duty_callsign_invalid')) } end
            callsign = result or callsign
        else
            if #callsign > Config.Duty.CallsignMaxLength or not callsign:match(Config.Duty.CallsignPattern) then
                return { error = L('duty_callsign_invalid') }
            end
            if callsignInUse(src, callsign) then return { error = L('duty_callsign_taken', callsign) } end
            VPO.Bridge.SetCallsignMetadata(src, callsign)
        end
        VPO.Officers.SetCallsign(o.identifier, callsign)
    end

    local vehicle = VPO.Util.Trim(d.vehicle, 24)
    o.collar, o.callsign = collar, callsign
    local label = VPO.Officers.Label(o)
    local t = os.time()

    -- Close anything left open (crash, kicked mid-shift) before opening a new one.
    MySQL.update.await("UPDATE vpo_duty_sessions SET ended_at = ?, end_reason = 'not_closed' WHERE identifier = ? AND ended_at IS NULL", { t, o.identifier })
    local id = MySQL.insert.await([[INSERT INTO vpo_duty_sessions (identifier, officer, callsign, collar, unit, vehicle, station, started_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)]], { o.identifier, label, callsign, collar, unit, vehicle, station and station.id or nil, t })
    if not id then return { error = L('qual_failed') } end

    local s = {
        id = id, identifier = o.identifier, officerLabel = label, callsign = callsign, collar = collar, unit = unit,
        vehicle = vehicle, station = station and station.label or nil, status = Config.Duty.DefaultStatus,
        startedAt = t, stats = { statusChanges = 0 },
    }
    sessions[src] = s
    announce(src, s)
    setFramework(src, true)
    VPO.Audit.Log({ action = 'duty.signon', actor = src, targetType = 'session', targetId = id,
        new = { callsign = callsign, unit = unit, vehicle = vehicle, station = s.station } })
    return { ok = true, duty = public(s) }
end

---------------------------------------------------------------------------
-- Sign off / end
---------------------------------------------------------------------------
--- Closes a session. reason: 'signed_off' | 'disconnected' | 'job_changed' | 'admin' | ...
--- gone = the player has already left (don't touch their statebag or framework flag).
function Duty.End(src, reason, report, gone)
    local s = sessions[src]
    if not s then return nil end
    for _, cb in ipairs(signOffCbs) do
        local ok, extra = pcall(cb, src, s, gone)
        if ok and type(extra) == 'table' then for k, v in pairs(extra) do s.stats[k] = v end end
        if not ok then VPO.Log.error('sign-off handler failed: %s', extra) end
    end
    sessions[src] = nil
    local t = os.time()
    s.stats.minutes = math.floor((t - s.startedAt) / 60)
    MySQL.update.await('UPDATE vpo_duty_sessions SET ended_at = ?, end_reason = ?, report = ?, stats = ? WHERE id = ?',
        { t, reason, report, json.encode(s.stats), s.id })
    if not gone then
        announce(src, nil)
        setFramework(src, false)
    else
        TriggerEvent('vinewood_police:server:dutyChanged', src, false, nil)
    end
    VPO.Audit.Log({ action = 'duty.signoff', actor = not gone and src or nil, actorIdentifier = s.identifier, actorName = s.officerLabel,
        source = gone and 'system' or 'player', targetType = 'session', targetId = s.id, reason = reason, meta = s.stats })
    return s
end

function Duty.SignOff(src, d)
    local s = sessions[src]
    if not s then return { error = L('duty_not_on') } end
    if Config.Duty.SignOffAtStation and not VPO.Stations.AtSignOn(src) then return { error = L('duty_go_to_station_off') } end
    local report = VPO.Util.Trim(type(d) == 'table' and d.report or nil, Config.Duty.Report.MaxLength)
    if Config.Duty.Report.Required and not report then return { error = L('duty_need_report') } end
    local ended = Duty.End(src, 'signed_off', report)
    return { ok = true, summary = ended and ended.stats or {} }
end

---------------------------------------------------------------------------
-- Status
---------------------------------------------------------------------------
function Duty.SetStatus(src, status)
    local s = sessions[src]
    if not s then return { error = L('duty_not_on') } end
    if not statusById[status] then return { error = L('duty_bad_status') } end
    if s.status ~= status then
        s.status = status
        s.stats.statusChanges = (s.stats.statusChanges or 0) + 1
        announce(src, s)
    end
    return { ok = true, duty = public(s) }
end

--- Summary shown on the sign-off screen before confirming.
function Duty.Summary(src)
    local s = sessions[src]
    if not s then return nil end
    local out = VPO.Util.Copy(s.stats)
    out.minutes = math.floor((os.time() - s.startedAt) / 60)
    out.notebook = MySQL.scalar.await('SELECT COUNT(*) FROM vpo_notebook WHERE session_id = ?', { s.id }) or 0
    out.outstanding = VPO.Equipment and #VPO.Equipment.Outstanding(s.identifier) or 0
    return out
end

---------------------------------------------------------------------------
-- Framework duty enforcement and job changes
---------------------------------------------------------------------------
local function enforce(src)
    src = tonumber(src)
    if not src or syncing[src] or not GetPlayerName(src) then return end
    local job = VPO.Bridge.GetJob(src)
    if not job or not Config.Jobs[job.name] then
        if sessions[src] then
            Duty.End(src, 'job_changed')
            VPO.Notify(src, L('duty_ended_job'), 'inform')
        end
        return
    end
    if not Config.Duty.EnforceFrameworkDuty or job.onduty == nil then return end
    local want = sessions[src] ~= nil
    if job.onduty ~= want then
        setFramework(src, want)
        if not want then VPO.Notify(src, L('duty_use_station'), 'error') end
    end
end

AddEventHandler('QBCore:Server:OnJobUpdate', function(src) SetTimeout(0, function() enforce(src) end) end)
AddEventHandler('QBCore:Server:SetDuty', function(src) SetTimeout(0, function() enforce(src) end) end)
AddEventHandler('esx:setJob', function(src) SetTimeout(0, function() enforce(src) end) end)

-- dispatch: someone changed their callsign with /callsign while on duty
AddEventHandler('vinewood-dispatch:server:callsignChanged', function(src, callsign)
    local s = sessions[tonumber(src)]
    if not s or not callsign or s.callsign == callsign then return end
    s.callsign = callsign
    announce(tonumber(src), s)
end)

---------------------------------------------------------------------------
-- Load, unload, restart
---------------------------------------------------------------------------
VPO.Bridge.OnPlayerLoaded(function(src)
    CreateThread(function()
        if not VPO.WaitReady() then return end
        if not sessions[src] then
            local id = VPO.Bridge.GetIdentifier(src)
            if id then
                MySQL.update.await("UPDATE vpo_duty_sessions SET ended_at = ?, end_reason = 'not_closed' WHERE identifier = ? AND ended_at IS NULL", { os.time(), id })
            end
        end
        enforce(src)
    end)
end)

VPO.Bridge.OnPlayerUnloaded(function(src)
    if sessions[src] then Duty.End(src, 'disconnected', nil, true) end
end)

-- After a restart: officers still in the city carry on their shift; everyone else's open session is closed.
AddEventHandler(VPO.Events.ready, function()
    local open = MySQL.query.await('SELECT * FROM vpo_duty_sessions WHERE ended_at IS NULL') or {}
    local t = os.time()
    for _, r in ipairs(open) do
        local src = VPO.Bridge.GetSource(r.identifier)
        local job = src and VPO.Bridge.GetJob(src)
        if src and job and Config.Jobs[job.name] and not sessions[src] then
            local stats = r.stats and json.decode(r.stats) or nil
            sessions[src] = {
                id = r.id, identifier = r.identifier, officerLabel = r.officer, callsign = r.callsign, collar = r.collar,
                unit = r.unit, vehicle = r.vehicle, station = (VPO.Stations.Get(r.station) or {}).label,
                status = Config.Duty.DefaultStatus, startedAt = r.started_at, stats = stats or { statusChanges = 0 },
            }
            announce(src, sessions[src])
            VPO.Log.info('Resumed shift for %s (%s)', r.officer or r.identifier, r.callsign or '-')
        else
            MySQL.update.await("UPDATE vpo_duty_sessions SET ended_at = ?, end_reason = 'server_restart' WHERE id = ?", { t, r.id })
        end
    end
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= VPO.Resource then return end
    -- Keep sessions open so they resume after the restart, but save the stats so far.
    for _, s in pairs(sessions) do
        MySQL.update('UPDATE vpo_duty_sessions SET stats = ? WHERE id = ?', { json.encode(s.stats), s.id })
    end
end)

---------------------------------------------------------------------------
-- Hub callbacks
---------------------------------------------------------------------------
VPO.Net.Callback('duty:signOn', { permission = 'duty.toggle', rate = 'duty' }, function(src, o, d) return Duty.SignOn(src, o, d) end)
VPO.Net.Callback('duty:signOff', { permission = 'duty.toggle', rate = 'duty' }, function(src, _, d) return Duty.SignOff(src, d) end)
VPO.Net.Callback('duty:summary', { permission = 'duty.status', rate = 'hub' }, function(src) return { ok = true, summary = Duty.Summary(src) } end)
VPO.Net.Callback('duty:setStatus', { permission = 'duty.status', rate = 'hub' }, function(src, _, d)
    return Duty.SetStatus(src, type(d) == 'table' and d.status or nil)
end)

VPO.Net.Callback('duty:roster', { permission = 'roster.view', rate = 'hub' }, function()
    local list = {}
    for _, s in pairs(sessions) do list[#list + 1] = public(s) end
    table.sort(list, function(a, b) return (a.callsign or '') < (b.callsign or '') end)
    return { ok = true, roster = list }
end)
