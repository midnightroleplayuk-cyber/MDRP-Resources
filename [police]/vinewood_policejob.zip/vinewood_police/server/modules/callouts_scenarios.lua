-- Callout scenarios. Each has:
--   pool      which Config.Callouts.Locations list it uses
--   outcomes  how the call can be closed
--   plan(loc) decides what's really happening when the call is made (before anyone arrives)
--   spawn(call) puts it in the world when an officer gets close
local CO = VPO.Callouts
local EN = VPO.Encounters
local M = Config.Callouts.Models

local function chance(pct) return math.random(1, 100) <= pct end
local function pick(list) return list[math.random(1, #list)] end
local function weighted(t) return VPO.NPC.Weighted(t) end

--- Point relative to a vec4: forward f metres, right r metres.
local function offset(c, f, r)
    local h = math.rad(c.w or 0.0)
    return vec4(c.x - math.sin(h) * f + math.cos(h) * r, c.y + math.cos(h) * f + math.sin(h) * r, c.z, c.w or 0.0)
end

local function facing(c, target) -- heading from c towards target
    return vec4(c.x, c.y, c.z, (math.deg(math.atan(target.x - c.x, target.y - c.y)) * -1.0) % 360.0)
end

local function model(sex) return pick(sex == 'F' and M.female or M.male) end

local AGES = { 'late teens', '20s', '30s', '40s', '50s' }
local TOPS = { 'a dark hoodie', 'a grey tracksuit', 'a black puffer jacket', 'a red top', 'a white T-shirt', 'a green parka' }
local function describe(sex) return ('%s, %s, wearing %s'):format(sex == 'F' and 'female' or 'male', pick(AGES), pick(TOPS)) end

local THEFT = 's.1 Theft, Theft Act 1968'
local BURGLARY = 's.9 Burglary, Theft Act 1968'
local S4 = 's.4 Fear or provocation of violence, Public Order Act 1986'
local S5 = 's.5 Harassment, alarm or distress, Public Order Act 1986'
local ASSAULT = 's.39 Common assault, Criminal Justice Act 1988'
local DRINK = 's.5 Driving with excess alcohol, Road Traffic Act 1988'
local CARELESS = 's.3 Careless driving, Road Traffic Act 1988'

---------------------------------------------------------------------------
-- Shoplifting
---------------------------------------------------------------------------
CO.Register('shoplifting', {
    pool = 'shops', code = '10-SHOP',
    outcomes = { 'Suspect arrested', 'Community resolution', 'Words of advice', 'Suspect not traced', 'No offence disclosed' },
    plan = function(loc)
        local sex = chance(75) and 'M' or 'F'
        local goods = pick({ { 'Two bottles of vodka', 'Phone charger' }, { 'Bag of meat joints', 'Razor blades' }, { 'Bottle of whisky' }, { 'Six energy drinks', 'Chocolate bars' } })
        local desc = describe(sex)
        return {
            title = 'Shoplifter detained / made off', mdtType = 'Theft',
            description = ('Staff at %s report a shoplifter: %s. Took %s.'):format(loc.label, desc, table.concat(goods, ' and '):lower()),
            sex = sex, goods = goods, desc = desc,
            behaviour = weighted({ compliant = 45, nervous = 20, flee = 25, hostile = 10 }),
        }
    end,
    spawn = function(call)
        local c, plan = call.coords, call.plan
        EN.Spawn(call.id, { role = 'witness', model = pick(M.shopkeeper), coords = c, action = 'idle', actionData = { scenario = 'WORLD_HUMAN_STAND_IMPATIENT' },
            statement = ('"%s. They took %s and walked straight out without paying. We have it on CCTV."'):format(plan.desc:gsub('^%l', string.upper), table.concat(plan.goods, ' and '):lower()) })
        local spot = offset(c, 14.0 + math.random() * 8.0, math.random(-6, 6))
        EN.Spawn(call.id, { role = 'suspect', model = model(plan.sex), coords = spot, behaviour = plan.behaviour,
            trigger = (plan.behaviour == 'flee' or plan.behaviour == 'hostile') and 'approach' or nil,
            action = 'idle', actionData = { scenario = 'WORLD_HUMAN_STAND_MOBILE' }, finds = plan.goods, offences = { THEFT },
            falseDetails = chance(20) })
    end,
})

---------------------------------------------------------------------------
-- Disturbance
---------------------------------------------------------------------------
CO.Register('disturbance', {
    pool = 'streets', code = '10-DIST',
    outcomes = { 'Arrest', 'Words of advice', 'Parties separated, no offences', 'Gone on police arrival' },
    plan = function(loc)
        local fighting = chance(25)
        return {
            title = fighting and 'Fight in progress' or 'Disturbance: two people arguing', mdtType = fighting and 'Assault' or 'Public order',
            description = fighting and ('Caller reports two people fighting at %s.'):format(loc.label)
                or ('Caller reports two people shouting and squaring up at %s.'):format(loc.label),
            fighting = fighting, drunk = chance(50),
            aggressor = weighted({ compliant = 35, uncooperative = 30, hostile = 20, flee = 15 }),
        }
    end,
    spawn = function(call)
        local c, plan = call.coords, call.plan
        local a = offset(c, 0.0, -0.9)
        local b = offset(c, 0.0, 0.9)
        local sexA, sexB = chance(80) and 'M' or 'F', chance(60) and 'M' or 'F'
        local victim = EN.Spawn(call.id, { role = 'victim', model = model(sexB), coords = facing(b, a), action = 'idle', actionData = { scenario = 'WORLD_HUMAN_STAND_IMPATIENT' },
            statement = plan.fighting and '"He just went for me, swinging. I was defending myself."' or '"He started shouting in my face over nothing. I want him to leave me alone."' })
        local aggressor = EN.Spawn(call.id, { role = 'suspect', model = model(sexA), coords = facing(a, b), behaviour = plan.aggressor,
            trigger = plan.aggressor == 'flee' and 'approach' or nil, drink = plan.drunk, offences = plan.fighting and { ASSAULT, S4 } or { S5, S4 },
            finds = chance(10) and { 'Lock knife' } or {} })
        if aggressor and victim then
            if plan.fighting then
                EN.Control(aggressor, 'fight', { other = victim.pedNet })
                EN.Control(victim, 'fight', { other = aggressor.pedNet })
            else
                EN.Control(aggressor, 'argue', { other = victim.pedNet })
            end
        end
    end,
})

---------------------------------------------------------------------------
-- Concern for welfare
---------------------------------------------------------------------------
CO.Register('welfare', {
    pool = 'streets', code = '10-CFW',
    outcomes = { 'Taken home', 'Handed to ambulance', 'Words of advice', 'No concerns found' },
    plan = function(loc)
        local kind = weighted({ confused = 50, drunk = 35, lost = 15 })
        local text = {
            confused = 'Elderly person seems confused and has been standing in the same spot for an hour.',
            drunk = 'Person very drunk, struggling to stand.',
            lost = 'Person says they are lost and has no phone.',
        }
        return { title = 'Concern for welfare', mdtType = 'Concern for welfare', kind = kind,
            description = ('%s at %s.'):format(text[kind], loc.label) }
    end,
    spawn = function(call)
        local c, plan = call.coords, call.plan
        local statements = {
            confused = '"I was going to the shops... I think. I live just round here, don\'t I?"',
            drunk = '"I\'m fine, officer. Fine. Just need a minute."',
            lost = '"My phone\'s dead and I don\'t know this area. I\'m trying to get home."',
        }
        EN.Spawn(call.id, { role = 'subject', model = plan.kind == 'confused' and pick(M.elderly) or model(chance(60) and 'M' or 'F'),
            coords = c, behaviour = 'compliant', drink = plan.kind == 'drunk', statement = statements[plan.kind],
            injured = plan.kind == 'drunk' and chance(40) or nil,
            action = plan.kind == 'drunk' and 'sit' or 'idle', actionData = { scenario = plan.kind == 'confused' and 'WORLD_HUMAN_STAND_IMPATIENT' or 'WORLD_HUMAN_STAND_MOBILE' } })
    end,
})

---------------------------------------------------------------------------
-- Burglary alarm
---------------------------------------------------------------------------
CO.Register('burglary', {
    pool = 'houses', code = '10-ALARM',
    outcomes = { 'False alarm', 'Suspect arrested', 'Suspect not traced', 'Premises secured, no offence' },
    plan = function(loc)
        local real = chance(40)
        return {
            title = 'Intruder alarm activation', mdtType = real and 'Burglary' or 'Suspicious activity', real = real,
            description = ('Monitored intruder alarm activation at %s.%s'):format(loc.label, real and ' Neighbour reports someone in the garden.' or ''),
            behaviour = weighted({ flee = 45, compliant = 25, hostile = 15, nervous = 15 }),
        }
    end,
    spawn = function(call)
        local c, plan = call.coords, call.plan
        if not plan.real then
            EN.Spawn(call.id, { role = 'keyholder', model = model(chance(50) and 'M' or 'F'), coords = c, behaviour = 'compliant',
                address = call.location, action = 'idle', actionData = { scenario = 'WORLD_HUMAN_STAND_MOBILE' },
                statement = '"Sorry, that\'s me. I forgot the code when I came in. This is my house."' })
            return
        end
        local spot = offset(c, -6.0, math.random(-5, 5))
        EN.Spawn(call.id, { role = 'suspect', model = model(chance(85) and 'M' or 'F'), coords = spot, behaviour = plan.behaviour,
            trigger = (plan.behaviour == 'flee' or plan.behaviour == 'hostile') and 'approach' or nil,
            action = 'idle', actionData = { scenario = 'WORLD_HUMAN_SMOKING' }, offences = { BURGLARY },
            finds = { pick({ 'Screwdriver and a small torch', 'Pair of gloves and a crowbar' }), pick({ 'Jewellery box', 'Laptop', 'Two watches and a wallet' }) },
            falseDetails = chance(30) })
        if chance(50) then
            EN.Spawn(call.id, { role = 'witness', model = model(chance(50) and 'M' or 'F'), coords = offset(c, 12.0, 6.0), action = 'idle',
                actionData = { scenario = 'WORLD_HUMAN_STAND_IMPATIENT' },
                statement = '"I heard glass go, then saw someone climbing over the back fence. Dark clothes, gloves on."' })
        end
    end,
})

---------------------------------------------------------------------------
-- Road traffic collision
---------------------------------------------------------------------------
local function spawnCar(call, pos)
    local hash = GetHashKey(pick(M.cars))
    local veh
    if CreateVehicleServerSetter then
        veh = CreateVehicleServerSetter(hash, 'automobile', pos.x, pos.y, pos.z, pos.w)
    else
        veh = CreateVehicle(hash, pos.x, pos.y, pos.z, pos.w, true, true)
    end
    local deadline = GetGameTimer() + 3000
    while (not veh or not DoesEntityExist(veh)) and GetGameTimer() < deadline do Wait(20) end
    if not veh or not DoesEntityExist(veh) then return nil end
    SetEntityOrphanMode(veh, 2)
    local net = NetworkGetNetworkIdFromEntity(veh)
    call.vehicles[#call.vehicles + 1] = net
    return net
end

CO.Register('collision', {
    pool = 'roads', code = '10-RTC',
    outcomes = { 'Damage only, details exchanged', 'Traffic offence report', 'Driver arrested', 'Injured party to hospital', 'Vehicles recovered' },
    plan = function(loc)
        local injury = chance(30)
        return {
            title = injury and 'RTC: injuries reported' or 'RTC: damage only', mdtType = injury and 'RTC - injuries' or 'RTC - damage only',
            description = ('Two-vehicle collision at %s.%s'):format(loc.label, injury and ' One person hurt.' or ' No injuries reported.'),
            injury = injury, drink = chance(35), noInsurance = chance(20),
            atFault = weighted({ compliant = 70, nervous = 15, flee = 15 }),
        }
    end,
    spawn = function(call)
        local c, plan = call.coords, call.plan
        local front = offset(c, 4.0, 0.0)
        local back = offset(c, -1.5, 0.3)
        local n1, n2 = spawnCar(call, front), spawnCar(call, back)
        local ctl = CO.Controller(call)
        if ctl then TriggerClientEvent('vinewood_police:client:enc:damage', ctl, { n1, n2 }) end
        local victimSpot = offset(c, 4.0, 3.0)
        local faultSpot = offset(c, -1.5, 3.2)
        EN.Spawn(call.id, { role = 'driver', model = model(chance(50) and 'M' or 'F'), coords = victimSpot, behaviour = 'compliant', injured = plan.injury,
            action = plan.injury and 'injured' or 'idle', actionData = { scenario = 'WORLD_HUMAN_STAND_MOBILE' },
            statement = '"I was stopped at the lights and they went straight into the back of me."' })
        EN.Spawn(call.id, { role = 'suspect', model = model(chance(70) and 'M' or 'F'), coords = faultSpot, behaviour = plan.atFault,
            trigger = plan.atFault == 'flee' and 'approach' or nil, drink = plan.drink, licence = plan.noInsurance and 'none' or nil,
            action = 'idle', actionData = { scenario = 'WORLD_HUMAN_STAND_IMPATIENT' },
            statement = plan.drink and '"They braked out of nowhere. I\'ve only had one, honest."' or '"I looked down for a second. Sorry."',
            offences = plan.drink and { DRINK, CARELESS } or { CARELESS }, falseDetails = plan.drink and chance(25) })
    end,
})

local ROBBERY = 's.8 Robbery, Theft Act 1968'
local BLADE = 's.139 Possession of a bladed article, Criminal Justice Act 1988'
local FIREARM = 's.1 Possession without certificate, Firearms Act 1968'

local function weaponFor(firearmAllowed)
    local A = Config.Callouts.Armed
    if firearmAllowed and chance(A.FirearmChance) then return A.Weapons.firearm, 'Handgun', FIREARM end
    return A.Weapons.knife, pick({ 'Kitchen knife', 'Lock knife', 'Large hunting knife' }), BLADE
end

---------------------------------------------------------------------------
-- Shop robbery (armed)
---------------------------------------------------------------------------
CO.Register('shop_robbery', {
    pool = 'shops', code = '10-90',
    outcomes = { 'Suspect arrested', 'Suspect not traced', 'Suspect made off', 'No offence disclosed' },
    plan = function(loc)
        local A = Config.Callouts.Armed
        local firearmAllowed = not A.FirearmsNeedARV or CO.ArvOnDuty() > 0
        local weapon, weaponLabel, weaponOffence = weaponFor(firearmAllowed)
        local sex = chance(85) and 'M' or 'F'
        local desc = describe(sex)
        local inProgress = chance(60)
        return {
            title = weapon == A.Weapons.firearm and 'Armed robbery: firearm seen' or 'Robbery: suspect with a knife',
            mdtType = weapon == A.Weapons.firearm and 'Armed robbery' or 'Robbery',
            description = ('%s at %s. Suspect %s, armed with a %s.%s'):format(inProgress and 'Robbery in progress' or 'Robbery just occurred',
                loc.label, desc, weaponLabel:lower(), inProgress and ' Staff still inside.' or ' Suspect left on foot.'),
            sex = sex, desc = desc, weapon = weapon, weaponLabel = weaponLabel, weaponOffence = weaponOffence, inProgress = inProgress,
            cash = math.random(80, 600),
        }
    end,
    spawn = function(call)
        local c, plan = call.coords, call.plan
        local staff = EN.Spawn(call.id, { role = 'victim', model = pick(M.shopkeeper), coords = c, action = 'idle', actionData = { scenario = 'WORLD_HUMAN_STAND_IMPATIENT' },
            statement = ('"%s. Pointed a %s at me and made me empty the till. About £%d."'):format(plan.desc:gsub('^%l', string.upper), plan.weaponLabel:lower(), plan.cash) })
        local spot = plan.inProgress and offset(c, 2.0, 0.0) or offset(c, 18.0 + math.random() * 8.0, math.random(-6, 6))
        local suspect = EN.Spawn(call.id, { role = 'suspect', model = model(plan.sex), coords = spot, behaviour = 'armed', trigger = 'approach',
            weapon = plan.weapon, weaponLabel = plan.weaponLabel, offences = { ROBBERY, plan.weaponOffence },
            finds = { ('£%d in cash, mostly notes'):format(plan.cash) }, falseDetails = chance(35),
            action = 'armed', actionData = { weapon = plan.weapon } })
        if suspect and staff and plan.inProgress then EN.Control(suspect, 'armed', { weapon = plan.weapon, aimAt = staff.pedNet }) end
        if staff and plan.inProgress then EN.Control(staff, 'handsup') end
    end,
})

---------------------------------------------------------------------------
-- Street robbery / mugging
---------------------------------------------------------------------------
CO.Register('street_robbery', {
    pool = 'streets', code = '10-31',
    outcomes = { 'Suspect arrested', 'Suspect not traced', 'Victim declined to support', 'Injured party to hospital' },
    plan = function(loc)
        local sex = chance(85) and 'M' or 'F'
        local desc = describe(sex)
        local item = pick({ 'phone', 'wallet', 'handbag', 'phone and wallet' })
        local knife = chance(35)
        return {
            title = 'Robbery: victim on scene', mdtType = 'Robbery',
            description = ('Victim at %s says they were robbed of their %s by %s%s.'):format(loc.label, item, desc, knife and ', who showed a knife' or ''),
            sex = sex, desc = desc, item = item, knife = knife, suspectNearby = chance(55), injured = chance(25),
            behaviour = weighted({ flee = 50, compliant = 25, hostile = 15, nervous = 10 }),
        }
    end,
    spawn = function(call)
        local c, plan = call.coords, call.plan
        EN.Spawn(call.id, { role = 'victim', model = model(chance(55) and 'F' or 'M'), coords = c, injured = plan.injured,
            action = plan.injured and 'sit' or 'idle', actionData = { scenario = 'WORLD_HUMAN_STAND_IMPATIENT' },
            statement = ('"%s. Grabbed my %s%s and ran off that way."'):format(plan.desc:gsub('^%l', string.upper), plan.item,
                plan.knife and ', showed me a knife' or '') })
        if not plan.suspectNearby then return end
        local items = { ('Victim\'s %s'):format(plan.item) }
        EN.Spawn(call.id, { role = 'suspect', model = model(plan.sex), coords = offset(c, 30.0 + math.random() * 15.0, math.random(-5, 5)),
            behaviour = plan.knife and 'armed' or plan.behaviour, trigger = 'approach',
            weapon = plan.knife and Config.Callouts.Armed.Weapons.knife or nil, weaponLabel = plan.knife and 'Lock knife' or nil,
            offences = plan.knife and { ROBBERY, BLADE } or { ROBBERY }, finds = items, falseDetails = chance(30),
            action = plan.knife and 'armed' or 'idle', actionData = plan.knife and { weapon = Config.Callouts.Armed.Weapons.knife } or { scenario = 'WORLD_HUMAN_STAND_MOBILE' } })
    end,
})

---------------------------------------------------------------------------
-- Stolen vehicle sighted (becomes an NPC vehicle stop)
---------------------------------------------------------------------------
CO.Register('stolen_vehicle', {
    pool = 'roads', code = '10-STOL',
    outcomes = { 'Vehicle recovered', 'Driver arrested', 'Vehicle failed to stop', 'Not located' },
    plan = function(loc)
        local plate = VPO.NPC.Plate()
        local car = pick(M.cars)
        return {
            title = 'Stolen vehicle sighted', mdtType = 'Vehicle crime',
            description = ('Stolen %s, registration %s, seen on %s a few minutes ago.'):format(car:upper(), plate, loc.label),
            plate = plate, car = car,
        }
    end,
    spawn = function(call)
        local c, plan = call.coords, call.plan
        local hash = GetHashKey(plan.car)
        local veh = CreateVehicleServerSetter and CreateVehicleServerSetter(hash, 'automobile', c.x, c.y, c.z, c.w or 0.0)
            or CreateVehicle(hash, c.x, c.y, c.z, c.w or 0.0, true, true)
        local deadline = GetGameTimer() + 3000
        while (not veh or not DoesEntityExist(veh)) and GetGameTimer() < deadline do Wait(20) end
        if not veh or not DoesEntityExist(veh) then return end
        SetEntityOrphanMode(veh, 2)
        SetVehicleNumberPlateText(veh, plan.plate)
        VPO.NPC.CreateStolen(plan.plate, plan.car)
        local driver = CreatePedInsideVehicle(veh, 4, GetHashKey(model('M')), -1, true, true)
        deadline = GetGameTimer() + 3000
        while (not driver or not DoesEntityExist(driver)) and GetGameTimer() < deadline do Wait(20) end
        if not driver or not DoesEntityExist(driver) then return end
        SetEntityOrphanMode(driver, 2)
        local vnet, pnet = NetworkGetNetworkIdFromEntity(veh), NetworkGetNetworkIdFromEntity(driver)
        call.vehicles[#call.vehicles + 1] = vnet
        call.drivers[#call.drivers + 1] = pnet
        local ctl = CO.Controller(call)
        if ctl then TriggerClientEvent('vinewood_police:client:enc:drive', ctl, { veh = vnet, ped = pnet }) end
        CO.Note(call, ('Vehicle located: %s'):format(plan.plate))
    end,
})

---------------------------------------------------------------------------
-- Missing person (vulnerable adult): reported at one place, really somewhere else
---------------------------------------------------------------------------
CO.Register('missing_person', {
    pool = 'streets', code = '10-57',
    outcomes = { 'Found safe and well', 'Found, taken to hospital', 'Returned home by themselves', 'Not found, handed over to next shift' },
    plan = function(loc)
        -- Where they really are: another street location, not too far
        local options = {}
        for _, l in ipairs(Config.Callouts.Locations.streets or {}) do
            local d = #(vector3(l.coords.x, l.coords.y, l.coords.z) - vector3(loc.coords.x, loc.coords.y, loc.coords.z))
            if d > 150.0 and d < 2500.0 then options[#options + 1] = l end
        end
        local where = #options > 0 and pick(options) or nil
        if not where then return nil end
        local person = VPO.NPC.NewPerson()
        local elderly = chance(70)
        local top = pick(TOPS)
        return {
            title = 'Missing person: vulnerable adult', mdtType = 'Missing person',
            description = ('%s, %s, missing from near %s. %s Last seen wearing %s.'):format(VPO.NPC.FullName(person), elderly and '70s' or '20s',
                loc.label, elderly and 'Has dementia and may be confused.' or 'Family worried for their welfare.', top),
            person = person, elderly = elderly, spawnAt = where.coords, sightingNear = where.label,
        }
    end,
    spawn = function(call)
        local plan = call.plan
        EN.Spawn(call.id, { role = 'subject', person = plan.person, model = plan.elderly and pick(M.elderly) or model(chance(50) and 'M' or 'F'),
            coords = call.spawnAt, behaviour = 'compliant', action = 'idle',
            actionData = { scenario = plan.elderly and 'WORLD_HUMAN_STAND_IMPATIENT' or 'WORLD_HUMAN_STAND_MOBILE' },
            statement = plan.elderly and '"I was going home... this isn\'t my road, is it?"' or '"I just needed some air. I didn\'t mean to worry anyone."' })
    end,
})
