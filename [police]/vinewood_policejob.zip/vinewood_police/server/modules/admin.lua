-- Admin panel: /vpo on its own opens it. Everything the vpo sub-commands do, in one place.
local L = VPO.L

local function admin(src) return VPO.Permissions.IsAdmin(src) end

VPO.Net.Callback('admin:panel', { rate = 'manage' }, function(src)
    if not admin(src) then return { error = L('admin_needs_ace') } end
    local st = VPO.Integrations.Status()
    local integrations = {}
    for name, s in pairs(st) do
        integrations[#integrations + 1] = { name = name, available = s.available == true, resource = s.resource, version = s.version, limited = s.limited,
            reason = s.available and nil or (s.reason == 'not_running' and ('not running (looked for %s)'):format(s.lookedFor or '?') or s.reason) }
    end
    table.sort(integrations, function(a, b) return a.name < b.name end)
    local scenarios = {}
    for id, sc in pairs(Config.Callouts.Scenarios) do scenarios[#scenarios + 1] = { id = id, weight = sc.weight } end
    table.sort(scenarios, function(a, b) return a.id < b.id end)
    local players = {}
    for _, id in ipairs(GetPlayers()) do
        local p = tonumber(id)
        players[#players + 1] = { src = p, name = GetPlayerName(p), cuffed = VPO.Restraint.IsCuffed(p), me = p == src }
    end
    table.sort(players, function(a, b) return a.src < b.src end)
    local o = VPO.Officers.Get(src)
    local out = o and VPO.Hub.Header(src, o) or { force = Config.Force.name, officer = { label = GetPlayerName(src) }, statuses = VPO.Hub.StatusList() }
    out.ok = true
    out.version = GetResourceMetadata(VPO.Resource, 'version', 0)
    out.ready = VPO.Ready == true
    out.framework = VPO.Bridge.Name
    out.inventory = VPO.Inventory.Name
    out.integrations = integrations
    out.callouts = VPO.Callouts.Status()
    out.scenarios = scenarios
    out.players = players
    return out
end)

VPO.Net.Callback('admin:callouts', { rate = 'manage' }, function(src, _, d)
    if not admin(src) then return { error = L('admin_needs_ace') } end
    d = type(d) == 'table' and d or {}
    VPO.Callouts.SetEnabled(d.on == true, GetPlayerName(src))
    local cleared = (not d.on and d.clear) and VPO.Callouts.CancelPending() or 0
    VPO.Audit.Log({ action = d.on and 'callouts.on' or 'callouts.off', actor = src, source = 'admin', meta = { cancelled = cleared } })
    return { ok = true, message = d.on and L('callouts_now_on') or (cleared > 0 and L('callouts_now_off_cleared', cleared) or L('callouts_now_off')),
        callouts = VPO.Callouts.Status() }
end)

VPO.Net.Callback('admin:callout', { rate = 'manage' }, function(src, _, d)
    if not admin(src) then return { error = L('admin_needs_ace') } end
    local call, why = VPO.Callouts.AdminCreate(src, type(d) == 'table' and d.scenario or nil)
    if not call then return { error = ('Callout not created: %s'):format(tostring(why)) } end
    return { ok = true, message = ('%s: %s at %s'):format(call.ref, call.title, call.location), callouts = VPO.Callouts.Status() }
end)

VPO.Net.Callback('admin:uncuff', { rate = 'manage' }, function(src, _, d)
    if not admin(src) then return { error = L('admin_needs_ace') } end
    local target = tonumber(type(d) == 'table' and d.target or nil)
    if not target or not GetPlayerName(target) then return { error = L('restraint_no_target') } end
    VPO.Restraint.Release(target, 'admin', src)
    VPO.Restraint.StopEscort(target, 'admin')
    return { ok = true, message = ('%s released from restraints.'):format(GetPlayerName(target)) }
end)

VPO.Net.Callback('admin:acecheck', { rate = 'manage' }, function(src, _, d)
    if not admin(src) then return { error = L('admin_needs_ace') } end
    local target = tonumber(type(d) == 'table' and d.target or nil)
    if not target or not GetPlayerName(target) then return { error = L('restraint_no_target') } end
    return { ok = true, name = GetPlayerName(target), checks = VPO.Permissions.AdminReport(target) }
end)

---------------------------------------------------------------------------
-- Qualifications for testing: give yourself (or anyone online) any qualification, or all of them.
-- Admin grants skip the rank and sign-off rules, like /qualgrant from an admin.
---------------------------------------------------------------------------
local function adminActor(src)
    return { source = 'admin', src = src, identifier = VPO.Bridge.GetIdentifier(src), name = ('%s (admin)'):format(GetPlayerName(src)) }
end

local function qualView(target)
    local id = VPO.Bridge.GetIdentifier(target)
    local held = id and VPO.Qualifications.List(id) or {}
    local have = {}
    for _, q in ipairs(held) do if q.valid then have[q.id] = true end end
    local defs = {}
    for _, q in ipairs(Config.Qualifications) do defs[#defs + 1] = { id = q.id, label = q.label, held = have[q.id] == true } end
    return { target = target, name = GetPlayerName(target), defs = defs }
end

VPO.Net.Callback('admin:quals', { rate = 'manage' }, function(src, _, d)
    if not admin(src) then return { error = L('admin_needs_ace') } end
    if not Config.AllowAdminQualifications then return { error = L('admin_quals_off') } end
    local target = tonumber(type(d) == 'table' and d.target or nil) or src
    if not GetPlayerName(target) then return { error = L('restraint_no_target') } end
    local id = VPO.Bridge.GetIdentifier(target)
    if not id then return { error = L('restraint_no_target') } end
    d = type(d) == 'table' and d or {}
    local actor = adminActor(src)
    local changed = 0
    local function grant(q)
        local ok = VPO.Qualifications.Grant(actor, id, q, nil, 'Admin testing')
        if ok then changed = changed + 1 end
    end
    if d.op == 'grant' and d.qual then grant(d.qual)
    elseif d.op == 'revoke' and d.qual then
        if VPO.Qualifications.Revoke(actor, id, d.qual, 'Admin testing') then changed = 1 end
    elseif d.op == 'all' then
        -- Prerequisites first (basic before response before advanced driver), so every grant goes through
        local have = {}
        for _, q in ipairs(VPO.Qualifications.List(id)) do if q.valid then have[q.id] = true end end
        local progress = true
        while progress do
            progress = false
            for _, q in ipairs(Config.Qualifications) do
                if not have[q.id] and VPO.Qualifications.Grant(actor, id, q.id, nil, 'Admin testing') then
                    have[q.id], changed, progress = true, changed + 1, true
                end
            end
        end
    elseif d.op == 'none' then
        for _, q in ipairs(VPO.Qualifications.List(id)) do
            if VPO.Qualifications.Revoke(actor, id, q.id, 'Admin testing') then changed = changed + 1 end
        end
    end
    local out = qualView(target)
    out.ok, out.changed = true, changed
    return out
end)
