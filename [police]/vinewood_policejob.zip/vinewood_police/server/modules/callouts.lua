-- Callout engine: makes calls, sends them out, brings scenes to life when officers arrive, and closes them.
VPO.Callouts = {}
local CO = VPO.Callouts
local Cfg = Config.Callouts
local L = VPO.L
local calls = {}       -- [id] = call
local scenarios = {}   -- [id] = definition (server/modules/callouts_scenarios.lua)

function CO.Register(id, def) scenarios[id] = def end
function CO.Get(id) return calls[tonumber(id) or 0] end

local function ped(src) local p = GetPlayerPed(src); return (p and p ~= 0) and p or nil end
local function v3(c) return vector3(c.x, c.y, c.z) end

local function dispatch() return VPO.Integrations.Get('dispatch') end

local function onDutyCount()
    local n = 0
    for _ in pairs(VPO.Duty.All()) do n = n + 1 end
    return n
end

function CO.Note(call, text, author)
    call.notes[#call.notes + 1] = { at = os.time(), text = text, by = author }
    local d = dispatch()
    if d and call.alertId then
        local ok = pcall(d.AddNote, call.alertId, text, author or 'Control')
        if not ok then VPO.Log.debug('dispatch note failed') end
    end
end

--- Officers signed on as Armed response.
function CO.ArvOnDuty()
    local n = 0
    for _, s in pairs(VPO.Duty.All()) do if s.unit == 'arv' then n = n + 1 end end
    return n
end

local function alert(title, description, priority, coords)
    local d = dispatch()
    if d then
        local ok = pcall(d.CreateAlert, { title = title, description = description, priority = priority, services = { 'police' },
            coords = vector3(coords.x, coords.y, coords.z), code = priority == 1 and '10-99' or '10-32' })
        if ok then return end
    end
    for src in pairs(VPO.Duty.All()) do VPO.Notify(src, ('%s: %s'):format(title, description), priority == 1 and 'error' or 'inform', 10000) end
end

--- A scene has turned violent: one urgent assistance call per call.
function CO.Escalate(call, what)
    if not Config.Callouts.AutoUrgentAssistance or call.escalated then return end
    call.escalated = true
    CO.Note(call, what)
    alert(L('calls_urgent_title'), L('calls_urgent_text', call.title, call.location, what), 1, call.coords)
end

--- An officer asks for backup at a call.
function CO.Backup(call, src, urgent)
    local who = VPO.Officers.Label(VPO.Officers.Get(src))
    local p = ped(src)
    local c = p and GetEntityCoords(p) or v3(call.coords)
    CO.Note(call, ('%s requested %s'):format(who, urgent and 'urgent assistance' or 'backup'))
    alert(urgent and L('calls_urgent_title') or L('calls_backup_title'), L('calls_backup_text', who, call.title, call.location), urgent and 1 or 2,
        { x = c.x, y = c.y, z = c.z })
end

function CO.Attend(call, src)
    if call.officers[src] then return end
    call.officers[src] = true
    call.attendedAt = call.attendedAt or os.time()
    if call.status == 'pending' then call.status = 'attending' end
end

--- Officer whose game moves the scene's peds: the closest attending officer still online.
function CO.Controller(call)
    if call.controller and GetPlayerName(call.controller) and VPO.IsOnDuty(call.controller) == true then return call.controller end
    local best, bestD
    for src in pairs(VPO.Duty.All()) do
        local p = ped(src)
        if p then
            local dd = #(GetEntityCoords(p) - v3(call.coords))
            if dd < 300.0 and (not bestD or dd < bestD) then best, bestD = src, dd end
        end
    end
    call.controller = best
    return best
end

---------------------------------------------------------------------------
-- Creating calls
---------------------------------------------------------------------------
local function locationFree(loc)
    for _, c in pairs(calls) do
        if #(v3(c.coords) - v3(loc.coords)) < Cfg.MinSpacing then return false end
    end
    return true
end

local function pickLocation(pool)
    local list = Cfg.Locations[pool] or {}
    local tries = {}
    for i = 1, #list do tries[i] = list[i] end
    for i = #tries, 2, -1 do local j = math.random(1, i); tries[i], tries[j] = tries[j], tries[i] end
    for _, loc in ipairs(tries) do if locationFree(loc) then return loc end end
    return nil
end

--- Creates a call. scenarioId optional (weighted pick otherwise); loc optional (admin testing).
function CO.Create(scenarioId, loc)
    local officers = onDutyCount()
    if not scenarioId then
        local weights = {}
        for id, s in pairs(Cfg.Scenarios) do
            if scenarios[id] and (s.weight or 0) > 0 and officers >= (s.minOfficers or 1) then weights[id] = s.weight end
        end
        if not next(weights) then return nil end
        scenarioId = VPO.NPC.Weighted(weights)
    end
    local def, sc = scenarios[scenarioId], Cfg.Scenarios[scenarioId] or {}
    if not def then return nil, 'unknown scenario' end
    loc = loc or pickLocation(def.pool)
    if not loc then return nil, 'no free location' end

    if def.ready and not def.ready() then return nil, 'not ready' end
    local plan = def.plan(loc) -- decides what's really going on before anyone arrives
    if not plan then return nil, 'no plan' end
    local t = os.time()
    local id = MySQL.insert.await([[INSERT INTO vpo_callouts (scenario, title, location, coords, priority, created_at) VALUES (?, ?, ?, ?, ?, ?)]],
        { scenarioId, plan.title, loc.label, json.encode({ x = loc.coords.x, y = loc.coords.y, z = loc.coords.z }), sc.priority or 3, t })
    if not id then return nil, 'database' end
    local ref = ('CAD/%s/%s/%05d'):format(Config.Force.short, os.date('%y%m'), id)
    MySQL.update('UPDATE vpo_callouts SET ref = ? WHERE id = ?', { ref, id })
    local call = {
        id = id, ref = ref, scenario = scenarioId, title = plan.title, description = plan.description, location = loc.label,
        coords = loc.coords, priority = sc.priority or 3, plan = plan, status = 'pending', createdAt = t,
        officers = {}, notes = {}, people = {}, vehicles = {}, drivers = {}, outcomes = def.outcomes,
        spawnAt = plan.spawnAt, -- where the scene really is, if not where it was reported (missing people)
    }
    calls[id] = call

    local d = dispatch()
    if d then
        local ok, alertId = pcall(function()
            return d.CreateAlert({
                title = plan.title, description = plan.description, priority = call.priority, services = { 'police' },
                coords = vector3(loc.coords.x, loc.coords.y, loc.coords.z), code = def.code,
            })
        end)
        if ok then call.alertId = alertId end
    else
        for src in pairs(VPO.Duty.All()) do VPO.Notify(src, L('calls_new', plan.title, loc.label), 'inform', 8000) end
    end
    VPO.Log.debug('Callout %s: %s at %s', ref, scenarioId, loc.label)
    return call
end

---------------------------------------------------------------------------
-- Bringing a scene to life, and clearing it away
---------------------------------------------------------------------------
local function activate(call)
    call.status = 'active'
    call.activatedAt = os.time()
    CO.Controller(call)
    local def = scenarios[call.scenario]
    local ok, err = pcall(def.spawn, call)
    if not ok then VPO.Log.error('Callout %s failed to spawn: %s', call.ref, err) end
end

local function cleanup(call)
    for _, p in ipairs(VPO.Encounters.ForCall(call.id)) do
        if p.state == 'arrested' then
            -- Still under arrest when the call closed: transport takes them anyway
            local any = next(call.officers) or call.controller
            if any then
                VPO.CustodyNpc.ReceiveFrom(any, { arrest = p.arrest, personId = p.profile.id, sourceRef = call.ref,
                    evidence = { exhibits = p.exhibits, tests = p.tests, details = p.given, fingerprint = p.fingerprint } })
            end
            VPO.Encounters.Control(p, 'handover')
            VPO.Encounters.Remove(p.id, true)
        else
            VPO.Encounters.Control(p, 'release')
            VPO.Encounters.Remove(p.id, true)
        end
    end
    for _, net in ipairs(call.vehicles) do
        local v = NetworkGetEntityFromNetworkId(net)
        if v and v ~= 0 and DoesEntityExist(v) then SetEntityOrphanMode(v, 0) end
    end
    for _, net in ipairs(call.drivers) do
        local p = NetworkGetEntityFromNetworkId(net)
        if p and p ~= 0 and DoesEntityExist(p) then SetEntityOrphanMode(p, 0) end
    end
end

--- Closes a call with an outcome. src = closing officer (nil = system).
function CO.Close(call, outcome, notes, src)
    if not calls[call.id] then return end
    calls[call.id] = nil
    cleanup(call)
    local officers = {}
    for o in pairs(call.officers) do officers[#officers + 1] = VPO.Officers.Label(VPO.Officers.Get(o)) end
    local mdtRef
    local m = VPO.Integrations.Get('mdt')
    if src and Cfg.CreateMdtIncident and m and m.canWrite and call.attendedAt then
        local res = VPO.Integrations.Call('mdt', 'Request', src, 'createIncident', {
            type = call.plan.mdtType or 'Other', location = call.location,
            coords = { x = call.coords.x, y = call.coords.y, z = call.coords.z },
            narrative = ('%s (%s). Outcome: %s.%s'):format(call.title, call.ref, outcome, notes and ('\n' .. notes) or ''),
        })
        if type(res) == 'table' and res.ref then mdtRef = res.ref end
    end
    MySQL.update([[UPDATE vpo_callouts SET status = 'closed', outcome = ?, notes = ?, officers = ?, mdt_incident = ?, attended_at = ?, closed_at = ? WHERE id = ?]],
        { outcome, json.encode({ text = notes, log = call.notes }), json.encode(officers), mdtRef, call.attendedAt, os.time(), call.id })
    local d = dispatch()
    if d and call.alertId then pcall(d.CloseAlert, call.alertId) end
    if src then VPO.Duty.AddStat(src, 'callsClosed', 1) end
    VPO.Audit.Log({ action = 'calls.close', actor = src, targetType = 'call', targetId = call.ref, new = { outcome = outcome, mdt = mdtRef } })
    return mdtRef
end

---------------------------------------------------------------------------
-- Scheduler and scene watcher
---------------------------------------------------------------------------
CreateThread(function()
    while true do
        Wait(60000)
        if Cfg.Enabled and VPO.Ready then
            local officers = onDutyCount()
            local open = 0
            for _ in pairs(calls) do open = open + 1 end
            local limit = math.min(Cfg.MaxActive, math.ceil(officers * Cfg.PerOfficer))
            if officers >= Cfg.MinOfficers and open < limit and math.random(1, 100) <= Cfg.ChancePerMinute then
                CO.Create()
            end
        end
    end
end)

CreateThread(function()
    while true do
        Wait(2000)
        local now = os.time()
        for _, call in pairs(calls) do
            local near300, nearAct = false, false
            for src in pairs(VPO.Duty.All()) do
                local p = ped(src)
                if p then
                    local here = GetEntityCoords(p)
                    local dd = #(here - v3(call.coords))
                    local ds = call.spawnAt and #(here - v3(call.spawnAt)) or dd
                    if math.min(dd, ds) <= 300.0 then near300 = true end
                    if dd <= Cfg.ActivationDistance then CO.Attend(call, src) end
                    if ds <= Cfg.ActivationDistance then nearAct = true; CO.Attend(call, src) end
                end
            end
            -- Missing people: a sighting near where they really are, after a while
            if call.spawnAt and not call.sighted and now - call.createdAt > Cfg.MissingSightingAfter * 60 then
                call.sighted = true
                CO.Note(call, L('calls_sighting', call.plan.sightingNear or '?'))
            end
            if (call.status == 'pending' or call.status == 'attending') and not call.activatedAt then
                if nearAct then
                    CreateThread(function() activate(call) end)
                    call.activatedAt = now
                elseif not next(call.officers) and now - call.createdAt > Cfg.Unattended * 60 then
                    CO.Close(call, 'No police attendance', nil, nil)
                elseif next(call.officers) and now - call.createdAt > Cfg.Unattended * 3 * 60 then
                    -- Attended but never found (missing people, stolen cars that have gone)
                    CO.Close(call, 'Not located', nil, nil)
                end
            elseif call.activatedAt then
                if near300 then call.lastNear = now
                elseif now - (call.lastNear or call.activatedAt) > Cfg.Abandoned * 60 then
                    CO.Close(call, 'Officers left the scene', nil, nil)
                end
            end
        end
    end
end)

-- Responding through vinewood-dispatch counts as attending
AddEventHandler('vinewood-dispatch:server:responderAttached', function(alertId, src)
    for _, call in pairs(calls) do
        if call.alertId == alertId then CO.Attend(call, tonumber(src)) end
    end
end)

---------------------------------------------------------------------------
-- Call panel and the built-in call list
---------------------------------------------------------------------------
local function callView(call, src)
    local p = ped(src)
    local people = {}
    for _, x in ipairs(VPO.Encounters.ForCall(call.id)) do people[#people + 1] = VPO.Encounters.Summary(x) end
    return {
        id = call.id, ref = call.ref, title = call.title, description = call.description, location = call.location, priority = call.priority,
        status = call.status, createdAt = call.createdAt, attending = call.officers[src] == true,
        distance = p and math.floor(#(GetEntityCoords(p) - v3(call.coords))) or nil,
        coords = { x = call.coords.x, y = call.coords.y, z = call.coords.z }, people = people, notes = call.notes, outcomes = call.outcomes,
    }
end

VPO.Net.Callback('call:list', { permission = 'calls.attend', rate = 'calls' }, function(src, o)
    local list = {}
    for _, call in pairs(calls) do list[#list + 1] = callView(call, src) end
    table.sort(list, function(a, b) return a.priority < b.priority or (a.priority == b.priority and a.createdAt < b.createdAt) end)
    local out = VPO.Hub.Header(src, o)
    out.ok, out.calls, out.dispatch = true, list, dispatch() ~= nil
    return out
end)

VPO.Net.Callback('call:open', { permission = 'calls.attend', rate = 'calls' }, function(src, o, d)
    local call = CO.Get(type(d) == 'table' and d.id or nil)
    if not call then return { error = L('calls_closed') } end
    local out = VPO.Hub.Header(src, o)
    out.ok, out.call = true, callView(call, src)
    return out
end)

VPO.Net.Callback('call:attach', { permission = 'calls.attend', rate = 'calls' }, function(src, _, d)
    local call = CO.Get(type(d) == 'table' and d.id or nil)
    if not call then return { error = L('calls_closed') } end
    CO.Attend(call, src)
    local dd = dispatch()
    if dd and call.alertId then pcall(dd.ToggleResponder, call.alertId, src) end
    return { ok = true, coords = { x = call.coords.x, y = call.coords.y, z = call.coords.z } }
end)

VPO.Net.Callback('call:backup', { permission = 'calls.attend', rate = 'calls' }, function(src, _, d)
    d = type(d) == 'table' and d or {}
    local call = CO.Get(d.id)
    if not call then return { error = L('calls_closed') } end
    if not call.officers[src] then return { error = L('calls_attach_first') } end
    if call.lastBackup and os.time() - call.lastBackup < 30 then return { error = L('rate_limited') } end
    call.lastBackup = os.time()
    CO.Backup(call, src, d.urgent == true)
    return { ok = true, message = L(d.urgent and 'calls_urgent_sent' or 'calls_backup_sent') }
end)

VPO.Net.Callback('call:close', { permission = 'calls.attend', rate = 'calls' }, function(src, o, d)
    d = type(d) == 'table' and d or {}
    local call = CO.Get(d.id)
    if not call then return { error = L('calls_closed') } end
    local p = ped(src)
    local here = p and GetEntityCoords(p)
    if not here or (#(here - v3(call.coords)) > 150.0 and not (call.spawnAt and #(here - v3(call.spawnAt)) <= 150.0)) then
        return { error = L('calls_be_there') }
    end
    if not VPO.Util.Contains(call.outcomes, d.outcome) then return { error = L('roads_pick_outcome') } end
    -- Arrest references from the scene, for a CID referral
    local links = { call.ref }
    for _, p in ipairs(VPO.Encounters.ForCall(call.id)) do if p.arrest then links[#links + 1] = p.arrest.ref end end
    local notes = VPO.Util.Trim(d.notes, 1000)
    local mdtRef = CO.Close(call, d.outcome, notes, src)
    local caseRef
    if d.referCid and o and VPO.Permissions.Check(src, 'cid.create') then
        if mdtRef then links[#links + 1] = mdtRef end
        local _, ref = VPO.Cases.Create(src, o, { title = ('%s, %s'):format(call.title, call.location), type = call.plan.mdtType,
            summary = ('%s\nOutcome at scene: %s'):format(notes or call.description or '', d.outcome), links = links })
        caseRef = ref
    end
    return { ok = true, ref = call.ref, mdt = mdtRef, case = caseRef }
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= VPO.Resource then return end
    for _, call in pairs(calls) do
        local d = dispatch()
        if d and call.alertId then pcall(d.CloseAlert, call.alertId) end
        for _, net in ipairs(call.vehicles) do
            local v = NetworkGetEntityFromNetworkId(net)
            if v and v ~= 0 and DoesEntityExist(v) then DeleteEntity(v) end
        end
    end
end)

-- Testing: /vpo callout <scenario> spawns one at the nearest location for that scenario
function CO.AdminCreate(src, scenarioId)
    local def = scenarios[scenarioId]
    if not def then return nil, 'unknown scenario' end
    local p = src ~= 0 and ped(src)
    local best, bestD
    for _, loc in ipairs(Cfg.Locations[def.pool] or {}) do
        local dd = p and #(GetEntityCoords(p) - v3(loc.coords)) or 0
        if locationFree(loc) and (not bestD or dd < bestD) then best, bestD = loc, dd end
    end
    if not best then return nil, 'no free location' end
    return CO.Create(scenarioId, best)
end

-- A stolen vehicle call ends with the vehicle stop that dealt with it.
VPO.Roads.OnClose(function(stop, outcome)
    for _, call in pairs(calls) do
        if call.plan.plate and call.plan.plate == stop.plate then
            local mapped = (outcome == 'Failed to stop' or outcome == 'Made off on foot') and 'Vehicle failed to stop'
                or (outcome == 'Arrest' and 'Driver arrested') or 'Vehicle recovered'
            CO.Note(call, ('Vehicle stop %s: %s'):format(stop.ref, outcome or '-'))
            CO.Close(call, mapped, nil, stop.officer and GetPlayerName(stop.officer) and stop.officer or nil)
        end
    end
end)

---------------------------------------------------------------------------
-- Switching automatic callouts on and off in game (vpo callouts on|off). The choice is kept in the
-- database, so it survives restarts until changed again; the config value is the default.
---------------------------------------------------------------------------
local SETTING = 'setting:callouts'

function CO.SetEnabled(on, by)
    Cfg.Enabled = on == true
    MySQL.insert.await([[INSERT INTO vpo_locations (`key`, data, updated_at, updated_by) VALUES (?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE data = VALUES(data), updated_at = VALUES(updated_at), updated_by = VALUES(updated_by)]],
        { SETTING, json.encode({ enabled = Cfg.Enabled }), os.time(), by })
end

--- Closes calls nobody has reached yet (scenes already running are left alone).
function CO.CancelPending()
    local n = 0
    for _, call in pairs(calls) do
        if not call.activatedAt then
            CO.Close(call, 'Cancelled', nil, nil)
            n = n + 1
        end
    end
    return n
end

function CO.Status()
    local open, active = 0, 0
    for _, call in pairs(calls) do
        open = open + 1
        if call.activatedAt then active = active + 1 end
    end
    return { enabled = Cfg.Enabled == true, open = open, active = active }
end

AddEventHandler(VPO.Events.ready, function()
    local raw = MySQL.scalar.await('SELECT data FROM vpo_locations WHERE `key` = ?', { SETTING })
    if raw then
        local ok, v = pcall(json.decode, raw)
        if ok and type(v) == 'table' and v.enabled ~= nil then
            Cfg.Enabled = v.enabled == true
            VPO.Log.info('Automatic callouts are %s (set in game)', Cfg.Enabled and 'on' or 'off')
        end
    end
end)

--- Backup or urgent assistance at the officer's position, not tied to a call (radial menu).
local lastHere = {}
VPO.Net.Callback('call:backupHere', { permission = 'calls.attend', rate = 'calls' }, function(src, o, d)
    d = type(d) == 'table' and d or {}
    if lastHere[src] and os.time() - lastHere[src] < 30 then return { error = L('rate_limited') } end
    lastHere[src] = os.time()
    local c = GetEntityCoords(GetPlayerPed(src))
    local where = VPO.Util.Trim(d.location, 120) or 'their location'
    local who = VPO.Officers.Label(o)
    alert(d.urgent and L('calls_urgent_title') or L('calls_backup_title'),
        L('calls_backup_here', who, where), d.urgent and 1 or 2, { x = c.x, y = c.y, z = c.z })
    VPO.Audit.Log({ action = d.urgent and 'calls.urgent' or 'calls.backup', actor = src, reason = where })
    return { ok = true, message = L(d.urgent and 'calls_urgent_sent' or 'calls_backup_sent') }
end)
AddEventHandler('playerDropped', function() lastHere[source] = nil end)
