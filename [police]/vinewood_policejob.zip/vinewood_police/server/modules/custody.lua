-- Custody suite: booking in, property, cells, welfare checks, the custody log and release.
-- The detainee's 'custody' state (set at arrest, persisted) carries everything about their detention,
-- so a relog or restart puts them straight back in their cell.
--
-- custody = { arrestId, ref, mdtRecordId, name, at, by, byLabel, offences,
--             booked = { at, by, suite, grounds, risk, observation }, cell = { suite, id },
--             out = reason | nil, nextWelfare, property = stashId }
VPO.Custody = {}
local CU = VPO.Custody
local Cfg = Config.Custody
local L = VPO.L
local overdueNotified = {} -- [arrestId] = os.time()

-- Suites can be edited in game, so they're always looked up from the live config.
local function suiteById(id)
    for _, s in ipairs(Config.Custody.Suites) do if s.id == id then return s end end
    return nil
end
local obsByLevel = {}
for _, o in ipairs(Cfg.Observation) do obsByLevel[o.level] = o end

local function ped(src)
    local p = GetPlayerPed(src)
    return (p and p ~= 0) and p or nil
end

local function coordsOf(src) local p = ped(src); return p and GetEntityCoords(p) or nil end

local function v3(v) return vector3(v.x, v.y, v.z) end

local function dist(a, b) if not a or not b then return math.huge end return #(a - b) end

--- Suite the player is standing in, or nil.
function CU.SuiteAt(src)
    local c = coordsOf(src)
    if not c then return nil end
    for _, s in ipairs(Config.Custody.Suites) do
        if dist(c, s.desk.coords) <= Cfg.AreaRadius then return s end
    end
    return nil
end

local function atDesk(src, suite) return dist(coordsOf(src), suite.desk.coords) <= Cfg.DeskRadius end

function CU.Get(src) return VPO.State.Get(src, 'custody') end

local function save(src, c) VPO.State.Set(src, 'custody', c) end

---------------------------------------------------------------------------
-- Custody log
---------------------------------------------------------------------------
function CU.Log(arrestId, kind, text, officer)
    if not arrestId then return end
    MySQL.insert('INSERT INTO vpo_custody_log (arrest_id, created_at, kind, text, officer) VALUES (?, ?, ?, ?, ?)',
        { arrestId, os.time(), kind, tostring(text):sub(1, 2000), officer })
end

local function officerLabel(src) return VPO.Officers.Label(VPO.Officers.Get(src)) end

---------------------------------------------------------------------------
-- Moving people
---------------------------------------------------------------------------
local function teleport(src, c4)
    TriggerClientEvent('vinewood_police:client:custody:teleport', src, { x = c4.x, y = c4.y, z = c4.z, w = c4.w or 0.0 })
end

local function cellDef(c)
    local s = c and c.cell and suiteById(c.cell.suite)
    if not s then return nil end
    for _, cell in ipairs(s.cells) do if cell.id == c.cell.id then return cell, s end end
    return nil
end

--- Who is in each cell of a suite: { [cellId] = src }
local function occupancy(suite)
    local out = {}
    for _, id in ipairs(GetPlayers()) do
        local src = tonumber(id)
        local c = CU.Get(src)
        if c and c.cell and c.cell.suite == suite.id then out[c.cell.id] = src end
    end
    return out
end

--- Is a cell taken by anyone (player or NPC) other than the given NPC detainee?
function CU.CellTaken(suite, cellId, exceptNpc)
    if occupancy(suite)[cellId] then return true end
    for id in pairs(VPO.CustodyNpc and VPO.CustodyNpc.Occupied(suite) or {}) do
        if id == cellId then
            for _, r in ipairs(VPO.CustodyNpc.ForSuite(suite)) do
                if r.cellId == cellId and r.id ~= exceptNpc then return true end
            end
        end
    end
    return false
end

---------------------------------------------------------------------------
-- Panel data
---------------------------------------------------------------------------
local function custodyHours(at)
    return math.floor((os.time() - (at or os.time())) / 60 / (Cfg.HourLength or 2) * 10) / 10
end

local function detaineeView(src, c)
    local cell = cellDef(c)
    local now = os.time()
    return {
        src = src, name = c.name or VPO.Bridge.GetName(src), ref = c.ref, at = c.at, byLabel = c.byLabel, offences = c.offences,
        hours = custodyHours(c.at), limit = Cfg.LimitHours,
        booked = c.booked and { at = c.booked.at, by = c.booked.by, grounds = c.booked.grounds, risk = c.booked.risk,
            observation = c.booked.observation, observationLabel = (obsByLevel[c.booked.observation] or {}).label } or nil,
        cell = cell and cell.label or nil, cellId = c.cell and c.cell.id or nil, out = c.out,
        welfareDue = c.nextWelfare, welfareOverdue = c.nextWelfare ~= nil and c.nextWelfare < now and c.out == nil,
        property = c.property ~= nil, cuffed = VPO.Restraint.IsCuffed(src),
    }
end

VPO.Net.Callback('custody:panel', { permission = 'custody.view', rate = 'custody' }, function(src, o)
    local suite = CU.SuiteAt(src)
    if not suite then return { error = L('custody_go_to_suite') } end
    local people, nearProperty = {}, {}
    local notArrested = {}
    local me = coordsOf(src)
    for _, id in ipairs(GetPlayers()) do
        local p = tonumber(id)
        local c = CU.Get(p)
        local pc = coordsOf(p)
        if c and (c.cell and c.cell.suite == suite.id or dist(pc, suite.desk.coords) <= Cfg.AreaRadius) then
            people[#people + 1] = detaineeView(p, c)
        elseif not c and p ~= src and dist(pc, suite.desk.coords) <= Cfg.AreaRadius
            and (VPO.Restraint.IsCuffed(p) or VPO.Restraint.EscortedBy(p)) and VPO.IsOnDuty(p) ~= true then
            -- Brought in handcuffed but never arrested: they can't be booked in until they are
            notArrested[#notArrested + 1] = { src = p, name = VPO.Bridge.GetName(p) or GetPlayerName(p) }
        elseif not c and p ~= src and dist(pc, me) <= 6.0 then
            -- People back for their property
            local ident = VPO.Bridge.GetIdentifier(p)
            local n = ident and MySQL.scalar.await("SELECT COUNT(*) FROM vpo_custody WHERE identifier = ? AND property_status IN ('held', 'retained')", { ident }) or 0
            if n > 0 then nearProperty[#nearProperty + 1] = { src = p, name = VPO.Bridge.GetName(p), bags = n } end
        end
    end
    for _, n in ipairs(VPO.CustodyNpc.ForSuite(suite)) do people[#people + 1] = n end
    table.sort(people, function(a, b) return (a.at or 0) < (b.at or 0) end)
    local occ, npcOcc = occupancy(suite), VPO.CustodyNpc.Occupied(suite)
    local cells = {}
    local inCell = {}
    for _, p in ipairs(people) do if p.cellId then inCell[p.cellId] = p end end
    for _, cell in ipairs(suite.cells) do
        local who = inCell[cell.id]
        cells[#cells + 1] = {
            id = cell.id, label = cell.label, free = occ[cell.id] == nil and not npcOcc[cell.id],
            occupant = who and who.name or nil, npc = who and who.npc or nil, out = who and who.out or nil,
            welfareOverdue = who and who.welfareOverdue or nil, risk = who and who.booked and who.booked.risk or nil,
            door = cell.door and (CU.DoorLocked(suite.id, cell.id) and 'locked' or 'open') or nil,
        }
        local at, isMuted = CU.BuzzState(suite.id, cell.id)
        cells[#cells].buzzing, cells[#cells].muted = at, isMuted
        for _, cam in ipairs(suite.cameras or {}) do if cam.cell == cell.id then cells[#cells].camera = cam.id end end
    end
    local out = VPO.Hub.Header(src, o)
    out.ok = true
    out.suite = { id = suite.id, label = suite.label }
    out.detainees, out.cells, out.nearProperty = people, cells, nearProperty
    out.cameraCount = #(suite.cameras or {})
    out.buzzer = Config.Custody.Buzzer and Config.Custody.Buzzer.Enabled or false
    local okBook, why, extra = VPO.Permissions.Check(src, 'custody.book')
    out.canBook = okBook == true
    out.canBookWhy = not okBook and VPO.Permissions.Message(why, extra) or nil
    out.notArrested = notArrested
    out.grounds, out.observation, out.outReasons, out.outcomes = Cfg.DetentionGrounds, Cfg.Observation, Cfg.OutReasons, Cfg.ReleaseOutcomes
    out.npcOutcomes = Cfg.NpcOutcomes
    out.mdt = VPO.Integrations.Get('mdt') ~= nil
    out.canStash = Cfg.TakeProperty and VPO.Inventory.CanStash()
    return out
end)

VPO.Net.Callback('custody:log', { permission = 'custody.view', rate = 'custody' }, function(src, _, d)
    d = type(d) == 'table' and d or {}
    local arrestId
    if d.npc then
        arrestId = tonumber(d.npc)
    else
        local target = tonumber(d.target)
        local c = target and CU.Get(target)
        if not c then return { error = L('custody_not_detained') } end
        arrestId = c.arrestId
    end
    local rows = MySQL.query.await('SELECT created_at, kind, text, officer FROM vpo_custody_log WHERE arrest_id = ? ORDER BY id DESC LIMIT 100', { arrestId }) or {}
    return { ok = true, log = rows }
end)

---------------------------------------------------------------------------
-- Actions (each checks where everyone is standing)
---------------------------------------------------------------------------
local function detainee(src, d, maxDist)
    local target = tonumber(type(d) == 'table' and d.target or nil)
    if not target or not GetPlayerName(target) then return nil, nil, nil, L('restraint_no_target') end
    local c = CU.Get(target)
    if not c then return nil, nil, nil, L('custody_not_detained') end
    local suite = CU.SuiteAt(src)
    if not suite then return nil, nil, nil, L('custody_go_to_suite') end
    if maxDist and dist(coordsOf(src), coordsOf(target)) > maxDist then return nil, nil, nil, L('restraint_too_far') end
    return target, c, suite
end

VPO.Net.Callback('custody:bookIn', { permission = 'custody.book', rate = 'custody' }, function(src, o, d)
    local target, c, suite, err = detainee(src, d, 6.0)
    if not target then return { error = err } end
    if c.booked then return { error = L('custody_already_booked') } end
    if not atDesk(src, suite) or dist(coordsOf(target), suite.desk.coords) > Cfg.DeskRadius + 2.0 then return { error = L('custody_at_desk') } end

    if d.authorise == false then
        -- Detention not authorised: release from arrest at the desk
        local reason = VPO.Util.Trim(d.notes, 500) or 'Detention not authorised'
        CU.Release(target, 'Detention not authorised', reason, src)
        return { ok = true, released = true }
    end
    if not VPO.Util.Contains(Cfg.DetentionGrounds, d.grounds) then return { error = L('custody_pick_grounds') } end
    local obs = obsByLevel[tonumber(d.observation) or 0]
    if not obs then return { error = L('custody_pick_observation') } end
    local risk = (d.risk == 'medium' or d.risk == 'high') and d.risk or 'low'
    if d.rights ~= true then return { error = L('custody_need_rights') } end

    c = VPO.Util.Copy(c)
    c.booked = { at = os.time(), by = VPO.Officers.Label(o), suite = suite.id, grounds = d.grounds, risk = risk, observation = obs.level }
    c.nextWelfare = os.time() + obs.minutes * 60
    save(target, c)
    MySQL.insert.await([[INSERT INTO vpo_custody (arrest_id, identifier, subject_name, suite, booked_at, booked_by, grounds, risk, observation)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE suite = VALUES(suite), booked_at = VALUES(booked_at), booked_by = VALUES(booked_by),
        grounds = VALUES(grounds), risk = VALUES(risk), observation = VALUES(observation)]],
        { c.arrestId, VPO.Bridge.GetIdentifier(target), c.name, suite.id, c.booked.at, c.booked.by, d.grounds, risk, obs.level })
    CU.Log(c.arrestId, 'booked', ('Detention authorised: %s. Risk %s, %s. Rights and entitlements given.%s'):format(
        d.grounds, risk, obs.label, VPO.Util.Trim(d.notes, 500) and (' ' .. VPO.Util.Trim(d.notes, 500)) or ''), c.booked.by)
    VPO.Audit.Log({ action = 'custody.book', actor = src, targetType = 'player', targetId = VPO.Bridge.GetIdentifier(target), new = c.booked })
    VPO.Notify(target, L('custody_booked_target'), 'inform')
    return { ok = true }
end)

VPO.Net.Callback('custody:takeProperty', { permission = 'custody.cells', rate = 'custody' }, function(src, o, d)
    local target, c, suite, err = detainee(src, d, 6.0)
    if not target then return { error = err } end
    if not c.booked then return { error = L('custody_book_first') } end
    if not Cfg.TakeProperty or not VPO.Inventory.CanStash() then return { error = L('custody_no_property_system') } end
    if not atDesk(src, suite) then return { error = L('custody_at_desk') } end
    local stash = ('vpo_property_%d'):format(c.arrestId)
    local moved = VPO.Inventory.MoveToStash(target, stash, ('Property %s'):format(c.ref or c.arrestId), Cfg.PropertyKeep)
    if not moved then return { error = L('qual_failed') } end
    c = VPO.Util.Copy(c)
    c.property = stash
    save(target, c)
    MySQL.update("UPDATE vpo_custody SET property_stash = ?, property_status = 'held' WHERE arrest_id = ?", { stash, c.arrestId })
    local list = {}
    for _, m in ipairs(moved) do list[#list + 1] = ('%dx %s'):format(m.count, m.label) end
    CU.Log(c.arrestId, 'property', #list > 0 and ('Property taken: %s'):format(table.concat(list, ', ')) or 'Searched: no property', officerLabel(src))
    return { ok = true, moved = moved }
end)

VPO.Net.Callback('custody:openProperty', { permission = 'custody.cells', rate = 'custody' }, function(src, _, d)
    local target, c, suite, err = detainee(src, d)
    if not target then return { error = err } end
    if not c.property then return { error = L('custody_no_property') } end
    if not atDesk(src, suite) then return { error = L('custody_at_desk') } end
    VPO.Inventory.OpenStash(src, c.property, ('Property %s'):format(c.ref or ''))
    return { ok = true }
end)

VPO.Net.Callback('custody:cell', { permission = 'custody.cells', rate = 'custody' }, function(src, o, d)
    local target, c, suite, err = detainee(src, d, 6.0)
    if not target then return { error = err } end
    if not c.booked then return { error = L('custody_book_first') } end
    local cell
    for _, x in ipairs(suite.cells) do if x.id == d.cell then cell = x end end
    if not cell then return { error = L('custody_pick_cell') } end
    local occ = occupancy(suite)
    if (occ[cell.id] and occ[cell.id] ~= target) or VPO.CustodyNpc.Occupied(suite)[cell.id] then return { error = L('custody_cell_taken', cell.label) } end
    VPO.Restraint.StopEscort(target, 'cell')
    if Cfg.RemoveCuffsInCell and VPO.Restraint.IsCuffed(target) then VPO.Restraint.Release(target, 'placed in cell', src) end
    c = VPO.Util.Copy(c)
    local moved = c.cell ~= nil
    c.cell, c.out = { suite = suite.id, id = cell.id }, nil
    save(target, c)
    teleport(target, cell.coords)
    CU.SetCellDoor(suite, cell, true)
    CU.Log(c.arrestId, 'cell', (moved and 'Moved to %s' or 'Placed in %s'):format(cell.label), officerLabel(src))
    return { ok = true }
end)

VPO.Net.Callback('custody:out', { permission = 'custody.cells', rate = 'custody' }, function(src, _, d)
    local target, c, _, err = detainee(src, d, 6.0)
    if not target then return { error = err } end
    if not c.cell then return { error = L('custody_not_in_cell') } end
    local reason = VPO.Util.Contains(Cfg.OutReasons, d.reason) and d.reason or 'Other'
    c = VPO.Util.Copy(c)
    c.out = reason
    save(target, c)
    local cell, su = cellDef(c)
    if cell then CU.SetCellDoor(su, cell, false) end
    CU.Log(c.arrestId, 'out', ('Out of cell: %s'):format(reason), officerLabel(src))
    return { ok = true }
end)

VPO.Net.Callback('custody:back', { permission = 'custody.cells', rate = 'custody' }, function(src, _, d)
    local target, c, _, err = detainee(src, d, 8.0)
    if not target then return { error = err } end
    local cell = cellDef(c)
    if not cell then return { error = L('custody_not_in_cell') } end
    VPO.Restraint.StopEscort(target, 'cell')
    if Cfg.RemoveCuffsInCell and VPO.Restraint.IsCuffed(target) then VPO.Restraint.Release(target, 'returned to cell', src) end
    c = VPO.Util.Copy(c)
    c.out = nil
    save(target, c)
    teleport(target, cell.coords)
    local _, su = cellDef(c)
    if su then CU.SetCellDoor(su, cell, true) end
    CU.Log(c.arrestId, 'cell', ('Returned to %s'):format(cell.label), officerLabel(src))
    return { ok = true }
end)

VPO.Net.Callback('custody:welfare', { permission = 'custody.cells', rate = 'custody' }, function(src, o, d)
    local target, c, _, err = detainee(src, d, 6.0)
    if not target then return { error = err } end
    if not c.booked then return { error = L('custody_book_first') } end
    c = VPO.Util.Copy(c)
    local level = tonumber(d.observation)
    if level and level ~= c.booked.observation then
        if not VPO.Permissions.Check(src, 'custody.book') then return { error = L('custody_sergeant_only') } end
        if not obsByLevel[level] then return { error = L('custody_pick_observation') } end
        CU.Log(c.arrestId, 'observation', ('Observation changed to %s'):format(obsByLevel[level].label), officerLabel(src))
        c.booked.observation = level
    end
    local obs = obsByLevel[c.booked.observation] or Cfg.Observation[1]
    c.nextWelfare = os.time() + obs.minutes * 60
    save(target, c)
    overdueNotified[c.arrestId] = nil
    local note = VPO.Util.Trim(d.note, 500)
    CU.Log(c.arrestId, 'welfare', ('Welfare check: %s%s'):format(d.rousable == false and 'NOT ROUSABLE. ' or 'Roused and responsive. ', note or ''), officerLabel(src))
    if d.rousable == false then
        for _, id in ipairs(GetPlayers()) do
            local p = tonumber(id)
            if VPO.IsOnDuty(p) == true and CU.SuiteAt(p) then VPO.Notify(p, L('custody_not_rousable', c.name or '?'), 'error', 15000) end
        end
    end
    return { ok = true }
end)

---------------------------------------------------------------------------
-- Release
---------------------------------------------------------------------------
--- Ends police detention: property back (if set), out of the cell to the release point, custody state cleared.
--- officer is nil when the MDT or the prison triggered it.
function CU.Release(target, outcome, notes, officer, opts)
    opts = opts or {}
    local c = CU.Get(target)
    if not c then return false end
    local suite = (c.cell and suiteById(c.cell.suite)) or (c.booked and suiteById(c.booked.suite)) or CU.SuiteAt(target)
    do -- the cell they leave is opened, and its buzzer starts fresh
        local cell, su = cellDef(c)
        if cell then CU.SetCellDoor(su, cell, false); CU.ClearBuzzer(su.id, cell.id) end
    end
    local returned, left
    if not opts.retainProperty and c.property and Cfg.ReturnPropertyOnRelease then
        returned, left = VPO.Inventory.ReturnFromStash(c.property, target)
    end
    local status = c.property and ((opts.retainProperty or (left and left > 0) or not returned) and 'retained' or 'returned') or 'none'
    MySQL.update('UPDATE vpo_custody SET released_at = ?, outcome = ?, property_status = ? WHERE arrest_id = ?', { os.time(), outcome, status, c.arrestId })
    MySQL.update('UPDATE vpo_arrests SET released_at = COALESCE(released_at, ?), release_reason = COALESCE(release_reason, ?) WHERE id = ?', { os.time(), outcome, c.arrestId })
    CU.Log(c.arrestId, 'release', ('%s%s%s'):format(outcome, notes and (': ' .. notes) or '',
        status == 'retained' and '. Property retained in the property store.' or (status == 'returned' and '. Property returned.' or '')),
        officer and officerLabel(officer) or 'System')
    VPO.Audit.Log({ action = 'custody.release', actor = officer, source = officer and 'player' or 'system', targetType = 'player',
        targetId = VPO.Bridge.GetIdentifier(target), previous = { ref = c.ref }, reason = outcome })
    VPO.State.Set(target, 'custody', nil)
    overdueNotified[c.arrestId] = nil
    if not opts.noMove then
        VPO.Restraint.Release(target, 'released from custody', officer)
        if suite and suite.release and (c.cell or c.booked) then teleport(target, suite.release) end
        VPO.Notify(target, L('custody_released_target', outcome), 'inform', 10000)
    end
    return true
end

VPO.Net.Callback('custody:release', { permission = 'custody.book', rate = 'custody' }, function(src, _, d)
    local target, c, _, err = detainee(src, d)
    if not target then return { error = err } end
    if not VPO.Util.Contains(Cfg.ReleaseOutcomes, d.outcome) then return { error = L('roads_pick_outcome') } end
    CU.Release(target, d.outcome, VPO.Util.Trim(d.notes, 500), src)
    local m = VPO.Integrations.Get('mdt')
    return { ok = true, message = m and c.mdtRecordId and L('custody_record_on_mdt', c.ref or '') or nil }
end)

VPO.Net.Callback('custody:returnProperty', { permission = 'custody.cells', rate = 'custody' }, function(src, _, d)
    local target = tonumber(type(d) == 'table' and d.target or nil)
    if not target or not GetPlayerName(target) then return { error = L('restraint_no_target') } end
    local suite = CU.SuiteAt(src)
    if not suite or not atDesk(src, suite) then return { error = L('custody_at_desk') } end
    if dist(coordsOf(src), coordsOf(target)) > 6.0 then return { error = L('restraint_too_far') } end
    if CU.Get(target) then return { error = L('custody_still_detained') } end
    local rows = MySQL.query.await("SELECT arrest_id, property_stash FROM vpo_custody WHERE identifier = ? AND property_status IN ('held', 'retained')",
        { VPO.Bridge.GetIdentifier(target) }) or {}
    local total, left = 0, 0
    for _, r in ipairs(rows) do
        local back, l = VPO.Inventory.ReturnFromStash(r.property_stash, target)
        total, left = total + #(back or {}), left + (l or 0)
        MySQL.update('UPDATE vpo_custody SET property_status = ? WHERE arrest_id = ?', { (l or 0) > 0 and 'retained' or 'returned', r.arrest_id })
        CU.Log(r.arrest_id, 'property', ('Property returned (%d items)%s'):format(#(back or {}), (l or 0) > 0 and (', %d could not be carried'):format(l) or ''), officerLabel(src))
    end
    return { ok = true, message = L('custody_property_returned', total, left) }
end)

---------------------------------------------------------------------------
-- Welfare reminders
---------------------------------------------------------------------------
CreateThread(function()
    while true do
        Wait(60000)
        local now = os.time()
        for _, id in ipairs(GetPlayers()) do
            local p = tonumber(id)
            local c = CU.Get(p)
            if c and c.booked and c.nextWelfare and c.nextWelfare < now and not c.out
                and (not overdueNotified[c.arrestId] or now - overdueNotified[c.arrestId] >= 300) then
                overdueNotified[c.arrestId] = now
                local cell = cellDef(c)
                CU.Log(c.arrestId, 'overdue', 'Welfare check overdue', 'System')
                for _, oid in ipairs(GetPlayers()) do
                    local o = tonumber(oid)
                    if VPO.IsOnDuty(o) == true and CU.SuiteAt(o) then
                        VPO.Notify(o, L('custody_welfare_overdue', c.name or '?', cell and cell.label or '?'), 'error', 10000)
                    end
                end
            end
        end
    end
end)

---------------------------------------------------------------------------
-- Other resources ending detention
---------------------------------------------------------------------------
local function detaineeByCid(cid, recordId)
    for _, id in ipairs(GetPlayers()) do
        local p = tonumber(id)
        local c = CU.Get(p)
        if c and VPO.Bridge.GetIdentifier(p) == cid and (not recordId or not c.mdtRecordId or c.mdtRecordId == recordId) then return p, c end
    end
    return nil
end

-- MDT outcome recorded (2.19+). Outcomes that end police detention release them here.
local ENDS = { ['Released on bail'] = true, ['Released under investigation'] = true, ['Simple caution'] = true,
    ['Community resolution'] = true, ['No further action'] = true, ['Fixed penalty notice'] = true }
AddEventHandler('vinewood-mdt:server:custodyOutcome', function(recordId, _, cid, outcome, officer)
    local p = detaineeByCid(cid, recordId)
    if not p then return end
    if ENDS[outcome] then
        CU.Release(p, outcome, nil, officer)
    else
        local c = CU.Get(p)
        CU.Log(c.arrestId, 'outcome', ('Outcome recorded on the MDT: %s'):format(outcome), officer and officerLabel(officer) or 'MDT')
    end
end)

AddEventHandler('vinewood-mdt:server:bailGranted', function(bail, target)
    local p = tonumber(target)
    if not (p and CU.Get(p)) and type(bail) == 'table' and bail.cid then p = detaineeByCid(bail.cid) end
    if p and CU.Get(p) then CU.Release(p, 'Released on bail', type(bail) == 'table' and bail.ref or nil, nil) end
end)

AddEventHandler('vinewood-mdt:server:noFurtherAction', function(cid, recordId, reason)
    local p = detaineeByCid(cid, recordId)
    if p then CU.Release(p, 'No further action', reason, nil) end
end)

-- Remanded and received by vinewood_prison: police detention ends, property stays in the store.
AddEventHandler('vinewood_prison:received', function(identifier, prisonNo)
    local p = detaineeByCid(identifier)
    if p then CU.Release(p, 'Remanded: received by prison', prisonNo and ('Prison number ' .. tostring(prisonNo)) or nil, nil, { retainProperty = true, noMove = true }) end
end)

-- Interviews (vinewood-interviews 1.8.1+)
AddEventHandler('vinewood-interviews:server:started', function(data)
    if type(data) ~= 'table' or not data.intervieweeCid then return end
    local p, c = detaineeByCid(data.intervieweeCid)
    if not p then return end
    if c.cell and not c.out then
        c = VPO.Util.Copy(c); c.out = 'Interview'; save(p, c)
    end
    CU.Log(c.arrestId, 'interview', ('Interview started in %s (recording %s)%s'):format(data.roomLabel or '?', tostring(data.id),
        data.solicitor and (', solicitor ' .. data.solicitor) or ', no solicitor'), data.startedBy and officerLabel(data.startedBy) or nil)
end)

AddEventHandler('vinewood-interviews:server:ended', function(data)
    if type(data) ~= 'table' or not data.intervieweeCid then return end
    local p, c = detaineeByCid(data.intervieweeCid)
    if not p then return end
    CU.Log(c.arrestId, 'interview', ('Interview ended (recording %s, %d min)'):format(tostring(data.id), math.floor((data.durationMs or 0) / 60000)), nil)
end)


---------------------------------------------------------------------------
-- Cell doors. A cell with a door set (vpo locations, Custody, "Set door") has a real door: locked or
-- unlocked on the server (GlobalState.vpo_celldoors) and applied in every player's game. Placing someone in
-- a cell or returning them locks it; taking them out or releasing them unlocks it. Opening the door of an
-- occupied cell lets them walk out (they count as out of the cell until it's locked with them inside).
---------------------------------------------------------------------------
local DOOR_OPEN = 'Cell door open'

local function doorKey(suiteId, cellId) return suiteId .. ':' .. cellId end

function CU.DoorLocked(suiteId, cellId)
    local t = GlobalState.vpo_celldoors or {}
    return t[doorKey(suiteId, cellId)] ~= false
end

function CU.SetCellDoor(suite, cell, locked)
    if not suite or not cell or not cell.door then return end
    local t = GlobalState.vpo_celldoors or {}
    t[doorKey(suite.id, cell.id)] = locked == true
    GlobalState.vpo_celldoors = t
end

local function occupantOf(suite, cellId)
    for _, id in ipairs(GetPlayers()) do
        local p = tonumber(id)
        local c = CU.Get(p)
        if c and c.cell and c.cell.suite == suite.id and c.cell.id == cellId then return p, c end
    end
    return nil
end

VPO.Net.Callback('custody:door', { permission = 'custody.cells', rate = 'custody' }, function(src, o, d)
    d = type(d) == 'table' and d or {}
    local suite = suiteById(d.suite)
    local cell
    for _, x in ipairs(suite and suite.cells or {}) do if x.id == d.cell then cell = x end end
    if not cell or not cell.door then return { error = L('custody_no_door') } end
    local dc = cell.door.coords
    -- At the door, or at this suite's custody desk (door release from the desk computer)
    local atDesk = d.desk and CU.SuiteAt(src) == suite
    if not atDesk and dist(coordsOf(src), vector3(dc.x, dc.y, dc.z)) > 3.5 then return { error = L('restraint_too_far') } end
    local locking = not CU.DoorLocked(suite.id, cell.id)
    CU.SetCellDoor(suite, cell, locking)
    local who = officerLabel(src)
    local p, c = occupantOf(suite, cell.id)
    if p then
        c = VPO.Util.Copy(c)
        if not locking and not c.out then
            c.out = DOOR_OPEN
            save(p, c)
            CU.Log(c.arrestId, 'door', ('%s door opened'):format(cell.label), who)
        elseif locking and c.out == DOOR_OPEN then
            local inside = dist(coordsOf(p), vector3(cell.coords.x, cell.coords.y, cell.coords.z)) <= Cfg.CellRadius + 1.0
            if inside then
                c.out = nil
                save(p, c)
                CU.Log(c.arrestId, 'door', ('%s door locked'):format(cell.label), who)
            else
                CU.Log(c.arrestId, 'door', ('%s door locked with the detainee OUTSIDE the cell'):format(cell.label), who)
                VPO.Notify(src, L('custody_door_empty'), 'error', 8000)
            end
        end
    end
    VPO.Audit.Log({ action = locking and 'custody.door_lock' or 'custody.door_unlock', actor = src, targetType = 'cell', targetId = doorKey(suite.id, cell.id) })
    return { ok = true, locked = locking, message = L(locking and 'custody_door_locked' or 'custody_door_unlocked', cell.label) }
end)

--- Every cell door starts locked unless an empty cell's door has been opened since.
local function initDoors()
    local t = GlobalState.vpo_celldoors or {}
    local fresh = {}
    for _, su in ipairs(Config.Custody.Suites) do
        for _, cell in ipairs(su.cells or {}) do
            if cell.door then
                local k = doorKey(su.id, cell.id)
                if t[k] ~= nil then fresh[k] = t[k] else fresh[k] = true end
            end
        end
    end
    GlobalState.vpo_celldoors = fresh
end

AddEventHandler(VPO.Events.ready, initDoors)
AddEventHandler('vinewood_police:server:locationsChanged', function(key) if key == 'custody' then initDoors() end end)

---------------------------------------------------------------------------
-- CCTV: cameras of a suite (cells and the suite), watched from its custody computer
---------------------------------------------------------------------------
VPO.Net.Callback('custody:cctv', { permission = 'custody.cells', rate = 'custody' }, function(src, _, d)
    local suite = CU.SuiteAt(src)
    if not suite then return { error = L('custody_go_to_suite') } end
    local names = {}
    for _, id in ipairs(GetPlayers()) do
        local p = tonumber(id)
        local c = CU.Get(p)
        if c and c.cell and c.cell.suite == suite.id then names[c.cell.id] = VPO.Bridge.GetName(p) end
    end
    for _, n in ipairs(VPO.CustodyNpc.ForSuite(suite)) do if n.cellId then names[n.cellId] = n.name end end
    local cams = {}
    for _, cam in ipairs(suite.cameras or {}) do
        local cellLabel
        for _, cell in ipairs(suite.cells) do if cell.id == cam.cell then cellLabel = cell.label end end
        cams[#cams + 1] = { id = cam.id, label = cam.label, cell = cam.cell, cellLabel = cellLabel, occupant = cam.cell and names[cam.cell] or nil,
            coords = { x = cam.coords.x, y = cam.coords.y, z = cam.coords.z }, rot = { x = cam.rot.x, z = cam.rot.z }, fov = cam.fov }
    end
    if #cams == 0 then return { error = L('custody_no_cctv') } end
    local start = 1
    for i, c in ipairs(cams) do if type(d) == 'table' and c.id == d.camera then start = i end end
    VPO.Audit.Log({ action = 'custody.cctv', actor = src, targetType = 'suite', targetId = suite.id })
    return { ok = true, suite = suite.label, cameras = cams, start = start }
end)

---------------------------------------------------------------------------
-- Cell buzzers
---------------------------------------------------------------------------
local BZ = Config.Custody.Buzzer or {}
local buzzing, muted, lastPress = {}, {}, {}   -- [suite:cell] = os.time() / true / os.time()
local function bkey(suiteId, cellId) return suiteId .. ':' .. cellId end

function CU.BuzzState(suiteId, cellId)
    local k = bkey(suiteId, cellId)
    local at = buzzing[k]
    if at and os.time() - at > (BZ.AutoClear or 180) then buzzing[k] = nil; at = nil end
    return at, muted[k] == true
end

--- Someone in a cell pressed the call button (player or NPC).
function CU.Buzz(suite, cell, who)
    if not BZ.Enabled then return false end
    local k = bkey(suite.id, cell.id)
    if lastPress[k] and os.time() - lastPress[k] < (BZ.Cooldown or 20) then return false end
    lastPress[k] = os.time()
    if muted[k] then return true end            -- pressed, but the suite has muted this cell
    buzzing[k] = os.time()
    local desk = suite.desk.coords
    for _, id in ipairs(GetPlayers()) do
        local p = tonumber(id)
        local pc = coordsOf(p)
        if pc and #(pc - desk) <= (BZ.HearRadius or 45.0) then
            TriggerClientEvent('vinewood_police:client:custody:buzzer', p, { suite = suite.id, cell = cell.id, label = cell.label, volume = BZ.Volume or 0.55,
                notify = VPO.IsOnDuty(p) == true })
        end
    end
    return true
end

-- A detainee presses the call button in their cell
VPO.Net.On('custody:buzz', { rate = 'custody', silent = true }, function(src)
    local c = CU.Get(src)
    if not c or not c.cell or c.out then return end
    local cell, suite = cellDef(c)
    if not cell then return end
    if CU.Buzz(suite, cell) then CU.Log(c.arrestId, 'buzzer', ('Pressed the call button in %s'):format(cell.label), nil) end
end)

VPO.Net.Callback('custody:buzzer', { permission = 'custody.cells', rate = 'custody' }, function(src, o, d)
    d = type(d) == 'table' and d or {}
    local suite = CU.SuiteAt(src)
    if not suite or suite.id ~= d.suite then return { error = L('custody_go_to_suite') } end
    local cell
    for _, x in ipairs(suite.cells) do if x.id == d.cell then cell = x end end
    if not cell then return { error = L('equipment_not_found') } end
    local k = bkey(suite.id, cell.id)
    if d.op == 'answer' then
        buzzing[k] = nil
        TriggerClientEvent('vinewood_police:client:custody:buzzerStop', -1, { suite = suite.id, cell = cell.id })
    elseif d.op == 'mute' then
        muted[k] = d.muted == true or nil
        if muted[k] then buzzing[k] = nil end
        VPO.Audit.Log({ action = muted[k] and 'custody.buzzer_mute' or 'custody.buzzer_unmute', actor = src, targetType = 'cell', targetId = k })
    end
    return { ok = true }
end)

-- NPC detainees press theirs now and then
CreateThread(function()
    while true do
        Wait(300000)
        if BZ.Enabled and (BZ.NpcChance or 0) > 0 then
            for _, su in ipairs(Config.Custody.Suites) do
                for _, n in ipairs(VPO.CustodyNpc.ForSuite(su)) do
                    if n.cellId and not n.out and math.random(1, 100) <= BZ.NpcChance then
                        for _, cell in ipairs(su.cells) do if cell.id == n.cellId then CU.Buzz(su, cell) end end
                    end
                end
            end
        end
    end
end)

-- A cell that's emptied starts fresh: no call showing, buzzer unmuted
function CU.ClearBuzzer(suiteId, cellId)
    local k = bkey(suiteId, cellId)
    buzzing[k], muted[k] = nil, nil
end
