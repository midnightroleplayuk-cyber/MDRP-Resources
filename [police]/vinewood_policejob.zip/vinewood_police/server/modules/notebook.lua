-- Pocket notebook. Entries are permanent: no edit, no delete. A mistake is fixed by adding a
-- correction that points at the original entry, like striking through a line in a real PNB.
VPO.Notebook = {}
local L = VPO.L

local function decorate(rows)
    for _, r in ipairs(rows) do r.created_at = tonumber(r.created_at) end
    return rows
end

function VPO.Notebook.Page(identifier, beforeId)
    local size = Config.Notebook.PageSize or 25
    local rows
    if beforeId then
        rows = MySQL.query.await('SELECT id, created_at, text, ref, corrects_id, session_id FROM vpo_notebook WHERE identifier = ? AND id < ? ORDER BY id DESC LIMIT ?',
            { identifier, beforeId, size + 1 })
    else
        rows = MySQL.query.await('SELECT id, created_at, text, ref, corrects_id, session_id FROM vpo_notebook WHERE identifier = ? ORDER BY id DESC LIMIT ?',
            { identifier, size + 1 })
    end
    rows = rows or {}
    local more = #rows > size
    if more then rows[#rows] = nil end
    return decorate(rows), more
end

VPO.Net.Callback('notebook:list', { permission = 'notebook.write', rate = 'hub' }, function(_, o, d)
    local entries, more = VPO.Notebook.Page(o.identifier, type(d) == 'table' and tonumber(d.beforeId) or nil)
    return { ok = true, entries = entries, more = more }
end)

VPO.Net.Callback('notebook:add', { permission = 'notebook.write', rate = 'notebook' }, function(src, o, d)
    d = type(d) == 'table' and d or {}
    local text = VPO.Util.Trim(d.text, Config.Notebook.MaxLength)
    if not text then return { error = L('notebook_empty') } end
    local corrects = tonumber(d.correctsId)
    if corrects then
        local owner = MySQL.scalar.await('SELECT identifier FROM vpo_notebook WHERE id = ?', { corrects })
        if owner ~= o.identifier then return { error = L('notebook_bad_correction') } end
    end
    local session = VPO.Duty.Get(src)
    local id = MySQL.insert.await('INSERT INTO vpo_notebook (identifier, session_id, created_at, text, ref, corrects_id) VALUES (?, ?, ?, ?, ?, ?)',
        { o.identifier, session and session.id or nil, os.time(), text, VPO.Util.Trim(d.ref, 32), corrects })
    if not id then return { error = L('qual_failed') } end
    if session then VPO.Duty.AddStat(src, 'notebook', 1) end
    return { ok = true, id = id }
end)
