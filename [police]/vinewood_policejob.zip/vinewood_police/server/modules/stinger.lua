-- Stinger tyre deflation. Laid by trained officers, server-created, withdrawn after a few minutes.
-- Every client deflates the tyres of vehicles it controls that cross it.
local Cfg = Config.Stinger
local L = VPO.L
local stingers = {} -- [officer] = { obj, net, expires }

local function publish()
    local t = {}
    for o, s in pairs(stingers) do
        if DoesEntityExist(s.obj) then
            local c, h = GetEntityCoords(s.obj), GetEntityHeading(s.obj)
            t[tostring(s.net)] = { x = c.x, y = c.y, z = c.z, h = h, by = o }
        end
    end
    GlobalState.vpo_stingers = t
end

local function remove(officer)
    local s = stingers[officer]
    if s and DoesEntityExist(s.obj) then DeleteEntity(s.obj) end
    stingers[officer] = nil
    publish()
end

VPO.Net.Callback('stinger:deploy', { permission = 'roads.stinger', rate = 'roads' }, function(src, o, d)
    d = type(d) == 'table' and d or {}
    local x, y, z, h = tonumber(d.x), tonumber(d.y), tonumber(d.z), tonumber(d.h) or 0.0
    if not x or not y or not z then return { error = L('scene_bad_spot') } end
    local p = GetPlayerPed(src)
    if #(GetEntityCoords(p) - vector3(x, y, z)) > Cfg.Range + 2.0 then return { error = L('scene_too_far') } end
    if stingers[src] then remove(src) end
    local obj = CreateObjectNoOffset(GetHashKey(Cfg.Model), x, y, z, true, true, false)
    local deadline = GetGameTimer() + 2000
    while not DoesEntityExist(obj) and GetGameTimer() < deadline do Wait(10) end
    if not DoesEntityExist(obj) then return { error = L('scene_failed') } end
    SetEntityHeading(obj, h)
    FreezeEntityPosition(obj, true)
    stingers[src] = { obj = obj, net = NetworkGetNetworkIdFromEntity(obj), expires = os.time() + Cfg.Lifetime }
    publish()
    VPO.Audit.Log({ action = 'roads.stinger', actor = src, new = { x = x, y = y } })
    return { ok = true, lifetime = Cfg.Lifetime }
end)

VPO.Net.Callback('stinger:withdraw', { permission = 'roads.stinger', rate = 'roads' }, function(src)
    if not stingers[src] then return { error = L('stinger_none') } end
    remove(src)
    return { ok = true }
end)

-- A stinger hit something: logged against the officer who laid it
VPO.Net.On('stinger:hit', { rate = 'discharge', silent = true }, function(src, _, net, plate)
    for o, s in pairs(stingers) do
        if s.net == tonumber(net) then
            VPO.Audit.Log({ action = 'roads.stinger_hit', actor = o, targetType = 'vehicle', targetId = tostring(plate or '?'):sub(1, 12) })
            if GetPlayerName(o) then VPO.Notify(o, L('stinger_hit', tostring(plate or '?')), 'success') end
        end
    end
end)

CreateThread(function()
    while true do
        Wait(5000)
        local now = os.time()
        for o, s in pairs(stingers) do if s.expires < now or not GetPlayerName(o) then remove(o) end end
    end
end)

VPO.Duty.OnSignOff(function(src) if stingers[src] then remove(src) end end)
AddEventHandler('onResourceStop', function(res)
    if res ~= VPO.Resource then return end
    for o in pairs(stingers) do remove(o) end
end)
