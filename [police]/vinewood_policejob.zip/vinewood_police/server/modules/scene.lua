-- Scene kit. Props are created by the server (so the server can always clear them) and frozen in place.
-- Each officer's props form a scene; the officer can slow or stop NPC traffic around it. Clients apply
-- the speed zones from GlobalState.vpo_scene_zones.
local Cfg = Config.Scene
local L = VPO.L
local props = {}  -- [officerIdentifier] = { { obj, net, id, expires } }
local modes = {}  -- [officerIdentifier] = 'none' | 'slow' | 'closed'
local propById = {}
for _, p in ipairs(Cfg.Props) do propById[p.id] = p end

local function ped(src)
    local p = GetPlayerPed(src)
    return (p and p ~= 0) and p or nil
end

local function alive(list)
    local out = {}
    for _, p in ipairs(list or {}) do if DoesEntityExist(p.obj) then out[#out + 1] = p end end
    return out
end

--- Recalculate an officer's traffic zone from where their props are.
local function updateZone(owner)
    local zones = GlobalState.vpo_scene_zones or {}
    local list = alive(props[owner])
    props[owner] = list
    local mode = modes[owner] or 'none'
    if #list == 0 or mode == 'none' then
        zones[owner] = nil
    else
        local cx, cy, cz = 0.0, 0.0, 0.0
        for _, p in ipairs(list) do local c = GetEntityCoords(p.obj); cx, cy, cz = cx + c.x, cy + c.y, cz + c.z end
        cx, cy, cz = cx / #list, cy / #list, cz / #list
        local r = 0.0
        for _, p in ipairs(list) do r = math.max(r, #(GetEntityCoords(p.obj) - vector3(cx, cy, cz))) end
        zones[owner] = { x = cx, y = cy, z = cz, r = math.min(r + Cfg.ZoneMargin, 80.0), speed = mode == 'closed' and 0.0 or Cfg.SlowSpeed }
    end
    GlobalState.vpo_scene_zones = zones
end

---------------------------------------------------------------------------
-- Police tape: points only (no entities). Everyone's game draws it from GlobalState.vpo_tapes.
---------------------------------------------------------------------------
local tapes, tapeSeq = {}, 0   -- [owner] = { { id, points, expires } }

local function publishTapes()
    local out = {}
    for owner, list in pairs(tapes) do
        for _, t in ipairs(list) do out[tostring(t.id)] = { points = t.points, owner = owner } end
    end
    GlobalState.vpo_tapes = out
end

local function clearTapes(owner)
    if tapes[owner] then tapes[owner] = nil; publishTapes() end
end

VPO.Net.Callback('scene:tape', { permission = 'scene.place', rate = 'scene' }, function(src, o, d)
    local T = Cfg.Tape
    local pts = type(d) == 'table' and d.points or nil
    if type(pts) ~= 'table' or #pts < 2 or #pts > T.MaxPoints then return { error = L('tape_points', T.MaxPoints) } end
    local me = GetEntityCoords(GetPlayerPed(src))
    local clean = {}
    for i, p in ipairs(pts) do
        local x, y, z = tonumber(p.x), tonumber(p.y), tonumber(p.z)
        if not x or not y or not z then return { error = L('scene_bad_spot') } end
        local v = vector3(x, y, z)
        if #(v - me) > T.MaxSpan * 2 + 10.0 then return { error = L('scene_too_far') } end
        if i > 1 and #(v - vector3(clean[i - 1].x, clean[i - 1].y, clean[i - 1].z)) > T.MaxSpan + 0.5 then return { error = L('tape_span', T.MaxSpan) } end
        clean[i] = { x = math.floor(x * 100) / 100, y = math.floor(y * 100) / 100, z = math.floor(z * 100) / 100 }
    end
    local list = tapes[o.identifier] or {}
    if #list >= T.MaxPerOfficer then return { error = L('tape_limit', T.MaxPerOfficer) } end
    tapeSeq = tapeSeq + 1
    list[#list + 1] = { id = tapeSeq, points = clean, expires = os.time() + Cfg.Lifetime * 60 }
    tapes[o.identifier] = list
    publishTapes()
    VPO.Audit.Log({ action = 'scene.tape', actor = src, new = { points = #clean } })
    return { ok = true, count = #list }
end)

VPO.Net.Callback('scene:tapeRemove', { permission = 'scene.place', rate = 'scene' }, function(src, o, d)
    local id = tonumber(type(d) == 'table' and d.id or nil)
    for owner, list in pairs(tapes) do
        for i, t in ipairs(list) do
            if t.id == id then
                -- Your own tape, or anyone's if you're a sergeant or above
                if owner ~= o.identifier and o.rank.level < VPO.Ranks.Level('ps') then return { error = L('tape_not_yours') } end
                table.remove(list, i)
                publishTapes()
                return { ok = true }
            end
        end
    end
    return { error = L('equipment_not_found') }
end)

local function clear(owner)
    for _, p in ipairs(props[owner] or {}) do if DoesEntityExist(p.obj) then DeleteEntity(p.obj) end end
    props[owner] = nil
    modes[owner] = nil
    updateZone(owner)
    clearTapes(owner)
end

VPO.Net.Callback('scene:place', { permission = 'scene.place', rate = 'scene' }, function(src, o, d)
    d = type(d) == 'table' and d or {}
    local def = propById[d.id or '']
    if not def then return { error = L('scene_unknown') } end
    if def.minRank and o.rank.level < VPO.Ranks.Level(def.minRank) then return { error = L('perm_rank') } end
    local x, y, z, h = tonumber(d.x), tonumber(d.y), tonumber(d.z), tonumber(d.h) or 0.0
    if not x or not y or not z then return { error = L('scene_bad_spot') } end
    local p = ped(src)
    if not p or #(GetEntityCoords(p) - vector3(x, y, z)) > Cfg.PlaceRange + 1.0 then return { error = L('scene_too_far') } end
    local list = alive(props[o.identifier])
    local kit = 0
    for _, e in ipairs(list) do if not e.marker then kit = kit + 1 end end
    if kit >= Cfg.MaxPerOfficer then return { error = L('scene_limit', Cfg.MaxPerOfficer) } end

    local obj = CreateObjectNoOffset(GetHashKey(def.model), x, y, z, true, true, false)
    local deadline = GetGameTimer() + 2000
    while not DoesEntityExist(obj) and GetGameTimer() < deadline do Wait(10) end
    if not DoesEntityExist(obj) then return { error = L('scene_failed') } end
    SetEntityHeading(obj, h)
    FreezeEntityPosition(obj, true)
    Entity(obj).state:set('vpo_scene', { owner = o.identifier, label = def.label }, true)
    list[#list + 1] = { obj = obj, net = NetworkGetNetworkIdFromEntity(obj), id = def.id, expires = os.time() + Cfg.Lifetime * 60 }
    props[o.identifier] = list
    local switched
    if def.traffic and (modes[o.identifier] or 'none') == 'none' then
        modes[o.identifier] = def.traffic
        switched = def.traffic
    end
    updateZone(o.identifier)
    return { ok = true, count = #list, traffic = switched }
end)

VPO.Net.Callback('scene:pickup', { permission = 'scene.place', rate = 'scene' }, function(src, _, d)
    local net = tonumber(type(d) == 'table' and d.net or nil)
    local obj = net and NetworkGetEntityFromNetworkId(net) or 0
    if not obj or obj == 0 or not DoesEntityExist(obj) then return { error = L('scene_failed') } end
    local st = Entity(obj).state.vpo_scene
    if not st then return { error = L('scene_not_ours') } end
    local p = ped(src)
    if not p or #(GetEntityCoords(p) - GetEntityCoords(obj)) > 4.0 then return { error = L('restraint_too_far') } end
    if st.marker then
        local i = VPO.Scene.IncidentAt(GetEntityCoords(obj))
        if i then VPO.Incidents.Log(i, 'marker', ('Evidence marker %d picked up'):format(st.marker), VPO.Officers.Label(VPO.Officers.Get(src))) end
    end
    DeleteEntity(obj)
    updateZone(st.owner)
    return { ok = true }
end)

---------------------------------------------------------------------------
-- Evidence markers
---------------------------------------------------------------------------
VPO.Scene = VPO.Scene or {}

--- The major incident whose outer cordon covers this point, if any.
function VPO.Scene.IncidentAt(c)
    for _, i in pairs(VPO.Incidents and VPO.Incidents.Active() or {}) do
        if #(c - vector3(i.coords.x, i.coords.y, i.coords.z)) <= i.outer then return i end
    end
    return nil
end

--- Numbers already used by markers near this point, any officer's.
local function markersNear(c)
    local used = {}
    local EM = Cfg.EvidenceMarkers
    for _, list in pairs(props) do
        for _, e in ipairs(list) do
            if e.marker and DoesEntityExist(e.obj) and #(GetEntityCoords(e.obj) - c) <= EM.Radius then used[e.marker] = true end
        end
    end
    return used
end

VPO.Net.Callback('scene:marker', { permission = 'scene.place', rate = 'scene' }, function(src, o, d)
    d = type(d) == 'table' and d or {}
    local EM = Cfg.EvidenceMarkers
    local x, y, z, h = tonumber(d.x), tonumber(d.y), tonumber(d.z), tonumber(d.h) or 0.0
    if not x or not y or not z then return { error = L('scene_bad_spot') } end
    local c = vector3(x, y, z)
    local p = ped(src)
    if not p or #(GetEntityCoords(p) - c) > Cfg.PlaceRange + 1.0 then return { error = L('scene_too_far') } end
    local used = markersNear(c)
    local n
    for k = 1, EM.Count do if not used[k] then n = k break end end
    if not n then return { error = L('marker_all_used', EM.Count) } end
    local obj = CreateObjectNoOffset(GetHashKey(EM.Model:format(n)), x, y, z, true, true, false)
    local deadline = GetGameTimer() + 2000
    while not DoesEntityExist(obj) and GetGameTimer() < deadline do Wait(10) end
    if not DoesEntityExist(obj) then return { error = L('scene_failed') } end
    SetEntityHeading(obj, h)
    FreezeEntityPosition(obj, true)
    Entity(obj).state:set('vpo_scene', { owner = o.identifier, label = ('Evidence marker %d'):format(n), marker = n }, true)
    local list = alive(props[o.identifier])
    list[#list + 1] = { obj = obj, net = NetworkGetNetworkIdFromEntity(obj), id = 'marker', marker = n, expires = os.time() + Cfg.Lifetime * 60 }
    props[o.identifier] = list
    local i = VPO.Scene.IncidentAt(c)
    if i then VPO.Incidents.Log(i, 'marker', ('Evidence marker %d placed'):format(n), VPO.Officers.Label(o)) end
    VPO.Audit.Log({ action = 'scene.marker', actor = src, new = { number = n } })
    -- What the next one here would be, for the preview
    used[n] = true
    local nextN
    for k = 1, EM.Count do if not used[k] then nextN = k break end end
    return { ok = true, number = n, nextNumber = nextN, incident = i and i.ref or nil }
end)

VPO.Net.Callback('scene:markerNext', { permission = 'scene.place', rate = 'scene' }, function(src)
    local used = markersNear(GetEntityCoords(ped(src)))
    for k = 1, Cfg.EvidenceMarkers.Count do if not used[k] then return { ok = true, number = k } end end
    return { ok = true, number = nil }
end)

VPO.Net.Callback('scene:traffic', { permission = 'scene.place', rate = 'scene' }, function(_, o, d)
    local mode = type(d) == 'table' and d.mode or 'none'
    if mode ~= 'none' and mode ~= 'slow' and mode ~= 'closed' then mode = 'none' end
    modes[o.identifier] = mode
    updateZone(o.identifier)
    return { ok = true, mode = mode, count = #(props[o.identifier] or {}) }
end)

VPO.Net.Callback('scene:clear', { permission = 'scene.place', rate = 'scene' }, function(_, o)
    clear(o.identifier)
    return { ok = true }
end)

VPO.Net.Callback('scene:info', { permission = 'scene.place', rate = 'scene' }, function(src, o)
    local out = VPO.Hub.Header(src, o)
    out.ok = true
    out.props = {}
    for _, p in ipairs(Cfg.Props) do
        if not p.minRank or o.rank.level >= VPO.Ranks.Level(p.minRank) then
            out.props[#out.props + 1] = { id = p.id, label = p.label, group = p.group }
        end
    end
    local kit, markers = 0, 0
    for _, e in ipairs(alive(props[o.identifier])) do if e.marker then markers = markers + 1 else kit = kit + 1 end end
    out.count, out.markers = kit, markers
    out.tapes = #(tapes[o.identifier] or {})
    out.tapeMax = Cfg.Tape.MaxPerOfficer
    out.max = Cfg.MaxPerOfficer
    out.mode = modes[o.identifier] or 'none'
    return out
end)

-- Props expire; signing off clears them.
CreateThread(function()
    while true do
        Wait(60000)
        local now = os.time()
        for owner, list in pairs(props) do
            local keep = {}
            for _, p in ipairs(list) do
                if p.expires > now and DoesEntityExist(p.obj) then keep[#keep + 1] = p elseif DoesEntityExist(p.obj) then DeleteEntity(p.obj) end
            end
            props[owner] = keep
            updateZone(owner)
        end
        for owner, list in pairs(tapes) do
            local keep = {}
            for _, t in ipairs(list) do if t.expires > now then keep[#keep + 1] = t end end
            if #keep ~= #list then tapes[owner] = keep; publishTapes() end
        end
    end
end)

VPO.Duty.OnSignOff(function(_, session) clear(session.identifier) end)

AddEventHandler('onResourceStop', function(res)
    if res ~= VPO.Resource then return end
    for _, list in pairs(props) do
        for _, p in ipairs(list) do if DoesEntityExist(p.obj) then DeleteEntity(p.obj) end end
    end
    GlobalState.vpo_scene_zones = {}
    GlobalState.vpo_tapes = {}
end)
