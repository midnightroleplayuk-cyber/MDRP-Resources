-- Exports for other resources. Documented in docs/EXPORTS.md.

--- true / false, or nil when duty can't be known (ESX before the duty module). vinewood-mdt 2.18+ uses this.
exports('IsOnDuty', function(src) return VPO.IsOnDuty(tonumber(src)) end)

--- Public view of an officer, or nil if the player isn't in a police job.
exports('GetOfficer', function(src)
    local o = VPO.Officers.Get(tonumber(src))
    if not o then return nil end
    return {
        src = o.src, identifier = o.identifier, name = o.name, label = VPO.Officers.Label(o),
        job = o.job, grade = o.grade, rank = o.rank.id, rankLabel = o.rank.label, rankShort = o.rank.short,
        rankLevel = o.rank.level, collar = o.collar, callsign = o.callsign, onDuty = o.onDuty,
    }
end)

--- Whether the player passes a permission from Config.Permissions right now.
exports('HasPermission', function(src, perm)
    return (VPO.Permissions.Check(tonumber(src), perm)) == true
end)

--- Accepts a server id or an identifier.
local function identifierOf(x)
    if type(x) == 'number' or tonumber(x) then return VPO.Bridge.GetIdentifier(tonumber(x)) end
    return x
end

exports('HasQualification', function(who, qual)
    return (VPO.Qualifications.Has(identifierOf(who), qual)) == true
end)

exports('GetQualifications', function(who)
    local id = identifierOf(who)
    return id and VPO.Qualifications.List(id) or {}
end)

--- Server-owned player state (cuffed, detained, custody, duty...).
exports('GetPlayerState', function(src, key)
    if key then return VPO.State.Get(tonumber(src), key) end
    return VPO.State.All(tonumber(src))
end)

exports('GetIntegrationStatus', function() return VPO.Integrations.Status() end)

--- Lets another resource add to the audit log. The entry is marked as coming from that resource.
exports('AddAuditEntry', function(entry)
    if type(entry) ~= 'table' then return false end
    entry = VPO.Util.Copy(entry)
    entry.source = 'export:' .. (GetInvokingResource() or 'unknown')
    VPO.Audit.Log(entry)
    return true
end)

exports('IsReady', function() return VPO.Ready == true end)

--- The officer's current shift: { callsign, collar, unit, unitLabel, vehicle, station, status, since, name } or nil.
exports('GetDuty', function(src) return VPO.Duty.Public(tonumber(src)) end)

--- Everyone signed on: { [src] = duty }.
exports('GetOnDutyOfficers', function()
    local out = {}
    for src in pairs(VPO.Duty.All()) do out[src] = VPO.Duty.Public(src) end
    return out
end)

--- Number of police officers signed on (for robbery minimums etc.).
exports('GetOnDutyCount', function()
    local n = 0
    for _ in pairs(VPO.Duty.All()) do n = n + 1 end
    return n
end)

--- Adds to the officer's shift report, e.g. AddShiftStat(src, 'arrests', 1).
exports('AddShiftStat', function(src, key, n)
    if type(key) ~= 'string' then return end
    VPO.Duty.AddStat(tonumber(src), key:sub(1, 32), tonumber(n) or 1)
end)

--- Handcuff state: { mode = 'front'|'rear', doubleLocked, byLabel, at } or nil.
exports('GetCuffs', function(src) return VPO.Restraint.Cuffs(tonumber(src)) end)
exports('IsCuffed', function(src) return VPO.Restraint.IsCuffed(tonumber(src)) end)
--- Server id of the officer escorting this player, or nil.
exports('GetEscortedBy', function(src) return VPO.Restraint.EscortedBy(tonumber(src)) end)
--- Removes cuffs and ends any escort (prison intake, admin tools). Audited as the calling resource.
exports('ReleaseRestraints', function(src, reason)
    return VPO.Restraint.Release(tonumber(src), ('%s (%s)'):format(reason or 'released', GetInvokingResource() or '?'))
end)

--- Arrest state: { arrestId, ref, at, byLabel, offences } or nil. Phase 3's custody suite and
--- vinewood_prison can read this.
exports('GetCustody', function(src) return VPO.State.Get(tonumber(src), 'custody') end)
exports('IsUnderArrest', function(src) return VPO.State.Get(tonumber(src), 'custody') ~= nil end)

--- Custody suite detention for a detainee: booked, cell, out reason, next welfare check. nil if not detained.
exports('GetDetention', function(src)
    local c = VPO.State.Get(tonumber(src), 'custody')
    if not c then return nil end
    return { ref = c.ref, booked = c.booked, cell = c.cell, out = c.out, nextWelfare = c.nextWelfare, property = c.property ~= nil }
end)

--- Releases someone from police custody (property returned, out of the cell). Audited as your resource.
exports('ReleaseFromCustody', function(src, outcome)
    return VPO.Custody.Release(tonumber(src), tostring(outcome or 'Released'), 'by ' .. (GetInvokingResource() or '?'), nil)
end)

--- Discharges (rounds not handed back at the armoury). filters: { unreviewed = true, identifier = '...' }
exports('GetDischarges', function(filters) return VPO.Armoury.Discharges(filters) end)
