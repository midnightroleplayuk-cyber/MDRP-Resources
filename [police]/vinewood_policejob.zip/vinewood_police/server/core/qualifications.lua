-- Officer qualifications: held separately from rank, with expiry and supervisor sign-off.
-- One active row per qualification; re-granting closes the old row ("renewed") and opens a new one.
VPO.Qualifications = {}
local Q = VPO.Qualifications
local defs = {}
for _, d in ipairs(Config.Qualifications or {}) do defs[d.id] = d end

local cache = {} -- [identifier] = { [qual] = row }

local function now() return os.time() end

local function load(identifier)
    local map = {}
    for _, r in ipairs(MySQL.query.await([[SELECT * FROM vpo_qualifications WHERE identifier = ? AND revoked_at IS NULL
        ORDER BY granted_at ASC, id ASC]], { identifier }) or {}) do
        map[r.qualification] = r
    end
    cache[identifier] = map
    return map
end

local function held(identifier) return cache[identifier] or load(identifier) end

function Q.Def(id) return defs[id] end
function Q.Defs() return Config.Qualifications end

--- true when held and in date; false + 'missing' | 'expired'
function Q.Has(identifier, qual)
    if not identifier then return false, 'missing' end
    local r = held(identifier)[qual]
    if not r then return false, 'missing' end
    if r.expires_at and r.expires_at <= now() then return false, 'expired' end
    return true
end

--- { { id, label, grantedAt, grantedBy, expiresAt, valid } } in config order.
function Q.List(identifier)
    local out, map = {}, held(identifier)
    for _, d in ipairs(Config.Qualifications) do
        local r = map[d.id]
        if r then
            out[#out + 1] = {
                id = d.id, label = d.label, grantedAt = r.granted_at, grantedBy = r.granted_by_name,
                expiresAt = r.expires_at, valid = not r.expires_at or r.expires_at > now(), notes = r.notes,
            }
        end
    end
    return out
end

--- actor = { src?, identifier?, name, source = 'player' | 'admin' | 'console' }
--- Players are checked against rank, sign-off rules and no self sign-off. Admins and console only
--- need Config.AllowAdminQualifications. Returns true, or false + locale message.
function Q.Grant(actor, target, qual, days, notes)
    local d = defs[qual]
    if not d then return false, VPO.L('qual_unknown', tostring(qual)) end
    local targetSrc = VPO.Bridge.GetSource(target)

    if actor.source == 'player' then
        local o = VPO.Officers.Get(actor.src)
        if not o then return false, VPO.L('perm_not_police') end
        if o.identifier == target then return false, VPO.L('qual_no_self') end
        if d.grantRank and o.rank.level < VPO.Ranks.Level(d.grantRank) then
            return false, VPO.L('qual_rank', d.label, VPO.Ranks.Get(d.grantRank).label)
        end
        if d.granterNeeds and not Q.Has(o.identifier, d.granterNeeds) then
            return false, VPO.L('qual_granter_needs', defs[d.granterNeeds].label, d.label)
        end
        actor.identifier, actor.name = o.identifier, VPO.Officers.Label(o)
    elseif not Config.AllowAdminQualifications then
        return false, VPO.L('no_permission')
    end

    for _, req in ipairs(d.requires or {}) do
        if not Q.Has(target, req) then return false, VPO.L('qual_requires', d.label, defs[req].label) end
    end

    days = tonumber(days) or d.validDays or 0
    local t = now()
    local expires = days > 0 and math.floor(t + days * (Config.QualificationDayLength or 86400)) or nil
    local previous = held(target)[qual]

    local ok = MySQL.transaction.await({
        { query = [[UPDATE vpo_qualifications SET revoked_at = ?, revoked_by = ?, revoke_reason = 'renewed'
            WHERE identifier = ? AND qualification = ? AND revoked_at IS NULL]], values = { t, actor.name, target, qual } },
        { query = [[INSERT INTO vpo_qualifications (identifier, qualification, granted_by, granted_by_name, granted_at, expires_at, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?)]], values = { target, qual, actor.identifier, actor.name, t, expires, VPO.Util.Trim(notes, 255) } },
    })
    cache[target] = nil
    if not ok then return false, VPO.L('qual_failed') end

    VPO.Audit.Log({
        action = 'qual.grant', actor = actor.src, actorIdentifier = actor.identifier, actorName = actor.name, source = actor.source,
        targetType = 'officer', targetId = target,
        previous = previous and { grantedAt = previous.granted_at, expiresAt = previous.expires_at } or nil,
        new = { qualification = qual, expiresAt = expires }, reason = notes,
    })
    if targetSrc then VPO.Notify(targetSrc, VPO.L('qual_granted_target', d.label, actor.name or 'an administrator'), 'success') end
    return true
end

function Q.Revoke(actor, target, qual, reason)
    local d = defs[qual]
    if not d then return false, VPO.L('qual_unknown', tostring(qual)) end
    reason = VPO.Util.Trim(reason, 255)
    if not reason then return false, VPO.L('qual_revoke_reason') end

    if actor.source == 'player' then
        local o = VPO.Officers.Get(actor.src)
        if not o then return false, VPO.L('perm_not_police') end
        if d.grantRank and o.rank.level < VPO.Ranks.Level(d.grantRank) then
            return false, VPO.L('qual_rank', d.label, VPO.Ranks.Get(d.grantRank).label)
        end
        actor.identifier, actor.name = o.identifier, VPO.Officers.Label(o)
    elseif not Config.AllowAdminQualifications then
        return false, VPO.L('no_permission')
    end

    local current = held(target)[qual]
    if not current then return false, VPO.L('qual_not_held', target, d.label) end

    local n = MySQL.update.await([[UPDATE vpo_qualifications SET revoked_at = ?, revoked_by = ?, revoke_reason = ?
        WHERE identifier = ? AND qualification = ? AND revoked_at IS NULL]], { now(), actor.name, reason, target, qual })
    cache[target] = nil
    if not n or n == 0 then return false, VPO.L('qual_failed') end

    VPO.Audit.Log({
        action = 'qual.revoke', actor = actor.src, actorIdentifier = actor.identifier, actorName = actor.name, source = actor.source,
        targetType = 'officer', targetId = target,
        previous = { qualification = qual, grantedAt = current.granted_at, expiresAt = current.expires_at }, reason = reason,
    })
    local targetSrc = VPO.Bridge.GetSource(target)
    if targetSrc then VPO.Notify(targetSrc, VPO.L('qual_revoked_target', d.label, actor.name or 'an administrator', reason), 'error') end
    return true
end

function Q.Forget(identifier) cache[identifier] = nil end
