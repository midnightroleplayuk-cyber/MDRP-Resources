-- Chat commands: qualifications, collar numbers and the /vpo admin tools.
local C = Config.Commands
local L = VPO.L

local function reply(src, msg, kind)
    if src == 0 then print(('[%s] %s'):format(VPO.Resource, msg)) else VPO.Notify(src, msg, kind) end
end

local function replyLines(src, lines)
    if src == 0 then print(table.concat(lines, '\n')) return end
    for _, l in ipairs(lines) do TriggerClientEvent('chat:addMessage', src, { args = { 'VPO', l } }) end
end

--- Who is running the command, or nil + message.
local function actorFor(src, perm)
    if src == 0 then return { source = 'console', name = 'Server console' } end
    if not VPO.RateLimit.Allow(src, 'command') then return nil, L('rate_limited') end
    local ok, why, extra = VPO.Permissions.Check(src, perm)
    if ok then return { source = 'player', src = src } end
    if VPO.Permissions.IsAdmin(src) and Config.AllowAdminQualifications then
        return { source = 'admin', src = src, identifier = VPO.Bridge.GetIdentifier(src), name = ('%s (admin)'):format(GetPlayerName(src)) }
    end
    return nil, VPO.Permissions.Message(why, extra)
end

--- Target police officer by server id: identifier, officer.
local function officerTarget(arg)
    local id = tonumber(arg)
    if not id or not GetPlayerName(id) then return nil, L('player_not_found') end
    local o = VPO.Officers.Get(id)
    if not o then return nil, L('not_police_target') end
    return o
end

RegisterCommand(C.quals, function(src, args)
    if not VPO.Ready then return reply(src, L('not_ready'), 'error') end
    local target
    if args[1] then
        local actor, err = actorFor(src, 'qual.grant') -- seeing someone else's needs supervisor rank
        if not actor then return reply(src, err, 'error') end
        local o, e = officerTarget(args[1]); if not o then return reply(src, e, 'error') end
        target = o
    else
        if src == 0 then return reply(src, L('usage_quals', C.quals)) end
        local ok, why, extra = VPO.Permissions.Check(src, 'qual.view')
        if not ok then return reply(src, VPO.Permissions.Message(why, extra), 'error') end
        target = extra
    end
    local list = VPO.Qualifications.List(target.identifier)
    local lines = { L('qual_list_header', VPO.Officers.Label(target)) }
    if #list == 0 then lines[#lines + 1] = L('qual_none') end
    for _, q in ipairs(list) do
        local status = not q.expiresAt and L('qual_valid')
            or (q.valid and L('qual_valid_until', VPO.Util.FormatDate(q.expiresAt)) or L('qual_expired', VPO.Util.FormatDate(q.expiresAt)))
        lines[#lines + 1] = L('qual_line', q.label, status)
    end
    replyLines(src, lines)
end, false)

RegisterCommand(C.qualGrant, function(src, args)
    if not VPO.Ready then return reply(src, L('not_ready'), 'error') end
    if not args[1] or not args[2] then return reply(src, L('usage_qualgrant', C.qualGrant), 'error') end
    local actor, err = actorFor(src, 'qual.grant'); if not actor then return reply(src, err, 'error') end
    local o, e = officerTarget(args[1]); if not o then return reply(src, e, 'error') end
    local ok, msg = VPO.Qualifications.Grant(actor, o.identifier, args[2], args[3], table.concat(args, ' ', 4))
    if not ok then return reply(src, msg, 'error') end
    reply(src, L('qual_granted', VPO.Qualifications.Def(args[2]).label, VPO.Officers.Label(o)), 'success')
end, false)

RegisterCommand(C.qualRevoke, function(src, args)
    if not VPO.Ready then return reply(src, L('not_ready'), 'error') end
    if not args[1] or not args[2] then return reply(src, L('usage_qualrevoke', C.qualRevoke), 'error') end
    local actor, err = actorFor(src, 'qual.revoke'); if not actor then return reply(src, err, 'error') end
    local o, e = officerTarget(args[1]); if not o then return reply(src, e, 'error') end
    local ok, msg = VPO.Qualifications.Revoke(actor, o.identifier, args[2], table.concat(args, ' ', 3))
    if not ok then return reply(src, msg, 'error') end
    reply(src, L('qual_revoked', VPO.Qualifications.Def(args[2]).label, VPO.Officers.Label(o)), 'success')
end, false)

RegisterCommand(C.collar, function(src, args)
    if not VPO.Ready then return reply(src, L('not_ready'), 'error') end
    if not args[1] or not args[2] then return reply(src, L('usage_collar', C.collar), 'error') end
    local actor, err = actorFor(src, 'officer.collar'); if not actor then return reply(src, err, 'error') end
    local o, e = officerTarget(args[1]); if not o then return reply(src, e, 'error') end
    local collar = tostring(args[2])
    if not collar:match('^%d+$') or #collar > Config.CollarMaxDigits then
        return reply(src, L('collar_invalid', Config.CollarMaxDigits), 'error')
    end
    local ok, prev = VPO.Officers.SetCollar(o.identifier, collar)
    if not ok then return reply(src, L('collar_taken', collar), 'error') end
    VPO.Audit.Log({
        action = 'officer.collar', actor = actor.src, actorName = actor.name, source = actor.source,
        targetType = 'officer', targetId = o.identifier, previous = prev, new = collar,
    })
    reply(src, L('collar_set', o.name, collar), 'success')
    if o.src ~= src then VPO.Notify(o.src, L('collar_set_target', collar), 'inform') end
end, false)

---------------------------------------------------------------------------
-- /vpo status | /vpo state <id> <key> <json|nil>   (admin ace or console)
---------------------------------------------------------------------------
local function status()
    local lines = {
        ('vinewood_police %s  ready=%s'):format(GetResourceMetadata(VPO.Resource, 'version', 0) or '?', tostring(VPO.Ready == true)),
        ('framework: %s (%s)   inventory: %s'):format(VPO.Bridge.Name or 'NONE', VPO.Bridge.Resource or '-', VPO.Inventory.Name or 'none'),
        ('migrations: %s'):format(table.concat(VPO.Migrations.List(), ', ')),
        'integrations:',
    }
    local names = {}
    for name in pairs(VPO.Integrations.Status()) do names[#names + 1] = name end
    table.sort(names)
    local st = VPO.Integrations.Status()
    for _, name in ipairs(names) do
        local s = st[name]
        lines[#lines + 1] = s.available
            and ('  %-16s %s %s%s'):format(name, s.resource, s.version or '?', s.limited and ' (limited)' or '')
            or ('  %-16s - (%s)'):format(name, s.reason or '?')
    end
    return lines
end

RegisterCommand(C.admin, function(src, args)
    -- vpo acecheck <id>: from the server console, shows exactly why someone does or doesn't count as admin
    if args[1] == 'acecheck' and src == 0 then
        local id = tonumber(args[2])
        if not id or not GetPlayerName(id) then return print(('[%s] No player with server id %s. Use the id shown in the player list (it changes every time they reconnect).'):format(VPO.Resource, tostring(args[2]))) end
        print(('[%s] Admin check for %s (server id %d):'):format(VPO.Resource, GetPlayerName(id), id))
        for _, r in ipairs(VPO.Permissions.AdminReport(id)) do print(('  %-32s %s%s'):format(r.check, r.result and 'YES' or 'no', r.raw and ('   (native returned ' .. r.raw .. ')') or '')) end
        for _, ident in ipairs(GetPlayerIdentifiers(id)) do
            if ident:find('^license:') or ident:find('^fivem:') or ident:find('^discord:') then print('  identifier ' .. ident) end
        end
        print('  Grant with:  add_ace group.admin vinewood_police.admin allow   and   add_principal identifier.<one of the above> group.admin')
        return
    end
    if not VPO.Permissions.IsAdmin(src) then return reply(src, L('admin_needs_ace'), 'error') end
    local sub = args[1]
    if sub == nil and src ~= 0 then
        -- /vpo on its own: the admin panel
        return TriggerClientEvent('vinewood_police:client:admin:open', src)
    end
    if sub == 'status' then
        replyLines(src, status())
    elseif sub == 'state' and Config.Debug then
        local target, key = tonumber(args[2]), args[3]
        if not target or not GetPlayerName(target) or not VPO.StateDefs[key or ''] then
            return reply(src, L('usage_admin', C.admin), 'error')
        end
        local raw = table.concat(args, ' ', 4)
        local value
        if raw ~= '' and raw ~= 'nil' then
            local ok, v = pcall(json.decode, raw)
            value = ok and v or raw
        end
        local prev = VPO.State.Set(target, key, value)
        VPO.Audit.Log({ action = 'debug.state', actor = src ~= 0 and src or nil, source = src == 0 and 'console' or 'admin',
            targetType = 'player', targetId = VPO.Bridge.GetIdentifier(target), previous = { [key] = prev }, new = { [key] = value } })
        reply(src, ('%s.%s = %s'):format(target, key, json.encode(value)), 'success')
    elseif sub == 'locations' then
        if src == 0 then return reply(src, 'Use this in game.', 'error') end
        TriggerClientEvent('vinewood_police:client:locations:open', src)
    elseif sub == 'callouts' then
        local what = (args[2] or 'status'):lower()
        local by = src == 0 and 'console' or GetPlayerName(src)
        if what == 'on' then
            VPO.Callouts.SetEnabled(true, by)
            VPO.Audit.Log({ action = 'callouts.on', actor = src ~= 0 and src or nil, source = src == 0 and 'console' or 'admin' })
            reply(src, L('callouts_now_on'), 'success')
        elseif what == 'off' then
            VPO.Callouts.SetEnabled(false, by)
            local cleared = (args[3] or ''):lower() == 'clear' and VPO.Callouts.CancelPending() or 0
            VPO.Audit.Log({ action = 'callouts.off', actor = src ~= 0 and src or nil, source = src == 0 and 'console' or 'admin', meta = { cancelled = cleared } })
            reply(src, cleared > 0 and L('callouts_now_off_cleared', cleared) or L('callouts_now_off'), 'success')
        else
            local st = VPO.Callouts.Status()
            reply(src, L('callouts_status', st.enabled and L('callouts_on_word') or L('callouts_off_word'), st.open, st.active), 'inform')
        end
    elseif sub == 'callout' then
        local call, why = VPO.Callouts.AdminCreate(src, args[2] or 'shoplifting')
        if not call then return reply(src, ('Callout not created: %s'):format(tostring(why)), 'error') end
        reply(src, ('%s: %s at %s'):format(call.ref, call.title, call.location), 'success')
    elseif sub == 'uncuff' then
        local target = tonumber(args[2])
        if not target or not GetPlayerName(target) then return reply(src, L('player_not_found'), 'error') end
        if VPO.Restraint.Release(target, 'admin', src ~= 0 and src or nil) then
            VPO.Notify(target, L('restraint_uncuffed'), 'inform')
            reply(src, L('restraint_admin_released', GetPlayerName(target)), 'success')
        else
            reply(src, L('restraint_not_cuffed'), 'error')
        end
    else
        reply(src, L('usage_admin', C.admin), 'error')
    end
end, false)

---------------------------------------------------------------------------
-- Chat suggestions
---------------------------------------------------------------------------
local suggestions = {
    { '/' .. C.quals, 'Show qualifications', { { name = 'id', help = 'Officer server ID (supervisors)' } } },
    { '/' .. C.qualGrant, 'Sign off a qualification', { { name = 'id', help = 'Officer server ID' }, { name = 'qualification', help = 'e.g. taser' }, { name = 'days', help = 'Optional validity' } } },
    { '/' .. C.qualRevoke, 'Revoke a qualification', { { name = 'id', help = 'Officer server ID' }, { name = 'qualification', help = 'e.g. taser' }, { name = 'reason', help = 'Why' } } },
    { '/' .. C.collar, 'Set an officer\'s collar number', { { name = 'id', help = 'Officer server ID' }, { name = 'number', help = 'Digits only' } } },
}
VPO.Bridge.OnPlayerLoaded(function(src)
    for _, s in ipairs(suggestions) do TriggerClientEvent('chat:addSuggestion', src, s[1], s[2], s[3]) end
end)
