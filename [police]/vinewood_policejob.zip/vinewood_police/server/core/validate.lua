-- Checks the config on start and reports every problem at once, instead of failing later mid-roleplay.
VPO.Validate = {}

function VPO.Validate.Config()
    local problems = {}
    local function bad(fmt, ...) problems[#problems + 1] = fmt:format(...) end

    local rankIds, levels = {}, {}
    for i, r in ipairs(Config.Ranks or {}) do
        if type(r.id) ~= 'string' then bad('Config.Ranks[%d] has no id', i) end
        if rankIds[r.id] then bad('Rank %s is listed twice', r.id) end
        if type(r.level) ~= 'number' then bad('Rank %s has no level', r.id) end
        if levels[r.level] then bad('Ranks %s and %s share level %s', levels[r.level], r.id, r.level) end
        rankIds[r.id], levels[r.level or -1] = true, r.id
    end

    if not next(Config.Jobs or {}) then bad('Config.Jobs lists no police jobs') end
    for job, j in pairs(Config.Jobs or {}) do
        for g, rank in pairs(j.grades or {}) do
            if not tonumber(g) then bad('Config.Jobs.%s grade %s is not a number', job, tostring(g)) end
            if not rankIds[rank] then bad('Config.Jobs.%s grade %s uses unknown rank %s', job, tostring(g), tostring(rank)) end
        end
    end

    local quals = {}
    for i, q in ipairs(Config.Qualifications or {}) do
        if type(q.id) ~= 'string' then bad('Config.Qualifications[%d] has no id', i) end
        if quals[q.id] then bad('Qualification %s is listed twice', q.id) end
        quals[q.id] = true
        if q.grantRank and not rankIds[q.grantRank] then bad('Qualification %s: unknown grantRank %s', q.id, q.grantRank) end
    end
    for _, q in ipairs(Config.Qualifications or {}) do
        for _, req in ipairs(q.requires or {}) do
            if not quals[req] then bad('Qualification %s requires unknown %s', q.id, req) end
        end
        if q.granterNeeds and not quals[q.granterNeeds] then bad('Qualification %s: unknown granterNeeds %s', q.id, q.granterNeeds) end
    end

    for perm, p in pairs(Config.Permissions or {}) do
        if p.rank and not rankIds[p.rank] then bad('Permission %s uses unknown rank %s', perm, p.rank) end
        for _, q in ipairs(p.qualifications or {}) do
            if not quals[q] then bad('Permission %s needs unknown qualification %s', perm, q) end
        end
    end

    local units = {}
    for i, u in ipairs((Config.Duty or {}).UnitTypes or {}) do
        if type(u.id) ~= 'string' then bad('Config.Duty.UnitTypes[%d] has no id', i) end
        units[u.id] = true
        if u.minRank and not rankIds[u.minRank] then bad('Unit %s: unknown minRank %s', u.id, u.minRank) end
        for _, q in ipairs(u.qualifications or {}) do
            if not quals[q] then bad('Unit %s needs unknown qualification %s', u.id, q) end
        end
    end
    local statuses = {}
    for _, st in ipairs((Config.Duty or {}).Statuses or {}) do statuses[st.id] = true end
    if Config.Duty and not statuses[Config.Duty.DefaultStatus] then bad('Config.Duty.DefaultStatus %s is not in Statuses', tostring(Config.Duty.DefaultStatus)) end

    local stationIds = {}
    for i, st in ipairs(Config.Stations or {}) do
        if type(st.id) ~= 'string' then bad('Config.Stations[%d] has no id', i) end
        if stationIds[st.id] then bad('Station %s is listed twice', st.id) end
        stationIds[st.id] = true
        if st.signOn and not st.signOn.coords then bad('Station %s: signOn has no coords', st.id) end
        for j, l in ipairs(st.lockers or {}) do
            if not l.coords then bad('Station %s: locker %d has no coords', st.id, j) end
        end
        for j, a in ipairs(st.armouries or {}) do
            if not a.coords then bad('Station %s: armoury %d has no coords', st.id, j) end
        end
        for j, a in ipairs(st.changingRooms or {}) do
            if not a.coords then bad('Station %s: changing room %d has no coords', st.id, j) end
        end
    end

    local items = {}
    for i, it in ipairs((Config.Equipment or {}).Items or {}) do
        if type(it.item) ~= 'string' then bad('Config.Equipment.Items[%d] has no item', i) end
        if items[it.item] then bad('Equipment item %s is listed twice', it.item) end
        items[it.item] = true
        if it.permission and not (Config.Permissions or {})[it.permission] then bad('Equipment %s: unknown permission %s', it.item, it.permission) end
        for _, u in ipairs(it.units or {}) do if not units[u] then bad('Equipment %s: unknown unit %s', it.item, u) end end
    end
    for _, it in ipairs((Config.Equipment or {}).Items or {}) do
        if it.ammo and not items[it.ammo] then bad('Equipment %s: ammo %s is not in the equipment list', it.item, it.ammo) end
        if it.ammo and not it.armoury then bad('Equipment %s takes ammo, so it must be armoury = true', it.item) end
    end
    for _, o in ipairs(((Config.Uniforms or {}).Outfits) or {}) do
        if o.minRank and not rankIds[o.minRank] then bad('Uniform %s: unknown minRank %s', o.id, o.minRank) end
        for _, u in ipairs(o.units or {}) do if not units[u] then bad('Uniform %s: unknown unit %s', o.id, u) end end
    end

    local suiteIds = {}
    for i, su in ipairs(((Config.Custody or {}).Suites) or {}) do
        if type(su.id) ~= 'string' then bad('Config.Custody.Suites[%d] has no id', i) end
        if suiteIds[su.id] then bad('Custody suite %s is listed twice', su.id) end
        suiteIds[su.id] = true
        if not su.desk or not su.desk.coords then bad('Custody suite %s has no desk coords', su.id) end
        if not su.release then bad('Custody suite %s has no release point', su.id) end
        local cells = {}
        for j, c in ipairs(su.cells or {}) do
            if not c.id or not c.coords then bad('Custody suite %s cell %d needs id and coords', su.id, j) end
            if c.id and cells[c.id] then bad('Custody suite %s: cell %s listed twice', su.id, c.id) end
            if c.door and (not c.door.model or not c.door.coords) then bad('Custody suite %s cell %s: door needs model and coords', su.id, tostring(c.id)) end
            if c.id then cells[c.id] = true end
        end
    end

    local sceneIds = {}
    for i, sp in ipairs(((Config.Scene or {}).Props) or {}) do
        if type(sp.id) ~= 'string' or type(sp.model) ~= 'string' then bad('Config.Scene.Props[%d] needs id and model', i) end
        if sp.id and sceneIds[sp.id] then bad('Scene prop %s is listed twice', sp.id) end
        if sp.id then sceneIds[sp.id] = true end
        if sp.minRank and not rankIds[sp.minRank] then bad('Scene prop %s: unknown minRank %s', sp.id, sp.minRank) end
        if sp.traffic and sp.traffic ~= 'slow' and sp.traffic ~= 'closed' then bad('Scene prop %s: traffic must be slow or closed', sp.id) end
    end

    if Config.Incidents and Config.Incidents.SilverRank and not rankIds[Config.Incidents.SilverRank] then bad('Config.Incidents.SilverRank %s is not a rank', Config.Incidents.SilverRank) end
    if Config.CID and Config.CID.ManageRank and not rankIds[Config.CID.ManageRank] then bad('Config.CID.ManageRank %s is not a rank', Config.CID.ManageRank) end

    if Config.Management then
        if not rankIds[Config.Management.HireRank] then bad('Config.Management.HireRank %s is not a rank', tostring(Config.Management.HireRank)) end
        for job in pairs(Config.Jobs or {}) do
            if not VPO.Ranks.GradeFor(job, Config.Management.HireRank) then bad('Config.Jobs.%s has no grade for HireRank %s', job, Config.Management.HireRank) end
        end
    end

    local co = Config.Callouts or {}
    for pool, list in pairs(co.Locations or {}) do
        for i, loc in ipairs(list) do
            if not loc.coords or not loc.label then bad('Config.Callouts.Locations.%s[%d] needs label and coords', pool, i) end
        end
    end
    for id, sc in pairs(co.Scenarios or {}) do
        if type(sc.weight) ~= 'number' then bad('Config.Callouts.Scenarios.%s has no weight', id) end
    end

    for _, msg in ipairs(problems) do VPO.Log.error('Config: %s', msg) end
    return #problems == 0
end
