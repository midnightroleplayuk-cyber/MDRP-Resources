-- Fixed-window rate limiter per player and action key.
VPO.RateLimit = {}
local buckets = {}

function VPO.RateLimit.Allow(src, key)
    local rule = Config.RateLimits[key] or Config.RateLimits.default
    local now = GetGameTimer()
    local b = buckets[src]
    if not b then b = {}; buckets[src] = b end
    local e = b[key]
    if not e or now - e.start >= rule.window then
        e = { start = now, count = 0 }
        b[key] = e
    end
    e.count = e.count + 1
    if e.count > rule.max then
        if e.count == rule.max + 1 then
            VPO.Log.warn('Rate limit hit: %s by %s (%s)', key, GetPlayerName(src) or '?', src)
        end
        return false
    end
    return true
end

AddEventHandler('playerDropped', function() buckets[source] = nil end)
