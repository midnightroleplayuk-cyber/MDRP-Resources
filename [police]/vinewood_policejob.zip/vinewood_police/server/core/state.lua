-- Authoritative player state. The server holds the truth in memory and mirrors it to a replicated
-- statebag (vpo_<key>) so clients can animate. Clients never decide it: a client-side write to one
-- of these bags is reverted. Keys marked persist are saved by identifier and restored on next load,
-- so a relog or a resource restart can't be used to slip out of cuffs or custody.
--
-- VPO.State.Set(src, key, value)   value nil clears it. Returns the previous value.
-- VPO.State.Get(src, key)
-- VPO.State.All(src)
VPO.State = {}
local State = VPO.State
local Defs = VPO.StateDefs

local mem = {}        -- [src] = { [key] = value }
local byBag = {}      -- [bagKey] = key
for key, d in pairs(Defs) do byBag[d.bag] = key end

-- Monotonic write sequence so an older async save can never overwrite a newer one.
local seq = os.time() * 1000

local function persist(identifier, key, value)
    seq = seq + 1
    MySQL.prepare([[INSERT INTO vpo_player_state (identifier, state_key, value, seq, updated_at) VALUES (?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
            value = IF(VALUES(seq) > seq, VALUES(value), value),
            updated_at = IF(VALUES(seq) > seq, VALUES(updated_at), updated_at),
            seq = GREATEST(seq, VALUES(seq))]],
        { identifier, key, value ~= nil and json.encode({ v = value }) or nil, seq, os.time() })
end

function State.Set(src, key, value)
    local d = Defs[key]
    if not d then error(('unknown state key %s'):format(tostring(key))) end
    src = tonumber(src)
    if not src then return nil end
    mem[src] = mem[src] or {}
    local prev = mem[src][key]
    mem[src][key] = value
    Player(src).state:set(d.bag, value, true)
    if d.persist then
        local id = VPO.Bridge.GetIdentifier(src) or VPO.Bridge.CachedIdentifier(src)
        if id then persist(id, key, value) else VPO.Log.warn('State %s for %s not saved: no identifier', key, src) end
    end
    return prev
end

function State.Get(src, key)
    local m = mem[tonumber(src)]
    return m and m[key] or nil
end

function State.All(src) return VPO.Util.Copy(mem[tonumber(src)] or {}) end

--- Persisted state for someone offline (or not yet loaded).
function State.GetOffline(identifier, key)
    local raw = MySQL.scalar.await('SELECT value FROM vpo_player_state WHERE identifier = ? AND state_key = ?', { identifier, key })
    if not raw then return nil end
    local ok, t = pcall(json.decode, raw)
    return ok and type(t) == 'table' and t.v or nil
end

--- Sets persisted state for someone offline. Applied when they next load.
function State.SetOffline(identifier, key, value)
    if not Defs[key] or not Defs[key].persist then return false end
    local src = VPO.Bridge.GetSource(identifier)
    if src then State.Set(src, key, value) else persist(identifier, key, value) end
    return true
end

--- Loads saved state for a player who has just loaded in. Fires vinewood_police:server:stateRestored.
function State.Restore(src)
    local id = VPO.Bridge.GetIdentifier(src)
    if not id then return end
    local restored = {}
    for _, r in ipairs(MySQL.query.await('SELECT state_key, value FROM vpo_player_state WHERE identifier = ? AND value IS NOT NULL', { id }) or {}) do
        local d = Defs[r.state_key]
        if d and d.persist then
            local ok, t = pcall(json.decode, r.value)
            if ok and type(t) == 'table' and t.v ~= nil then
                mem[src] = mem[src] or {}
                mem[src][r.state_key] = t.v
                Player(src).state:set(d.bag, t.v, true)
                restored[r.state_key] = t.v
            end
        end
    end
    if next(restored) then
        VPO.Log.debug('Restored state for %s: %s', src, json.encode(restored))
        TriggerEvent(VPO.Events.stateRestored, src, restored)
    end
end

--- Clears in-memory state only (persisted values stay for the next load).
function State.Forget(src)
    src = tonumber(src)
    if not src then return end
    if GetPlayerName(src) then
        for _, d in pairs(Defs) do Player(src).state:set(d.bag, nil, true) end
    end
    mem[src] = nil
end

-- Revert client-side writes to our bags.
for bag, key in pairs(byBag) do
    AddStateBagChangeHandler(bag, nil, function(bagName, _, value)
        local src = GetPlayerFromStateBagName(bagName)
        if not src or src == 0 then return end
        local truth = mem[src] and mem[src][key]
        if VPO.Util.DeepEqual(truth, value) then return end
        SetTimeout(0, function()
            if GetPlayerName(src) then
                local now = mem[src] and mem[src][key]
                if not VPO.Util.DeepEqual(Player(src).state[bag], now) then
                    VPO.Log.warn('Reverted client change to %s by %s (%s)', bag, GetPlayerName(src), src)
                    Player(src).state:set(bag, now, true)
                end
            end
        end)
    end)
end

AddEventHandler('playerDropped', function() mem[source] = nil end)
