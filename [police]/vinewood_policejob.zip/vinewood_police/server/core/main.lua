-- Start-up: config check, inventory pick, database migrations, audit retention, integrations,
-- then restore everyone already online (covers a resource restart mid-session).
VPO.Ready = false
VPO.Failed = false

-- GlobalState outlives a resource restart: clear what the last run left so clients don't act on it.
for _, key in ipairs({ 'vpo_npc_peds', 'vpo_npc_cuffed', 'vpo_enc_peds', 'vpo_dogs', 'vpo_stingers', 'vpo_scene_zones', 'vpo_incidents', 'vpo_tapes' }) do
    GlobalState[key] = {}
end

--- Blocks the calling thread until start-up finishes. Returns false if it failed.
function VPO.WaitReady()
    while not VPO.Ready and not VPO.Failed do Wait(100) end
    return VPO.Ready
end

local function onLoaded(src)
    if not VPO.WaitReady() then return end
    VPO.Officers.Ensure(src)
    VPO.State.Restore(src)
end

local function onUnloaded(src, identifier)
    VPO.State.Forget(src)
    VPO.Officers.Forget(identifier)
    VPO.Qualifications.Forget(identifier)
end

VPO.Bridge.OnPlayerLoaded(function(src) CreateThread(function() onLoaded(src) end) end)
VPO.Bridge.OnPlayerUnloaded(onUnloaded)

CreateThread(function()
    if not VPO.Bridge.Name then VPO.Failed = true; return end
    if not VPO.Validate.Config() then
        VPO.Log.error('Fix the config errors above, then restart %s.', VPO.Resource)
        VPO.Failed = true
        return
    end

    VPO.Inventory._Init()

    local ok, err = pcall(VPO.Migrations.Run)
    if not ok then
        VPO.Log.error('Database setup failed: %s', err)
        VPO.Failed = true
        return
    end

    VPO.Audit.Purge()
    VPO.Integrations.DetectAll()

    VPO.Ready = true
    TriggerEvent(VPO.Events.ready)

    -- Players already in the city (resource restart): load them as if they had just joined.
    for _, id in ipairs(GetPlayers()) do
        local src = tonumber(id)
        if src and VPO.Bridge.GetIdentifier(src) then VPO.Bridge._Loaded(src) end
    end

    VPO.Log.info('Ready. Framework %s, inventory %s.', VPO.Bridge.Name, VPO.Inventory.Name or 'none')
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= VPO.Resource then return end
    -- Statebags are cleared so clients don't keep stale animations; persisted values stay in the database.
    for _, id in ipairs(GetPlayers()) do
        local src = tonumber(id)
        for _, d in pairs(VPO.StateDefs) do Player(src).state:set(d.bag, nil, true) end
    end
end)
