-- Guarded net events and callbacks. Every player-triggered action in later drops goes through these,
-- so readiness, rate limiting, permissions and error handling are never forgotten.
--
-- VPO.Net.On('arrest:make', { permission = 'arrest.make', rate = 'arrest' }, function(src, officer, ...) end)
-- VPO.Net.Callback('officer:me', { permission = 'qual.view' }, function(src, officer, ...) return {...} end)
-- Event names are prefixed with 'vinewood_police:server:' / callbacks with 'vinewood_police:cb:'.
VPO.Net = {}

local function guard(src, opts)
    if not VPO.Ready then return false, { error = VPO.L('not_ready') } end
    if not VPO.RateLimit.Allow(src, opts.rate or 'default') then return false, { error = VPO.L('rate_limited') } end
    if opts.permission then
        local ok, why, extra = VPO.Permissions.Check(src, opts.permission)
        if not ok then return false, { error = VPO.Permissions.Message(why, extra) } end
        return true, extra
    end
    return true, VPO.Officers.Get(src)
end

function VPO.Net.On(name, opts, handler)
    RegisterNetEvent('vinewood_police:server:' .. name, function(...)
        local src = source
        local ok, officer = guard(src, opts)
        if not ok then
            if not opts.silent then VPO.Notify(src, officer.error, 'error') end
            return
        end
        local good, err = pcall(handler, src, officer, ...)
        if not good then VPO.Log.error('%s failed: %s', name, err) end
    end)
end

function VPO.Net.Callback(name, opts, handler)
    lib.callback.register('vinewood_police:cb:' .. name, function(src, ...)
        local ok, officer = guard(src, opts)
        if not ok then return officer end
        local good, res = pcall(handler, src, officer, ...)
        if not good then
            VPO.Log.error('%s failed: %s', name, res)
            return { error = VPO.L('qual_failed') }
        end
        return res
    end)
end

--- Asks a player to choose (a prompt on their screen). options = { { id, label }, ... }, first is the
--- main button. Returns the chosen id, or nil if they didn't answer in time or left.
function VPO.AskPlayer(target, title, text, options, timeout)
    timeout = timeout or 20
    local p, done = promise.new(), false
    lib.callback('vinewood_police:client:choice', target, function(choice)
        if not done then done = true; p:resolve(choice) end
    end, { title = title, text = text, options = options, timeout = timeout })
    SetTimeout((timeout + 3) * 1000, function()
        if not done then done = true; p:resolve(nil) end
    end)
    return Citizen.Await(p)
end
