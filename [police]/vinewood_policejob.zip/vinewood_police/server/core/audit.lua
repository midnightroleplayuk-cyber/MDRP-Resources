-- Append-only audit log. Code only ever inserts; the one delete is the retention purge on start.
--
-- VPO.Audit.Log({
--     action = 'qual.grant',            -- required
--     actor = src,                      -- player source, or nil for system / console
--     source = 'player',                -- 'player' | 'console' | 'admin' | 'system' | 'export:<resource>'
--     targetType = 'officer', targetId = 'ABC123',
--     previous = {...}, new = {...},    -- tables are stored as JSON
--     reason = 'text', meta = {...},
-- })
VPO.Audit = {}

local function enc(v)
    if v == nil then return nil end
    if type(v) == 'table' then return json.encode(v) end
    return tostring(v)
end

function VPO.Audit.Log(e)
    if type(e) ~= 'table' or type(e.action) ~= 'string' then return end
    local actorId, actorName = e.actorIdentifier, e.actorName
    if e.actor and e.actor ~= 0 then
        actorId = actorId or VPO.Bridge.GetIdentifier(e.actor) or VPO.Bridge.CachedIdentifier(e.actor)
        actorName = actorName or VPO.Bridge.GetName(e.actor)
    end
    local src = e.source or (e.actor and e.actor ~= 0 and 'player' or 'system')
    local row = {
        os.time(), e.action:sub(1, 64), tostring(src):sub(1, 64), actorId, actorName and actorName:sub(1, 100),
        e.targetType, e.targetId and tostring(e.targetId):sub(1, 64), enc(e.previous), enc(e.new),
        e.reason and tostring(e.reason):sub(1, 500), enc(e.meta),
    }
    MySQL.insert([[INSERT INTO vpo_audit (created_at, action, source, actor_identifier, actor_name, target_type, target_id,
        previous_value, new_value, reason, meta) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)]], row, function(id)
        if not id then VPO.Log.error('Audit entry for %s was not saved', e.action) end
    end)
    if Config.Audit.Console then
        VPO.Log.info('AUDIT %s by %s (%s) on %s:%s %s', e.action, actorName or '-', src, e.targetType or '-', e.targetId or '-', e.reason or '')
    end
end

--- Reads entries, newest first. filters: { action, actorIdentifier, targetType, targetId, since, limit, beforeId }
function VPO.Audit.Query(f)
    f = f or {}
    local where, args = {}, {}
    if f.action then where[#where + 1] = 'action = ?'; args[#args + 1] = f.action end
    if f.actorIdentifier then where[#where + 1] = 'actor_identifier = ?'; args[#args + 1] = f.actorIdentifier end
    if f.targetType then where[#where + 1] = 'target_type = ?'; args[#args + 1] = f.targetType end
    if f.targetId then where[#where + 1] = 'target_id = ?'; args[#args + 1] = tostring(f.targetId) end
    if f.since then where[#where + 1] = 'created_at >= ?'; args[#args + 1] = f.since end
    if f.beforeId then where[#where + 1] = 'id < ?'; args[#args + 1] = f.beforeId end
    args[#args + 1] = math.min(tonumber(f.limit) or 50, 500)
    local sql = 'SELECT * FROM vpo_audit' .. (#where > 0 and (' WHERE ' .. table.concat(where, ' AND ')) or '')
        .. ' ORDER BY id DESC LIMIT ?'
    return MySQL.query.await(sql, args) or {}
end

function VPO.Audit.Purge()
    local days = tonumber(Config.Audit.KeepDays) or 0
    if days <= 0 then return end
    local n = MySQL.update.await('DELETE FROM vpo_audit WHERE created_at < ?', { os.time() - days * 86400 })
    if n and n > 0 then VPO.Log.info('Removed %d audit entries older than %d days', n, days) end
end
