-- Built-in defaults for settings that newer versions add. config/ files are left open under escrow, so a
-- server that keeps its own config/ranks.lua or config/qualifications.lua through an update won't have the
-- new entries. Anything missing is filled in from here, and the console says which, so nothing is refused
-- just because the config is older than the resource.

local PERMISSIONS = {
    ['duty.toggle']    = { rank = 'student', duty = false },
    ['qual.view']      = { rank = 'student', duty = false },
    ['qual.grant']     = { rank = 'ps' },
    ['qual.revoke']    = { rank = 'ps' },
    ['officer.collar'] = { rank = 'ps' },
    ['audit.view']     = { rank = 'insp', duty = false },

    ['duty.status']    = { rank = 'student' },
    ['roster.view']    = { rank = 'student' },
    ['notebook.write'] = { rank = 'student', duty = false },

    ['equipment.basic']    = { rank = 'student' },
    ['equipment.taser']    = { rank = 'pc', qualifications = { 'taser' } },
    ['equipment.firearms'] = { rank = 'pc', qualifications = { 'firearms' } },
    ['restraint.cuff']     = { rank = 'student' },
    ['restraint.escort']   = { rank = 'student' },
    ['arrest.make']        = { rank = 'student' },
    ['search.person']      = { rank = 'student' },
    ['search.seize']       = { rank = 'student' },
    ['stopsearch.record']  = { rank = 'student' },
    ['arrest.release']     = { rank = 'student' },
    ['roads.stop']         = { rank = 'student' },
    ['roads.ticket']       = { rank = 'student' },
    ['roads.search']       = { rank = 'student' },
    ['roads.test']         = { rank = 'student' },
    ['roads.seize']        = { rank = 'pc' },
    ['scene.place']        = { rank = 'student' },
    ['custody.view']       = { rank = 'student' },
    ['custody.cells']      = { rank = 'student' },                                  -- cells, welfare checks
    ['custody.book']       = { rank = 'ps' },                                       -- book in, observation level, release (sergeant and above)
    ['evidence.view']      = { rank = 'student' },
    ['calls.attend']       = { rank = 'student' },
    ['incident.join']      = { rank = 'student' },
    ['incident.declare']   = { rank = 'ps' },             -- declare, assign roles, move cordons, stand down
    ['cid.view']           = { rank = 'pc' },
    ['cid.create']         = { rank = 'pc' },
    ['uof.submit']         = { rank = 'student', duty = false },
    ['standards.view']     = { rank = 'insp', duty = false },   -- reviews, complaints, audit log
    ['dogs.handle']        = { rank = 'pc', qualifications = { 'dog_handler' } },
    ['roads.stinger']      = { rank = 'pc', qualifications = { 'stinger' } },
    -- Management (/management): rank limits always apply on top of these
    ['manage.view']        = { rank = 'insp', duty = false },
    ['manage.hire']        = { rank = 'insp', duty = false },
    ['manage.promote']     = { rank = 'ci', duty = false },
    ['manage.discipline']  = { rank = 'insp', duty = false },  -- suspend from duty
    ['manage.fire']        = { rank = 'supt', duty = false },
    ['evidence.manage']    = { rank = 'ps' },                                       -- return to owner, destroy
}

local QUALIFICATIONS = {
    { id = 'basic_driver',        label = 'Basic driver',                validDays = 0,   grantRank = 'ps' },
    { id = 'response_driver',     label = 'Response driver',             validDays = 0,   grantRank = 'ps',   requires = { 'basic_driver' } },
    { id = 'advanced_driver',     label = 'Advanced driver (TPAC)',      validDays = 0,   grantRank = 'insp', requires = { 'response_driver' } },
    { id = 'taser',               label = 'Taser (CED)',                 validDays = 365, grantRank = 'ps' },
    { id = 'firearms',            label = 'Authorised firearms officer', validDays = 365, grantRank = 'insp' },
    { id = 'dog_handler',         label = 'Dog handler',                 validDays = 0,   grantRank = 'insp' },
    { id = 'public_order',        label = 'Public order (Level 2)',      validDays = 365, grantRank = 'ps' },
    { id = 'custody',             label = 'Custody trained',             validDays = 0,   grantRank = 'insp' },
    { id = 'tutor',               label = 'Tutor constable',             validDays = 0,   grantRank = 'ps' },
    { id = 'stinger',             label = 'Stinger (tactical pursuit)',  validDays = 365, grantRank = 'ps' },
    { id = 'independent_patrol',  label = 'Independent patrol',          validDays = 0,   grantRank = 'ps',   granterNeeds = 'tutor' },
}

local added = {}
for key, def in pairs(PERMISSIONS) do
    if Config.Permissions[key] == nil then
        Config.Permissions[key] = def
        added[#added + 1] = key
    end
end
if #added > 0 then
    table.sort(added)
    VPO.Log.warn('config/ranks.lua is missing %d permission(s), using the defaults: %s. Copy them from the new config/ranks.lua to change them.',
        #added, table.concat(added, ', '))
end

local have, addedQ = {}, {}
for _, x in ipairs(Config.Qualifications) do have[x.id] = true end
for _, def in ipairs(QUALIFICATIONS) do
    if not have[def.id] then
        Config.Qualifications[#Config.Qualifications + 1] = def
        addedQ[#addedQ + 1] = def.id
    end
end
if #addedQ > 0 then
    VPO.Log.warn('config/qualifications.lua is missing %s, using the default(s).', table.concat(addedQ, ', '))
end

-- Older config.lua had AdminAce as a single string: keep it working, and add the default admin ace too.
if type(Config.AdminAce) == 'string' then
    Config.AdminAce = { Config.AdminAce, 'command' }
end
