-- Permission checks. Rank, duty and qualifications, all read on the server at the moment of the action.
--
-- On success:  true, nil, officer
-- On failure:  false, why, extra, officer?
--   why: 'unknown' | 'not_police' | 'rank' | 'off_duty' | 'qualification' (extra = the qualification id)
VPO.Permissions = {}
local P = VPO.Permissions

-- The duty module registers itself here. Without it the framework's duty flag is used
-- (nil on ESX, which counts as on duty).
local dutyProvider

function P.SetDutyProvider(fn) dutyProvider = fn end

--- true / false for police officers. nil for anyone who isn't in a police job (not ours to answer,
--- so the MDT and dispatch fall back to their own rules), and nil on ESX with no duty module.
function VPO.IsOnDuty(src)
    src = tonumber(src)
    if not src then return nil end
    local job = VPO.Bridge.GetJob(src)
    if not job or not Config.Jobs[job.name] then return nil end
    if dutyProvider then return dutyProvider(src) == true end
    return job.onduty
end

function P.Check(src, perm)
    local def = Config.Permissions[perm]
    if not def then
        VPO.Log.warn('Permission "%s" is not in Config.Permissions (config/ranks.lua): refused for %s', tostring(perm), GetPlayerName(src) or src)
        return false, 'unknown', perm
    end
    local o = VPO.Officers.Get(src)
    if not o then return false, 'not_police' end
    if def.rank and o.rank.level < VPO.Ranks.Level(def.rank) then return false, 'rank', nil, o end
    if def.duty ~= false and VPO.IsOnDuty(src) == false then return false, 'off_duty', nil, o end
    for _, q in ipairs(def.qualifications or {}) do
        if not VPO.Qualifications.Has(o.identifier, q) then return false, 'qualification', q, o end
    end
    return true, nil, o
end

--- Player-facing message for a failed check.
function P.Message(why, extra)
    if why == 'not_police' then return VPO.L('perm_not_police') end
    if why == 'rank' then return VPO.L('perm_rank') end
    if why == 'off_duty' then return VPO.L('perm_off_duty') end
    if why == 'qualification' then
        local d = VPO.Qualifications.Def(extra)
        return VPO.L('perm_qualification', d and d.label or tostring(extra))
    end
    if why == 'unknown' then return VPO.L('perm_not_configured', tostring(extra)) end
    return VPO.L('no_permission')
end

-- IsPlayerAceAllowed returns 1 (not true) on some server builds, so anything truthy other than 0 counts.
-- Checked with the id as a number and as a string, as builds differ there too.
local function aceOk(src, ace)
    for _, id in ipairs({ src, tostring(src) }) do
        local ok, r = pcall(IsPlayerAceAllowed, id, ace)
        if ok and r and r ~= 0 then return true end
    end
    return false
end

local function aceList()
    local a = Config.AdminAce
    if type(a) == 'table' then return a end
    return { a or 'vinewood_police.admin' }
end

--- Every way this player could count as an admin, for vpo acecheck.
function P.AdminReport(src)
    local out = {}
    for _, ace in ipairs(aceList()) do
        out[#out + 1] = { check = ('ace %s'):format(ace), result = aceOk(src, ace), raw = tostring(IsPlayerAceAllowed(tostring(src), ace)) }
    end
    if Config.FrameworkAdmins ~= false then
        out[#out + 1] = { check = 'framework admin', result = VPO.Bridge.IsFrameworkAdmin(src) == true }
    end
    return out
end

function P.IsAdmin(src)
    if src == 0 then return true end
    for _, ace in ipairs(aceList()) do
        if aceOk(src, ace) then return true end
    end
    if Config.FrameworkAdmins ~= false and VPO.Bridge.IsFrameworkAdmin(src) then return true end
    VPO.Log.warn('%s (server id %s) was refused an admin tool. Run "vpo acecheck %s" in the server console to see why.',
        GetPlayerName(src) or '?', src, src)
    return false
end
