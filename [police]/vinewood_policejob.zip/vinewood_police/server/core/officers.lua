-- Officer records (collar number, callsign) and the officer view other modules use.
--
-- VPO.Officers.Get(src) -> {
--     src, identifier, name, job, grade, rank = { id, label, short, level },
--     collar, callsign, onDuty
-- } or nil when the player isn't in a police job.
VPO.Officers = {}
local Officers = VPO.Officers
local cache = {} -- [identifier] = row

local function load(identifier)
    local row = MySQL.single.await('SELECT identifier, display_name, collar_number, callsign FROM vpo_officers WHERE identifier = ?', { identifier })
    cache[identifier] = row or false
    return row
end

local function row(identifier)
    local r = cache[identifier]
    if r == nil then r = load(identifier) end
    return r or nil
end

--- Creates or refreshes the officer's row when a police character loads.
function Officers.Ensure(src)
    local job = VPO.Bridge.GetJob(src)
    if not job or not Config.Jobs[job.name] then return end
    local id, name = VPO.Bridge.GetIdentifier(src), VPO.Bridge.GetName(src)
    if not id then return end
    local t = os.time()
    MySQL.insert.await([[INSERT INTO vpo_officers (identifier, display_name, created_at, updated_at) VALUES (?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE display_name = VALUES(display_name), updated_at = VALUES(updated_at)]], { id, name, t, t })
    load(id)
end

function Officers.Get(src)
    src = tonumber(src)
    if not src then return nil end
    local job = VPO.Bridge.GetJob(src)
    if not job then return nil end
    local rank = VPO.Ranks.FromJob(job.name, job.grade)
    if not rank then return nil end
    local id = VPO.Bridge.GetIdentifier(src)
    if not id then return nil end
    local r = row(id) or {}
    local callsign = r.callsign
    local live = VPO.Integrations.Get('dispatch')
    if live then
        local ok, cs = pcall(live.GetStoredCallsign, src)
        if ok and cs and cs ~= '' then callsign = cs end
    end
    return {
        src = src,
        identifier = id,
        name = VPO.Bridge.GetName(src),
        job = job.name,
        grade = job.grade,
        rank = rank,
        collar = r.collar_number,
        callsign = callsign,
        onDuty = VPO.IsOnDuty(src) ~= false,
    }
end

--- "PC 4521 Smith"-style label for records.
function Officers.Label(o)
    if not o then return 'Unknown' end
    local parts = { o.rank and o.rank.short or nil, o.collar, o.name }
    local out = {}
    for _, p in ipairs(parts) do if p and p ~= '' then out[#out + 1] = p end end
    return table.concat(out, ' ')
end

function Officers.SetCollar(identifier, collar)
    local taken = MySQL.scalar.await('SELECT identifier FROM vpo_officers WHERE collar_number = ? AND identifier <> ?', { collar, identifier })
    if taken then return false, 'taken' end
    local prev = (row(identifier) or {}).collar_number
    local t = os.time()
    local ok, res = pcall(MySQL.insert.await, [[INSERT INTO vpo_officers (identifier, collar_number, created_at, updated_at) VALUES (?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE collar_number = VALUES(collar_number), updated_at = VALUES(updated_at)]], { identifier, collar, t, t })
    if not ok or res == nil then return false, 'taken' end -- the unique key caught a race
    load(identifier)
    return true, prev
end

function Officers.SetCallsign(identifier, callsign)
    MySQL.update.await('UPDATE vpo_officers SET callsign = ?, updated_at = ? WHERE identifier = ?', { callsign, os.time(), identifier })
    load(identifier)
end

function Officers.Forget(identifier) cache[identifier] = nil end
