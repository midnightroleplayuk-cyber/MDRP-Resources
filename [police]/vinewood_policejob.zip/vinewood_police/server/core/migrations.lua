-- Versioned SQL migrations. Each runs once, in order, and is recorded in vpo_schema_migrations.
-- Add new files to the end of this list; never edit or reorder an applied one.
VPO.Migrations = {}

local MIGRATIONS = {
    '001_core',
    '002_duty',
    '003_arrests',
    '004_roads',
    '005_npc',
    '006_roadside',
    '007_custody',
    '008_npc_custody',
    '009_callouts',
    '010_locations',
    '011_armoury',
    '012_incidents_cid',
    '013_standards',
    '014_management',
}

local function statements(sql)
    local out = {}
    -- Drop line comments, then split on semicolons that end a line.
    local clean = {}
    for line in (sql .. '\n'):gmatch('(.-)\r?\n') do
        if not line:match('^%s*%-%-') then clean[#clean + 1] = line end
    end
    for stmt in (table.concat(clean, '\n') .. '\n'):gmatch('(.-);%s*\n') do
        stmt = stmt:gsub('^%s+', ''):gsub('%s+$', '')
        if stmt ~= '' then out[#out + 1] = stmt end
    end
    return out
end

local function exec(query)
    local ok, res = pcall(MySQL.query.await, query)
    if not ok then return false, res end
    if res == nil then return false, 'no result (see the oxmysql error above)' end
    return true
end

function VPO.Migrations.Run()
    local ok, err = exec([[CREATE TABLE IF NOT EXISTS `vpo_schema_migrations` (
        `id` VARCHAR(64) NOT NULL PRIMARY KEY,
        `applied_at` INT UNSIGNED NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]])
    if not ok then error(('could not create vpo_schema_migrations: %s'):format(err)) end

    local applied = {}
    for _, r in ipairs(MySQL.query.await('SELECT id FROM vpo_schema_migrations') or {}) do applied[r.id] = true end

    for _, id in ipairs(MIGRATIONS) do
        if not applied[id] then
            local sql = LoadResourceFile(VPO.Resource, ('sql/migrations/%s.sql'):format(id))
            if not sql then error(('migration file sql/migrations/%s.sql is missing'):format(id)) end
            for i, stmt in ipairs(statements(sql)) do
                local good, why = exec(stmt)
                if not good then error(('migration %s, statement %d failed: %s'):format(id, i, tostring(why))) end
            end
            MySQL.insert.await('INSERT INTO vpo_schema_migrations (id, applied_at) VALUES (?, ?)', { id, os.time() })
            VPO.Log.info('Applied database migration %s', id)
        end
    end
end

function VPO.Migrations.List() return MIGRATIONS end
