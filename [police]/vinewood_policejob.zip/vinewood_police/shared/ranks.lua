-- Rank lookups shared by server and client.
VPO.Ranks = {}
local Ranks = VPO.Ranks

local byId = {}
for _, r in ipairs(Config.Ranks or {}) do byId[r.id] = r end

function Ranks.Get(id) return byId[id] end

function Ranks.Level(id)
    local r = byId[id]
    return r and r.level or 0
end

--- Rank for a framework job and grade, or nil if the job isn't a police job.
function Ranks.FromJob(jobName, grade)
    local job = jobName and Config.Jobs[jobName]
    if not job then return nil end
    grade = tonumber(grade) or 0
    local best, bestGrade
    for g, rankId in pairs(job.grades or {}) do
        g = tonumber(g)
        if g and g <= grade and (not bestGrade or g > bestGrade) then best, bestGrade = rankId, g end
    end
    return best and byId[best] or nil
end

--- Lowest framework grade that maps to this rank in a job, or nil.
function Ranks.GradeFor(jobName, rankId)
    local job = Config.Jobs[jobName]
    if not job then return nil end
    local best
    for g, r in pairs(job.grades or {}) do
        g = tonumber(g)
        if r == rankId and g and (not best or g < best) then best = g end
    end
    return best
end
