-- Converting places between the config's vectors and plain tables (for the database, GlobalState and NUI),
-- and writing them into Config. Shared so server and client apply them the same way.
VPO.Loc = {}
local LC = VPO.Loc

--- Vectors to { x, y, z (, w) } tables, recursively.
function LC.Plain(v)
    local t = type(v)
    if t == 'vector3' then return { x = v.x, y = v.y, z = v.z } end
    if t == 'vector4' then return { x = v.x, y = v.y, z = v.z, w = v.w } end
    if t ~= 'table' then return v end
    local out = {}
    for k, x in pairs(v) do out[k] = LC.Plain(x) end
    return out
end

local function isPoint(t)
    if type(t) ~= 'table' or type(t.x) ~= 'number' or type(t.y) ~= 'number' or type(t.z) ~= 'number' then return false end
    for k in pairs(t) do if k ~= 'x' and k ~= 'y' and k ~= 'z' and k ~= 'w' then return false end end
    return true
end

--- { x, y, z (, w) } tables back to vectors, recursively.
function LC.Vectors(v)
    if type(v) ~= 'table' then return v end
    if isPoint(v) then
        if type(v.w) == 'number' then return vector4(v.x, v.y, v.z, v.w) end
        return vector3(v.x, v.y, v.z)
    end
    local out = {}
    for k, x in pairs(v) do out[k] = LC.Vectors(x) end
    return out
end

--- Outfit pieces as a list: { { id = component, d = drawable, t = texture } }. The config's older
--- shape ({ [11] = { 55, 0 } }) is converted; lists are what the editor saves (they survive JSON).
function LC.Pieces(set)
    local out = {}
    for k, v in pairs(set or {}) do
        if type(v) == 'table' then
            if v.id ~= nil then out[#out + 1] = { id = tonumber(v.id), d = tonumber(v.d) or 0, t = tonumber(v.t) or 0 }
            else out[#out + 1] = { id = tonumber(k), d = tonumber(v[1]) or 0, t = tonumber(v[2]) or 0 } end
        end
    end
    table.sort(out, function(a, b) return a.id < b.id end)
    return out
end

function LC.NormaliseOutfits(list)
    local out = {}
    for _, u in ipairs(list or {}) do
        local x = { id = u.id, label = u.label, minRank = u.minRank, units = u.units, qualifications = u.qualifications }
        for _, sex in ipairs({ 'male', 'female' }) do
            if u[sex] then x[sex] = { components = LC.Pieces(u[sex].components), props = LC.Pieces(u[sex].props) } end
        end
        out[#out + 1] = x
    end
    return out
end

--- The editable places: where each lives in Config.
LC.Keys = {
    stations = { get = function() return Config.Stations end, set = function(v) Config.Stations = v end },
    custody = { get = function() return Config.Custody.Suites end, set = function(v) Config.Custody.Suites = v end },
    callouts = { get = function() return Config.Callouts.Locations end, set = function(v) Config.Callouts.Locations = v end },
    hostileZones = { get = function() return Config.NPC.NoHostileZones end, set = function(v) Config.NPC.NoHostileZones = v end },
    uniforms = { get = function() return LC.NormaliseOutfits(Config.Uniforms.Outfits) end, set = function(v) Config.Uniforms.Outfits = v end },
}

--- Write plain data for one key into Config.
function LC.Apply(key, plain)
    local k = LC.Keys[key]
    if k and plain ~= nil then k.set(LC.Vectors(plain)) end
end
