-- Event names and the authoritative player state keys.
VPO.Events = {
    notify = 'vinewood_police:client:notify',
    ready = 'vinewood_police:server:ready',
    stateRestored = 'vinewood_police:server:stateRestored',
}

--- Player state owned by the server. `bag` is the replicated statebag key clients read
--- (LocalPlayer.state.vpo_cuffed etc.). `persist` keeps the value across relogs and restarts.
VPO.StateDefs = {
    duty     = { bag = 'vpo_duty',     persist = false },
    cuffed   = { bag = 'vpo_cuffed',   persist = true },
    escort   = { bag = 'vpo_escort',   persist = false },
    escorting = { bag = 'vpo_escorting', persist = false },
    detained = { bag = 'vpo_detained', persist = true },
    custody  = { bag = 'vpo_custody',  persist = true },
}
