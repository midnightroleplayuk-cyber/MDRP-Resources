-- Shared namespace, logging, utilities and locale.
VPO = VPO or {}
VPO.Resource = GetCurrentResourceName()
VPO.IsServer = IsDuplicityVersion()

---------------------------------------------------------------------------
-- Logging
---------------------------------------------------------------------------
local LEVELS = { error = 1, warn = 2, info = 3, debug = 4 }
local COLOURS = { error = '^1', warn = '^3', info = '^2', debug = '^5' }

local function log(level, fmt, ...)
    local want = LEVELS[Config.LogLevel or 'info'] or 3
    if LEVELS[level] > want then return end
    local msg = tostring(fmt)
    if select('#', ...) > 0 then
        local ok, out = pcall(string.format, msg, ...)
        if ok then msg = out end
    end
    print(('%s[%s:%s]^7 %s'):format(COLOURS[level], VPO.Resource, level, msg))
end

VPO.Log = {
    error = function(...) log('error', ...) end,
    warn  = function(...) log('warn', ...) end,
    info  = function(...) log('info', ...) end,
    debug = function(...) log('debug', ...) end,
}

---------------------------------------------------------------------------
-- Utilities
---------------------------------------------------------------------------
local Util = {}
VPO.Util = Util

function Util.Trim(s, max)
    if type(s) ~= 'string' then return nil end
    s = s:gsub('^%s+', ''):gsub('%s+$', '')
    if s == '' then return nil end
    return max and s:sub(1, max) or s
end

function Util.DeepEqual(a, b)
    if a == b then return true end
    if type(a) ~= 'table' or type(b) ~= 'table' then return false end
    for k, v in pairs(a) do if not Util.DeepEqual(v, b[k]) then return false end end
    for k in pairs(b) do if a[k] == nil then return false end end
    return true
end

function Util.Copy(t)
    if type(t) ~= 'table' then return t end
    local out = {}
    for k, v in pairs(t) do out[k] = Util.Copy(v) end
    return out
end

function Util.Contains(list, v)
    for _, x in ipairs(list or {}) do if x == v then return true end end
    return false
end

--- Compares dotted versions. Returns -1, 0 or 1.
function Util.CompareVersion(a, b)
    local pa, pb = {}, {}
    for n in tostring(a or ''):gmatch('%d+') do pa[#pa + 1] = tonumber(n) end
    for n in tostring(b or ''):gmatch('%d+') do pb[#pb + 1] = tonumber(n) end
    for i = 1, math.max(#pa, #pb) do
        local x, y = pa[i] or 0, pb[i] or 0
        if x ~= y then return x < y and -1 or 1 end
    end
    return 0
end

--- UK date and 24-hour time.
function Util.FormatTime(t)
    if not t then return '' end
    return os.date('%d/%m/%Y %H:%M', t)
end

function Util.FormatDate(t)
    if not t then return '' end
    return os.date('%d/%m/%Y', t)
end

---------------------------------------------------------------------------
-- Locale
---------------------------------------------------------------------------
local strings = {}
local function loadLocale(lang)
    local raw = LoadResourceFile(VPO.Resource, ('locales/%s.json'):format(lang))
    if not raw then return nil end
    local ok, data = pcall(json.decode, raw)
    return ok and type(data) == 'table' and data or nil
end
strings = loadLocale(Config.Locale or 'en') or loadLocale('en') or {}

function VPO.L(key, ...)
    local s = strings[key] or key
    if select('#', ...) > 0 then
        local ok, out = pcall(string.format, s, ...)
        if ok then return out end
    end
    return s
end
