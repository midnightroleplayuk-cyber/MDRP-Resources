-- Stinger: lay one ahead of you (/stinger, again to withdraw it). Any vehicle this game controls that
-- crosses a stinger has its tyres deflated.
local Cfg = Config.Stinger
local L = VPO.L
local mine = false

RegisterCommand(Cfg.Command, function()
    if not LocalPlayer.state[VPO.StateDefs.duty.bag] then return VPO.ClientNotify(L('perm_off_duty'), 'error') end
    CreateThread(function()
        if mine then
            local res = lib.callback.await('vinewood_police:cb:stinger:withdraw', false)
            mine = false
            if type(res) == 'table' and not res.error then VPO.ClientNotify(L('stinger_withdrawn'), 'inform') end
            return
        end
        local ped = PlayerPedId()
        if IsPedInAnyVehicle(ped, false) then return VPO.ClientNotify(L('stinger_on_foot'), 'error') end
        local fwd = GetOffsetFromEntityInWorldCoords(ped, 0.0, 3.0, 0.0)
        local found, gz = GetGroundZFor_3dCoord(fwd.x, fwd.y, fwd.z + 1.0, false)
        -- Laid across the road: at right angles to the way you face
        local res = lib.callback.await('vinewood_police:cb:stinger:deploy', false,
            { x = fwd.x, y = fwd.y, z = found and gz or fwd.z - 1.0, h = (GetEntityHeading(ped) + 90.0) % 360.0 })
        if type(res) ~= 'table' or res.error then return VPO.ClientNotify(res and res.error or L('scene_failed'), 'error') end
        mine = true
        VPO.ClientNotify(L('stinger_laid', res.lifetime), 'success')
        SetTimeout(res.lifetime * 1000, function() mine = false end)
    end)
end, false)

local burst = {} -- [vehicle] = true

CreateThread(function()
    while true do
        local list = GlobalState.vpo_stingers or {}
        local me = GetEntityCoords(PlayerPedId())
        local active = false
        for net, s in pairs(list) do
            local centre = vector3(s.x, s.y, s.z)
            if #(me - centre) < 150.0 then
                active = true
                local obj = NetworkDoesEntityExistWithNetworkId(tonumber(net)) and NetworkGetEntityFromNetworkId(tonumber(net)) or 0
                if obj ~= 0 then
                    for _, veh in ipairs(GetGamePool('CVehicle')) do
                        if not burst[veh] and NetworkHasControlOfEntity(veh) and #(GetEntityCoords(veh) - centre) < 6.0
                            and not (Cfg.IgnoreEmergencyVehicles and GetVehicleClass(veh) == 18) then
                            local off = GetOffsetFromEntityGivenWorldCoords(obj, GetEntityCoords(veh))
                            if math.abs(off.x) < 2.6 and math.abs(off.y) < 1.4 then
                                burst[veh] = true
                                for _, w in ipairs({ 0, 1, 4, 5 }) do SetVehicleTyreBurst(veh, w, false, 1000.0) end
                                TriggerServerEvent('vinewood_police:server:stinger:hit', net, GetVehicleNumberPlateText(veh))
                            end
                        end
                    end
                end
            end
        end
        Wait(active and 0 or 1000)
    end
end)

-- Forget burst vehicles that no longer exist
CreateThread(function()
    while true do
        Wait(30000)
        for veh in pairs(burst) do if not DoesEntityExist(veh) then burst[veh] = nil end end
    end
end)
