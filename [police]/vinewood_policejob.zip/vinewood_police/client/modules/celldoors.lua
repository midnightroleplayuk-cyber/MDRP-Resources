-- Custody cell doors: registered with the game's door system and kept in step with the server
-- (GlobalState.vpo_celldoors). Same approach as vinewood_prison: doors are re-attached whenever their
-- object reloads, so a door never shows open while it's meant to be locked.
local doors = {} -- [key] = { hash, model, coords, bound }

local function key(suite, cell) return suite .. ':' .. cell end
local function lockedFor(k) local t = GlobalState.vpo_celldoors or {}; return t[k] ~= false end

local function setState(k, locked)
    local d = doors[k]
    if not d then return end
    if locked then
        DoorSystemSetDoorState(d.hash, 4, false, false) -- swing shut and latch this frame
        SetTimeout(50, function()
            if doors[k] and lockedFor(k) then DoorSystemSetDoorState(d.hash, 1, false, false) end
        end)
    else
        DoorSystemSetDoorState(d.hash, 0, false, false)
    end
end

local function load()
    for _, d in pairs(doors) do RemoveDoorFromSystem(d.hash) end
    doors = {}
    for _, su in ipairs(Config.Custody.Suites or {}) do
        for _, cell in ipairs(su.cells or {}) do
            if cell.door and cell.door.coords then
                local k = key(su.id, cell.id)
                local c = cell.door.coords
                local h = GetHashKey('vpo_cell_' .. k)
                AddDoorToSystem(h, cell.door.model, c.x, c.y, c.z, false, false, false)
                doors[k] = { hash = h, model = cell.door.model, coords = vector3(c.x, c.y, c.z), bound = nil }
                DoorSystemSetDoorState(h, lockedFor(k) and 1 or 0, false, true)
            end
        end
    end
end

AddStateBagChangeHandler('vpo_celldoors', 'global', function(_, _, value)
    SetTimeout(0, function()
        for k in pairs(doors) do setState(k, (value or {})[k] ~= false) end
    end)
end)

AddEventHandler('vinewood_police:client:locationsChanged', function() SetTimeout(500, load) end)
CreateThread(function() Wait(2500); load() end)

-- Re-attach doors whose object reloaded, and correct any that drifted from the server's state
local GAME_LOCKED = { [1] = true, [2] = true, [4] = true, [6] = true }
CreateThread(function()
    local tick = 0
    while true do
        Wait(500)
        tick = tick + 1
        local me = GetEntityCoords(PlayerPedId())
        for k, d in pairs(doors) do
            local dist = #(me - d.coords)
            if dist < 80.0 then
                local obj = GetClosestObjectOfType(d.coords.x, d.coords.y, d.coords.z, 1.0, d.model, false, false, false)
                if obj ~= 0 and (obj ~= d.bound or not IsDoorRegisteredWithSystem(d.hash)) then
                    RemoveDoorFromSystem(d.hash)
                    AddDoorToSystem(d.hash, d.model, d.coords.x, d.coords.y, d.coords.z, false, false, false)
                    d.bound = obj
                    setState(k, lockedFor(k))
                elseif obj == 0 then
                    d.bound = nil
                elseif tick % 4 == 0 and dist < 40.0 and (GAME_LOCKED[DoorSystemGetDoorState(d.hash)] == true) ~= lockedFor(k) then
                    setState(k, lockedFor(k))
                end
            elseif d.bound then
                d.bound = nil
            end
        end
    end
end)

-- Lock / unlock at the door
VPO.Zones.Register('celldoors', function()
    local out = {}
    for _, su in ipairs(Config.Custody.Suites or {}) do
        for _, cell in ipairs(su.cells or {}) do
            if cell.door and cell.door.coords then
                local suiteId, cellId = su.id, cell.id
                out[#out + 1] = { name = ('vpo_celldoor_%s_%s'):format(suiteId, cellId),
                    box = { coords = vector3(cell.door.coords.x, cell.door.coords.y, cell.door.coords.z), size = vec3(1.4, 1.4, 2.4), rotation = 0.0 },
                    options = {
                        { name = 'vpo_celldoor', label = ('%s: lock / unlock'):format(cell.label), icon = 'fas fa-door-closed', distance = 2.5,
                          canInteract = function() return LocalPlayer.state[VPO.StateDefs.duty.bag] ~= nil end,
                          onSelect = function()
                              CreateThread(function()
                                  local res = lib.callback.await('vinewood_police:cb:custody:door', false, { suite = suiteId, cell = cellId })
                                  if type(res) ~= 'table' then return end
                                  VPO.ClientNotify(res.error or res.message, res.error and 'error' or 'inform')
                              end)
                          end },
                    } }
            end
        end
    end
    return out
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= VPO.Resource then return end
    for _, d in pairs(doors) do RemoveDoorFromSystem(d.hash) end
end)
