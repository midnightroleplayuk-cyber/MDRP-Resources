-- Places set in game: apply them from the server, and the editor's helpers (your position, go there,
-- markers showing what you're editing).
local LC = VPO.Loc

local function applyAll(all)
    if type(all) ~= 'table' then return end
    for key, data in pairs(all) do LC.Apply(key, data) end
    TriggerEvent('vinewood_police:client:locationsChanged')
end

AddStateBagChangeHandler('vpo_locations', 'global', function(_, _, value) SetTimeout(0, function() applyAll(value) end) end)
CreateThread(function()
    Wait(500)
    if GlobalState.vpo_locations then applyAll(GlobalState.vpo_locations) end
end)

---------------------------------------------------------------------------
-- Editor
---------------------------------------------------------------------------
RegisterNetEvent('vinewood_police:client:locations:open', function()
    VPO.UI.OpenTask('locations', 'loc:get', nil)
end)

RegisterNUICallback('locMyPos', function(_, cb)
    local ped = PlayerPedId()
    local c = GetEntityCoords(ped)
    cb({ x = c.x, y = c.y, z = c.z, w = GetEntityHeading(ped), street = VPO.Location() })
end)

RegisterNUICallback('locTp', function(body, cb)
    cb({})
    if type(body) ~= 'table' or not tonumber(body.x) then return end
    local ped = PlayerPedId()
    DoScreenFadeOut(300)
    Wait(350)
    SetEntityCoords(ped, body.x + 0.0, body.y + 0.0, body.z + 0.0, false, false, false, false)
    if body.w then SetEntityHeading(ped, body.w + 0.0) end
    Wait(300)
    DoScreenFadeIn(400)
end)

-- Markers for the section being edited
local preview = {}
RegisterNUICallback('locPreview', function(body, cb)
    preview = type(body) == 'table' and body.points or {}
    cb({})
end)

local function text3d(x, y, z, label)
    SetDrawOrigin(x, y, z, 0)
    BeginTextCommandDisplayText('STRING')
    SetTextScale(0.32, 0.32)
    SetTextFont(4)
    SetTextCentre(true)
    SetTextOutline()
    AddTextComponentSubstringPlayerName(label)
    EndTextCommandDisplayText(0.0, 0.0)
    ClearDrawOrigin()
end

CreateThread(function()
    while true do
        if #preview == 0 then
            Wait(500)
        else
            Wait(0)
            local me = GetEntityCoords(PlayerPedId())
            for _, p in ipairs(preview) do
                if #(me - vector3(p.x, p.y, p.z)) < 80.0 then
                    local r, g, b = 47, 111, 224
                    if p.kind == 'cell' then r, g, b = 233, 211, 28 elseif p.kind == 'zone' then r, g, b = 217, 83, 79 end
                    DrawMarker(p.kind == 'zone' and 1 or 2, p.x, p.y, p.z + (p.kind == 'zone' and -1.0 or 0.3), 0.0, 0.0, 0.0, 0.0, 180.0, 0.0,
                        p.kind == 'zone' and 1.5 or 0.4, p.kind == 'zone' and 1.5 or 0.4, p.kind == 'zone' and 1.0 or 0.4,
                        r, g, b, 180, false, true, 2, false, nil, nil, false)
                    text3d(p.x, p.y, p.z + 0.9, p.label or '')
                end
            end
        end
    end
end)

-- Markers go when the panel closes
AddEventHandler('vinewood_police:client:uiClosed', function() preview = {} end)

---------------------------------------------------------------------------
-- Walking about with the editor open: let go of the mouse, F7 (rebindable) to take it back
---------------------------------------------------------------------------
local walking = false

RegisterNUICallback('locWalk', function(_, cb)
    cb({})
    walking = true
    SetNuiFocus(false, false)
    CreateThread(function()
        while walking and VPO.UI.open do
            BeginTextCommandDisplayHelp('STRING')
            AddTextComponentSubstringPlayerName(VPO.L('loc_walk_help'))
            EndTextCommandDisplayHelp(0, false, false, -1)
            Wait(0)
        end
        walking = false
    end)
end)

RegisterCommand('vpo_editor_focus', function()
    if walking and VPO.UI.open then
        walking = false
        SetNuiFocus(true, true)
    end
end, false)
RegisterKeyMapping('vpo_editor_focus', 'Police: back to the location editor', 'keyboard', 'F7')

AddEventHandler('vinewood_police:client:uiClosed', function() walking = false end)

---------------------------------------------------------------------------
-- Uniform editor: capture what you're wearing, try a uniform on, back to your own clothes
---------------------------------------------------------------------------
RegisterNUICallback('locOutfit', function(_, cb) cb(VPO.CurrentClothes()) end)

RegisterNUICallback('locTryOutfit', function(body, cb)
    cb({})
    if type(body) ~= 'table' then return end
    if body.own then VPO.WearUniform('own') return end
    if type(body.set) == 'table' then VPO.TryClothes(body.set) end
end)
