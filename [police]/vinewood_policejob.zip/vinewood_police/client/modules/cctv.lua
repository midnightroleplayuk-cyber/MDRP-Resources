-- Custody CCTV, operator style (same feel as vinewood_prison): WASD pans and tilts, the mouse
-- fine-adjusts, scroll zooms, all eased. Left/right arrows change camera, Backspace goes back to the
-- custody computer.  Also the cell buzzers: the detainee's call button and the suite's alarm sound.
local Cfg = Config.Custody.CCTV
local L = VPO.L
local viewing = false

local function clamp(v, lo, hi) return math.max(lo, math.min(hi, v)) end

local function text(x, y, str, scale, r, g, b, centre)
    SetTextFont(4); SetTextScale(scale, scale); SetTextColour(r or 255, g or 255, b or 255, 235); SetTextOutline()
    if centre then SetTextCentre(true) end
    BeginTextCommandDisplayText('STRING'); AddTextComponentSubstringPlayerName(str); EndTextCommandDisplayText(x, y)
end

local function view(data)
    if viewing or not data or not data.cameras or #data.cameras == 0 then return end
    viewing = true
    VPO.UI.Close()
    local cams, i = data.cameras, data.start or 1
    local cam = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
    local tYaw, tPitch, tFov, cYaw, cPitch, cFov, baseFov

    local function apply()
        local c = cams[i]
        baseFov = clamp(tonumber(c.fov) or 50.0, Cfg.MinFov, Cfg.MaxFov)
        tYaw, tPitch, tFov, cYaw, cPitch, cFov = 0.0, 0.0, baseFov, 0.0, 0.0, baseFov
        SetCamCoord(cam, c.coords.x, c.coords.y, c.coords.z)
        SetCamRot(cam, c.rot.x, 0.0, c.rot.z, 2)
        SetCamFov(cam, cFov)
        SetFocusPosAndVel(c.coords.x, c.coords.y, c.coords.z, 0.0, 0.0, 0.0)
    end

    DoScreenFadeOut(150); Wait(160)
    RenderScriptCams(true, false, 0, true, true)
    SetTimecycleModifier(Cfg.Filter)
    SetTimecycleModifierStrength(Cfg.FilterStrength)
    apply()
    DoScreenFadeIn(250)

    while viewing do
        Wait(0)
        DisableAllControlActions(0)
        EnableControlAction(0, 245, true) -- chat
        local dt = GetFrameTime()
        local c = cams[i]
        local zoomScale = cFov / baseFov
        local speed = Cfg.PanSpeed * zoomScale * dt
        if IsDisabledControlPressed(0, 34) then tYaw = tYaw + speed end
        if IsDisabledControlPressed(0, 35) then tYaw = tYaw - speed end
        if IsDisabledControlPressed(0, 32) then tPitch = tPitch + speed end
        if IsDisabledControlPressed(0, 33) then tPitch = tPitch - speed end
        tYaw = clamp(tYaw - GetDisabledControlNormal(0, 1) * Cfg.MouseSensitivity * zoomScale * 10.0, -Cfg.MaxYaw, Cfg.MaxYaw)
        tPitch = clamp(tPitch - GetDisabledControlNormal(0, 2) * Cfg.MouseSensitivity * zoomScale * 10.0, -Cfg.MaxPitch, Cfg.MaxPitch)
        if IsDisabledControlJustPressed(0, 241) then tFov = clamp(tFov - Cfg.ZoomStep, Cfg.MinFov, Cfg.MaxFov) end
        if IsDisabledControlJustPressed(0, 242) then tFov = clamp(tFov + Cfg.ZoomStep, Cfg.MinFov, Cfg.MaxFov) end
        local k = 1.0 - math.exp(-Cfg.Smoothing * dt)
        cYaw, cPitch, cFov = cYaw + (tYaw - cYaw) * k, cPitch + (tPitch - cPitch) * k, cFov + (tFov - cFov) * k
        SetCamRot(cam, c.rot.x + cPitch, 0.0, c.rot.z + cYaw, 2)
        SetCamFov(cam, cFov)

        -- Overlay: camera, who's in the cell, time, recording light
        local label = ('CAM %02d/%02d  %s'):format(i, #cams, c.label:upper())
        text(0.03, 0.03, label, 0.5)
        if c.cellLabel then text(0.03, 0.075, c.occupant and ('%s: %s'):format(c.cellLabel, c.occupant) or ('%s: empty'):format(c.cellLabel), 0.38, 220, 230, 240) end
        local y, mo, d, h, mi, se = GetLocalTime()
        text(0.97 - 0.16, 0.03, ('%02d/%02d/%04d %02d:%02d:%02d'):format(d, mo, y, h, mi, se), 0.45)
        if math.floor(GetGameTimer() / 600) % 2 == 0 then text(0.97 - 0.16, 0.07, '● REC', 0.4, 230, 60, 60) end
        text(0.03, 0.03 + 0.06 * 0 + 0.88, ('%s   ZOOM %.1fx'):format(data.suite or '', baseFov / cFov), 0.36, 200, 210, 220)
        text(0.5, 0.94, '~INPUT_CELLPHONE_LEFT~ ~INPUT_CELLPHONE_RIGHT~ camera   WASD pan   scroll zoom   ~INPUT_COVER~ centre   ~INPUT_FRONTEND_RRIGHT~ back', 0.36, 255, 255, 255, true)

        if IsDisabledControlJustPressed(0, 174) then i = i > 1 and i - 1 or #cams; apply() end
        if IsDisabledControlJustPressed(0, 175) then i = i < #cams and i + 1 or 1; apply() end
        if IsDisabledControlJustPressed(0, 44) then tYaw, tPitch, tFov = 0.0, 0.0, baseFov end
        if IsDisabledControlJustPressed(0, 177) or IsDisabledControlJustPressed(0, 200) then viewing = false end
    end

    DoScreenFadeOut(150); Wait(160)
    ClearTimecycleModifier()
    RenderScriptCams(false, false, 0, true, true)
    DestroyCam(cam, false)
    ClearFocus()
    DoScreenFadeIn(250)
    VPO.UI.OpenTask('custody', 'custody:panel', nil)
end

RegisterNUICallback('custodyCctv', function(body, cb)
    cb({})
    CreateThread(function()
        local res = VPO.UI.Request('custody:cctv', { camera = type(body) == 'table' and body.camera or nil })
        if res.error then return VPO.ClientNotify(res.error, 'error') end
        view(res)
    end)
end)

---------------------------------------------------------------------------
-- Cell buzzers
---------------------------------------------------------------------------
local BZ = Config.Custody.Buzzer or {}

RegisterCommand('vpo_cellbuzzer', function()
    local st = LocalPlayer.state[VPO.StateDefs.custody.bag]
    if not BZ.Enabled or not st or not st.cell or st.out then return end
    TriggerServerEvent('vinewood_police:server:custody:buzz')
    VPO.ClientNotify(L('custody_buzzer_pressed'), 'inform', 2500)
end, false)
RegisterKeyMapping('vpo_cellbuzzer', 'Custody: press the cell call button', 'keyboard', BZ.Key or 'E')

-- Help text for the detainee while they're in a cell
local buzzTag = ('~INPUT_%X~'):format((GetHashKey('vpo_cellbuzzer') & 0xFFFFFFFF) | 0x80000000)
CreateThread(function()
    while true do
        local st = BZ.Enabled and LocalPlayer.state[VPO.StateDefs.custody.bag]
        if st and st.cell and not st.out then
            Wait(0)
            BeginTextCommandDisplayHelp('STRING')
            AddTextComponentSubstringPlayerName(('%s cell call button'):format(buzzTag))
            EndTextCommandDisplayHelp(0, false, false, -1)
        else
            Wait(1000)
        end
    end
end)

RegisterNetEvent('vinewood_police:client:custody:buzzer', function(b)
    if type(b) ~= 'table' then return end
    SendNUIMessage({ type = 'sound', name = 'custody_buzzer', volume = b.volume or 0.55 })
    if b.notify then VPO.ClientNotify(L('custody_buzzer_alert', b.label or 'Cell'), 'inform', 6000) end
    if VPO.UI.open then SendNUIMessage({ type = 'custodyRefresh' }) end
end)

RegisterNetEvent('vinewood_police:client:custody:buzzerStop', function()
    SendNUIMessage({ type = 'soundStop', name = 'custody_buzzer' })
end)
