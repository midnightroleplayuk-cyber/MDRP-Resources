-- Professional standards on the client: telling the server when an officer fires a Taser or firearm
-- (it starts a use of force form), and the /standards and /complaint commands.
local Cfg = Config.Standards
local L = VPO.L

local watched = {}
for _, w in ipairs(Cfg.TaserWeapons) do watched[GetHashKey(w)] = w end
for _, w in ipairs(Cfg.FirearmWeapons) do watched[GetHashKey(w)] = w end

-- Cheap when idle: checks what's in your hands twice a second, and only watches for shots while it's
-- a Taser or firearm.
CreateThread(function()
    local last = 0
    while true do
        local ped = PlayerPedId()
        local name = LocalPlayer.state[VPO.StateDefs.duty.bag] and watched[GetSelectedPedWeapon(ped)] or nil
        if not name then
            Wait(500)
        else
            Wait(0)
            if IsPedShooting(ped) and GetGameTimer() - last > 10000 then
                last = GetGameTimer()
                TriggerServerEvent('vinewood_police:server:standards:discharge', name)
            end
        end
    end
end)

RegisterCommand(Cfg.Command, function()
    VPO.UI.OpenTask('standards', 'standards:panel', nil)
end, false)

RegisterCommand(Cfg.ComplaintCommand, function()
    VPO.UI.OpenTask('complaint', 'complaint:prepare', nil)
end, false)

RegisterCommand(Config.Management.Command, function()
    VPO.UI.OpenTask('management', 'manage:panel', nil)
end, false)
