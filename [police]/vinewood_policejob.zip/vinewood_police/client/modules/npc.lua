-- Moves NPCs for the stops this officer controls. The server decides what happens; this client
-- only carries it out on the ped and reports back when it has stopped or given itself up.
local C = Config.NPC
local active = {} -- [stopId] = { ped, veh, state }

local function entityFrom(net)
    local deadline = GetGameTimer() + 3000
    while not NetworkDoesEntityExistWithNetworkId(net) and GetGameTimer() < deadline do Wait(50) end
    if not NetworkDoesEntityExistWithNetworkId(net) then return 0 end
    return NetworkGetEntityFromNetworkId(net)
end

local function takeControl(ent)
    if ent == 0 then return false end
    local deadline = GetGameTimer() + 2000
    NetworkRequestControlOfEntity(ent)
    while not NetworkHasControlOfEntity(ent) and GetGameTimer() < deadline do
        Wait(50)
        NetworkRequestControlOfEntity(ent)
    end
    return NetworkHasControlOfEntity(ent)
end

local function loadDict(d)
    RequestAnimDict(d)
    local deadline = GetGameTimer() + 3000
    while not HasAnimDictLoaded(d) and GetGameTimer() < deadline do Wait(10) end
end

local function report(stop, event) TriggerServerEvent('vinewood_police:server:npc:event', stop, event) end

--- Any on-duty officer's ped within range of this ped.
local function officerNear(ped, range)
    local pc = GetEntityCoords(ped)
    for _, pid in ipairs(GetActivePlayers()) do
        local sid = GetPlayerServerId(pid)
        if Player(sid).state[VPO.StateDefs.duty.bag] then
            if #(GetEntityCoords(GetPlayerPed(pid)) - pc) <= range then return true end
        end
    end
    return false
end

local function surrenderPose(ped)
    ClearPedTasksImmediately(ped)
    loadDict('random@arrests@busted')
    TaskPlayAnim(ped, 'random@arrests@busted', 'idle_a', 8.0, -8.0, -1, 1, 0.0, false, false, false)
end

local function prepare(ped, veh)
    SetEntityAsMissionEntity(ped, true, true)
    if veh ~= 0 then SetEntityAsMissionEntity(veh, true, true) end
    SetBlockingOfNonTemporaryEvents(ped, true)
    SetPedKeepTask(ped, true)
end

---------------------------------------------------------------------------
-- Watchers
---------------------------------------------------------------------------
local function watchStop(stop, ped, veh)
    CreateThread(function()
        local deadline = GetGameTimer() + 15000
        while GetGameTimer() < deadline and active[stop] and active[stop].state == 'pull_over' do
            Wait(250)
            if GetEntitySpeed(veh) < 0.8 and GetGameTimer() > deadline - 13000 then break end
        end
        if not active[stop] or active[stop].state ~= 'pull_over' then return end
        TaskVehicleTempAction(ped, veh, 27, 600000)
        SetVehicleEngineOn(veh, false, false, true)
        SetVehicleIndicatorLights(veh, 0, true)
        SetVehicleIndicatorLights(veh, 1, true)
        active[stop].state = 'stopped'
        report(stop, 'stopped')
    end)
end

local function watchCatch(stop, ped)
    CreateThread(function()
        local closeSince
        while active[stop] and (active[stop].state == 'flee_foot' or active[stop].state == 'hostile') do
            Wait(200)
            if not DoesEntityExist(ped) then return end
            local caught = IsPedBeingStunned(ped, 0) or IsPedRagdoll(ped)
                or (active[stop].state == 'hostile' and GetEntityHealth(ped) < GetEntityMaxHealth(ped) * 0.6)
            if officerNear(ped, C.CatchDistance) then
                closeSince = closeSince or GetGameTimer()
                if GetGameTimer() - closeSince >= C.CatchSeconds * 1000 then caught = true end
            else
                closeSince = nil
            end
            if caught then
                Wait(1200) -- let a ragdoll finish
                active[stop].state = 'surrendered'
                surrenderPose(ped)
                report(stop, 'surrendered')
                return
            end
        end
    end)
end

---------------------------------------------------------------------------
-- Instructions from the server
---------------------------------------------------------------------------
RegisterNetEvent('vinewood_police:client:npc:control', function(m)
    if type(m) ~= 'table' then return end
    local ped, veh = entityFrom(m.ped), entityFrom(m.veh)
    if ped == 0 then return end
    takeControl(ped)
    if veh ~= 0 then takeControl(veh) end
    local me = PlayerPedId()
    active[m.stop] = active[m.stop] or { ped = ped, veh = veh }
    local a = active[m.stop]
    a.state = m.action

    if m.action == 'pull_over' then
        prepare(ped, veh)
        local to = GetOffsetFromEntityInWorldCoords(veh, 3.5, 28.0, 0.0)
        TaskVehicleDriveToCoord(ped, veh, to.x, to.y, to.z, 7.0, 0, GetEntityModel(veh), 786603, 4.0, true)
        watchStop(m.stop, ped, veh)

    elseif m.action == 'flee_vehicle' then
        prepare(ped, veh)
        SetDriverAbility(ped, 1.0)
        SetDriverAggressiveness(ped, 0.8)
        TaskVehicleMissionPedTarget(ped, veh, me, 8, 38.0, 786468, 300.0, 15.0, true)

    elseif m.action == 'step_out' then
        TaskLeaveVehicle(ped, veh, 0)
        CreateThread(function()
            Wait(2500)
            TaskTurnPedToFaceEntity(ped, me, -1)
        end)

    elseif m.action == 'flee_foot' then
        prepare(ped, veh)
        SetPedFleeAttributes(ped, 0, false)
        if IsPedInAnyVehicle(ped, false) then TaskLeaveVehicle(ped, veh, 256); Wait(1200) end
        TaskSmartFleePed(ped, me, 600.0, -1, false, false)
        watchCatch(m.stop, ped)

    elseif m.action == 'hostile' then
        prepare(ped, veh)
        RemoveAllPedWeapons(ped, true)
        SetPedFleeAttributes(ped, 0, false)
        SetPedCombatAttributes(ped, 46, true)
        if IsPedInAnyVehicle(ped, false) then TaskLeaveVehicle(ped, veh, 256); Wait(1200) end
        SetBlockingOfNonTemporaryEvents(ped, false)
        TaskCombatPed(ped, me, 0, 16)
        watchCatch(m.stop, ped)

    elseif m.action == 'cuff' then
        ClearPedTasksImmediately(ped)
        if IsPedInAnyVehicle(ped, false) then TaskLeaveVehicle(ped, veh, 16); Wait(1500) end
        loadDict('mp_arresting')
        TaskPlayAnim(ped, 'mp_arresting', 'idle', 8.0, -8.0, -1, 1, 0.0, false, false, false)
        SetEnableHandcuffs(ped, true)

    elseif m.action == 'handover' then
        NetworkFadeOutEntity(ped, false, true)
        Wait(1500)
        if NetworkHasControlOfEntity(ped) then DeleteEntity(ped) end
        active[m.stop] = nil

    elseif m.action == 'release' then
        SetEnableHandcuffs(ped, false)
        ClearPedTasks(ped)
        if veh ~= 0 then
            SetVehicleIndicatorLights(veh, 0, false)
            SetVehicleIndicatorLights(veh, 1, false)
            if not IsPedInVehicle(ped, veh, false) then
                TaskEnterVehicle(ped, veh, 10000, -1, 1.0, 1, 0)
                local deadline = GetGameTimer() + 10000
                while not IsPedInVehicle(ped, veh, false) and GetGameTimer() < deadline do Wait(250) end
            end
            SetVehicleEngineOn(veh, true, false, true)
            TaskVehicleDriveWander(ped, veh, 15.0, 786603)
        end
        SetBlockingOfNonTemporaryEvents(ped, false)
        SetPedKeepTask(ped, false)
        Wait(5000)
        SetEntityAsNoLongerNeeded(ped)
        if veh ~= 0 then SetEntityAsNoLongerNeeded(veh) end
        active[m.stop] = nil

    elseif m.action == 'forget' then
        -- Got away: let the game clean them up normally
        SetPedKeepTask(ped, false)
        SetEntityAsNoLongerNeeded(ped)
        if veh ~= 0 then SetEntityAsNoLongerNeeded(veh) end
        active[m.stop] = nil
    end
end)

---------------------------------------------------------------------------
-- Talk to an NPC driver who has left their car
---------------------------------------------------------------------------
local function stopVehicleFor(ped)
    local list = GlobalState.vpo_npc_peds or {}
    if not NetworkGetEntityIsNetworked(ped) then return nil end
    return list[tostring(NetworkGetNetworkIdFromEntity(ped))]
end

local pedOptions = {
    { name = 'vpo_npc_talk', label = 'Speak to them (vehicle stop)', icon = 'fas fa-comments', distance = 3.0,
      canInteract = function(e)
          return LocalPlayer.state[VPO.StateDefs.duty.bag] ~= nil and not IsPedAPlayer(e) and stopVehicleFor(e) ~= nil
      end,
      onSelect = function(e)
          local vehNet = stopVehicleFor(e)
          CreateThread(function()
              local data = VPO.UI.Request('roads:open', { net = vehNet, location = VPO.Location() })
              if data.error then return VPO.ClientNotify(data.error, 'error') end
              VPO.UI.open = true
              SetNuiFocus(true, true)
              SendNUIMessage({ type = 'task', task = 'roadside', data = data, location = VPO.Location() })
          end)
      end },
}

CreateThread(function()
    Wait(1400)
    VPO.Target.AddGlobalPed(pedOptions)
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= VPO.Resource then return end
    VPO.Target.RemoveGlobalPed(pedOptions)
    for _, a in pairs(active) do
        if DoesEntityExist(a.ped) then SetEntityAsNoLongerNeeded(a.ped) end
        if a.veh ~= 0 and DoesEntityExist(a.veh) then SetEntityAsNoLongerNeeded(a.veh) end
    end
end)
