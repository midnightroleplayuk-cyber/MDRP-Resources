-- Vehicle stops: /stopvehicle from a police car, the roadside panel at the vehicle, and the
-- driver's side (notice and a reminder while they're being signalled).
local Cfg = Config.Roads
local L = VPO.L

local function onDuty() return LocalPlayer.state[VPO.StateDefs.duty.bag] ~= nil end

--- Vehicle ahead of mine: a ray along my heading, then the closest vehicle in a cone in front.
local function vehicleAhead(mine)
    local from = GetOffsetFromEntityInWorldCoords(mine, 0.0, 3.0, 0.4)
    local to = GetOffsetFromEntityInWorldCoords(mine, 0.0, Cfg.StopRange, 0.4)
    local ray = StartShapeTestCapsule(from.x, from.y, from.z, to.x, to.y, to.z, 2.5, 10, mine, 7)
    local _, hit, _, _, ent = GetShapeTestResult(ray)
    if hit == 1 and ent ~= 0 and GetEntityType(ent) == 2 then return ent end
    -- Fallback: nearest vehicle in front within range
    local best, bestDist
    local myPos, fwd = GetEntityCoords(mine), GetEntityForwardVector(mine)
    for _, v in ipairs(GetGamePool('CVehicle')) do
        if v ~= mine then
            local d = GetEntityCoords(v) - myPos
            local dist = #d
            if dist < Cfg.StopRange and dist > 2.0 and (d.x * fwd.x + d.y * fwd.y) / dist > 0.85 then
                if not bestDist or dist < bestDist then best, bestDist = v, dist end
            end
        end
    end
    return best
end

local function stopVehicle()
    if not onDuty() then return VPO.ClientNotify(L('perm_off_duty'), 'error') end
    local ped = PlayerPedId()
    local mine = GetVehiclePedIsIn(ped, false)
    if mine == 0 or GetPedInVehicleSeat(mine, -1) ~= ped then return VPO.ClientNotify(L('roads_must_drive'), 'error') end
    if Cfg.RequireEmergencyVehicle and GetVehicleClass(mine) ~= 18 then return VPO.ClientNotify(L('roads_need_police_vehicle'), 'error') end
    if Cfg.RequireLights and not IsVehicleSirenOn(mine) then return VPO.ClientNotify(L('roads_lights_on'), 'error') end
    local target = vehicleAhead(mine)
    if not target or not NetworkGetEntityIsNetworked(target) then return VPO.ClientNotify(L('roads_nothing_ahead'), 'error') end
    CreateThread(function()
        local res = lib.callback.await('vinewood_police:cb:roads:initiate', false, { net = VehToNet(target), location = VPO.Location() })
        if type(res) ~= 'table' or res.error then return VPO.ClientNotify(res and res.error or L('restraint_failed'), 'error') end
        VPO.ClientNotify(L('roads_stop_started', res.plate, res.ref), 'success')
        -- Mark the stopped car for a minute so you don't lose it in traffic
        local blip = AddBlipForEntity(target)
        SetBlipColour(blip, 3)
        SetBlipFlashes(blip, true)
        SetTimeout(60000, function() if DoesBlipExist(blip) then RemoveBlip(blip) end end)
    end)
end

RegisterCommand(Cfg.StopCommand, stopVehicle, false)
if Cfg.StopKeybind and Cfg.StopKeybind ~= '' then
    RegisterKeyMapping(Cfg.StopCommand, 'Police: stop the vehicle in front', 'keyboard', Cfg.StopKeybind)
end

--- Opens the roadside panel for a vehicle (target menu and radial menu).
function VPO.OpenRoadside(veh)
    CreateThread(function()
        local data = VPO.UI.Request('roads:open', { net = VehToNet(veh), location = VPO.Location() })
        if data.error then return VPO.ClientNotify(data.error, 'error') end
        data.modelLabel = GetLabelText(GetDisplayNameFromVehicleModel(GetEntityModel(veh)))
        VPO.UI.open = true
        SetNuiFocus(true, true)
        SendNUIMessage({ type = 'task', task = 'roadside', data = data, location = VPO.Location() })
    end)
end

-- Roadside panel from the target menu on any vehicle
local options = {
    { name = 'vpo_roadside', label = 'Roadside checks', icon = 'fas fa-car-on', distance = 4.0,
      canInteract = function() return onDuty() and not IsPedInAnyVehicle(PlayerPedId(), false) and not VPO.IsCuffed() end,
      onSelect = function(veh) VPO.OpenRoadside(veh) end },
}

CreateThread(function()
    Wait(1300)
    VPO.Target.AddGlobalVehicle(options)
end)
AddEventHandler('onResourceStop', function(res)
    if res == VPO.Resource then VPO.Target.RemoveGlobalVehicle(options) end
end)

-- Driver being signalled to stop: a reminder until they've pulled up or 30 seconds pass.
RegisterNetEvent('vinewood_police:client:roads:signal', function()
    local ped = PlayerPedId()
    local untilT = GetGameTimer() + 30000
    CreateThread(function()
        while GetGameTimer() < untilT do
            local veh = GetVehiclePedIsIn(ped, false)
            if veh == 0 or GetEntitySpeed(veh) < 0.5 then break end
            BeginTextCommandDisplayHelp('STRING')
            AddTextComponentSubstringPlayerName(L('roads_signal_help'))
            EndTextCommandDisplayHelp(0, false, false, -1)
            Wait(0)
        end
    end)
end)

---------------------------------------------------------------------------
-- Opening a stopped car's boot or glovebox (ox_inventory)
---------------------------------------------------------------------------
VPO.UI.After('roads:searchVehicle', function(res)
    if GetResourceState('ox_inventory') ~= 'started' then
        return VPO.ClientNotify(L('roads_search_ox_only'), 'error')
    end
    local veh = NetToVeh(res.net)
    if veh == 0 then return end
    local plate = GetVehicleNumberPlateText(veh)
    if GetConvarInt('inventory:trimplate', 1) == 1 then plate = plate:gsub('^%s+', ''):gsub('%s+$', '') end
    VPO.UI.Close()
    if res.part == 'glovebox' then
        exports.ox_inventory:openInventory('glovebox', { id = 'glove' .. plate, netid = res.net })
    else
        exports.ox_inventory:openInventory('trunk', { id = 'trunk' .. plate, netid = res.net })
    end
end)
