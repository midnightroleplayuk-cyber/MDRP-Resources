-- Moves the NPCs at callout scenes this officer's game controls, and opens the person panel.
local C = Config.NPC
local L = VPO.L
local watching = {} -- [personId] = state

local function entityFrom(net)
    local deadline = GetGameTimer() + 4000
    while not NetworkDoesEntityExistWithNetworkId(net) and GetGameTimer() < deadline do Wait(50) end
    if not NetworkDoesEntityExistWithNetworkId(net) then return 0 end
    return NetworkGetEntityFromNetworkId(net)
end

local function control(ent)
    if ent == 0 then return false end
    local deadline = GetGameTimer() + 2000
    NetworkRequestControlOfEntity(ent)
    while not NetworkHasControlOfEntity(ent) and GetGameTimer() < deadline do Wait(50); NetworkRequestControlOfEntity(ent) end
    return NetworkHasControlOfEntity(ent)
end

local function loadDict(d)
    RequestAnimDict(d)
    local deadline = GetGameTimer() + 3000
    while not HasAnimDictLoaded(d) and GetGameTimer() < deadline do Wait(10) end
    return HasAnimDictLoaded(d)
end

local function officerNear(ped, range)
    local pc = GetEntityCoords(ped)
    for _, pid in ipairs(GetActivePlayers()) do
        if Player(GetPlayerServerId(pid)).state[VPO.StateDefs.duty.bag] and #(GetEntityCoords(GetPlayerPed(pid)) - pc) <= range then return true end
    end
    return false
end

local function surrender(id, ped)
    ClearPedTasksImmediately(ped)
    if loadDict('random@arrests@busted') then TaskPlayAnim(ped, 'random@arrests@busted', 'idle_a', 8.0, -8.0, -1, 1, 0.0, false, false, false) end
    watching[id] = 'surrendered'
    TriggerServerEvent('vinewood_police:server:enc:event', id, 'surrendered')
end

local function watchCatch(id, ped, hostile)
    CreateThread(function()
        local closeSince
        while watching[id] == (hostile and 'hostile' or 'flee') do
            Wait(200)
            if not DoesEntityExist(ped) then return end
            local caught = IsPedBeingStunned(ped, 0) or IsPedRagdoll(ped) or (hostile and GetEntityHealth(ped) < GetEntityMaxHealth(ped) * 0.6)
            if officerNear(ped, C.CatchDistance) then
                closeSince = closeSince or GetGameTimer()
                if GetGameTimer() - closeSince >= C.CatchSeconds * 1000 then caught = true end
            else closeSince = nil end
            if caught then Wait(1200); surrender(id, ped); return end
        end
    end)
end

RegisterNetEvent('vinewood_police:client:enc:control', function(m)
    if type(m) ~= 'table' then return end
    local ped = entityFrom(m.ped)
    if ped == 0 then return end
    control(ped)
    local me = PlayerPedId()
    local a = m.action
    if a ~= 'release' and a ~= 'handover' then
        SetEntityAsMissionEntity(ped, true, true)
        SetBlockingOfNonTemporaryEvents(ped, true)
        SetPedKeepTask(ped, true)
    end

    if a == 'idle' then
        ClearPedTasks(ped)
        TaskStartScenarioInPlace(ped, (m.scenario or 'WORLD_HUMAN_STAND_IMPATIENT'), 0, true)
    elseif a == 'sit' then
        ClearPedTasks(ped)
        TaskStartScenarioInPlace(ped, 'WORLD_HUMAN_PICNIC', 0, true)
    elseif a == 'injured' then
        ClearPedTasks(ped)
        if loadDict('combat@damage@writhe') then TaskPlayAnim(ped, 'combat@damage@writhe', 'writhe_loop', 8.0, -8.0, -1, 1, 0.0, false, false, false) end
    elseif a == 'argue' then
        local other = m.other and entityFrom(m.other) or 0
        if other ~= 0 then TaskTurnPedToFaceEntity(ped, other, 1500) end
        Wait(1500)
        if loadDict('oddjobs@assassinate@vice@hooker') then
            TaskPlayAnim(ped, 'oddjobs@assassinate@vice@hooker', 'argue_a', 8.0, -8.0, -1, 1, 0.0, false, false, false)
        else
            TaskStartScenarioInPlace(ped, 'WORLD_HUMAN_STAND_IMPATIENT', 0, true)
        end
    elseif a == 'fight' then
        local other = m.other and entityFrom(m.other) or 0
        RemoveAllPedWeapons(ped, true)
        SetPedFleeAttributes(ped, 0, false)
        if other ~= 0 then SetBlockingOfNonTemporaryEvents(ped, false); TaskCombatPed(ped, other, 0, 16) end
    elseif a == 'flee' then
        watching[m.person] = 'flee'
        SetPedFleeAttributes(ped, 0, false)
        ClearPedTasks(ped)
        TaskSmartFleePed(ped, me, 600.0, -1, false, false)
        watchCatch(m.person, ped, false)
    elseif a == 'armed' then
        -- Holding a weapon; aiming it at someone if told to
        local hash = GetHashKey(m.weapon or 'WEAPON_KNIFE')
        GiveWeaponToPed(ped, hash, 30, false, true)
        SetCurrentPedWeapon(ped, hash, true)
        local other = m.aimAt and entityFrom(m.aimAt) or 0
        if other ~= 0 then TaskAimGunAtEntity(ped, other, -1, false)
        else TaskStandStill(ped, -1) end
    elseif a == 'handsup' then
        ClearPedTasks(ped)
        TaskHandsUp(ped, -1, 0, -1, true)
    elseif a == 'surrender' then
        watching[m.person] = nil
        if GetSelectedPedWeapon(ped) ~= GetHashKey('WEAPON_UNARMED') then SetPedDropsWeapon(ped) end
        RemoveAllPedWeapons(ped, true)
        ClearPedTasksImmediately(ped)
        if loadDict('random@arrests@busted') then TaskPlayAnim(ped, 'random@arrests@busted', 'idle_a', 8.0, -8.0, -1, 1, 0.0, false, false, false) end
    elseif a == 'hostile' then
        watching[m.person] = 'hostile'
        if m.weapon then
            local hash = GetHashKey(m.weapon)
            GiveWeaponToPed(ped, hash, 30, false, true)
            SetCurrentPedWeapon(ped, hash, true)
        else
            RemoveAllPedWeapons(ped, true)
        end
        SetPedFleeAttributes(ped, 0, false)
        SetPedCombatAttributes(ped, 46, true)
        SetBlockingOfNonTemporaryEvents(ped, false)
        ClearPedTasks(ped)
        TaskCombatPed(ped, me, 0, 16)
        watchCatch(m.person, ped, true)
    elseif a == 'cuff' then
        watching[m.person] = nil
        ClearPedTasksImmediately(ped)
        if loadDict('mp_arresting') then TaskPlayAnim(ped, 'mp_arresting', 'idle', 8.0, -8.0, -1, 1, 0.0, false, false, false) end
        SetEnableHandcuffs(ped, true)
    elseif a == 'handover' then
        watching[m.person] = nil
        NetworkFadeOutEntity(ped, false, true)
        Wait(1500)
        if NetworkHasControlOfEntity(ped) then DeleteEntity(ped) end
    elseif a == 'release' then
        watching[m.person] = nil
        SetEnableHandcuffs(ped, false)
        ClearPedTasks(ped)
        SetBlockingOfNonTemporaryEvents(ped, false)
        SetPedKeepTask(ped, false)
        TaskWanderStandard(ped, 10.0, 10)
        Wait(3000)
        SetEntityAsNoLongerNeeded(ped)
    end
end)

-- Stolen vehicle: drive about until someone stops it
RegisterNetEvent('vinewood_police:client:enc:drive', function(m)
    if type(m) ~= 'table' then return end
    local veh, ped = entityFrom(m.veh), entityFrom(m.ped)
    if veh == 0 or ped == 0 then return end
    control(veh); control(ped)
    SetEntityAsMissionEntity(veh, true, true)
    SetEntityAsMissionEntity(ped, true, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    SetDriverAbility(ped, 0.8)
    TaskVehicleDriveWander(ped, veh, 18.0, 786603)
end)

-- Collision scene: damage the cars and put the hazards on
RegisterNetEvent('vinewood_police:client:enc:damage', function(nets)
    for i, net in ipairs(nets or {}) do
        if net then
            local veh = entityFrom(net)
            if veh ~= 0 and control(veh) then
                local front = i == 2 -- the car behind hit the one in front
                SetVehicleDamage(veh, 0.0, front and 2.0 or -2.0, 0.2, 700.0, 150.0, true)
                SetVehicleDamage(veh, 0.5, front and 1.8 or -1.8, 0.2, 500.0, 120.0, true)
                if front then SmashVehicleWindow(veh, 6) end
                SetVehicleEngineHealth(veh, front and 150.0 or 500.0)
                SetVehicleIndicatorLights(veh, 0, true)
                SetVehicleIndicatorLights(veh, 1, true)
                SetVehicleDoorsLocked(veh, 1)
            end
        end
    end
end)

---------------------------------------------------------------------------
-- Speak to someone at a scene
---------------------------------------------------------------------------
local function personFor(ped)
    if IsPedAPlayer(ped) or not NetworkGetEntityIsNetworked(ped) then return nil end
    local list = GlobalState.vpo_enc_peds or {}
    return list[tostring(NetworkGetNetworkIdFromEntity(ped))]
end

local options = {
    { name = 'vpo_enc_talk', label = 'Speak to them', icon = 'fas fa-comments', distance = 3.0,
      canInteract = function(e) return LocalPlayer.state[VPO.StateDefs.duty.bag] ~= nil and personFor(e) ~= nil end,
      onSelect = function(e)
          local id = personFor(e)
          CreateThread(function()
              local data = VPO.UI.Request('enc:open', { id = id })
              if data.error then return VPO.ClientNotify(data.error, 'error') end
              VPO.UI.open = true
              SetNuiFocus(true, true)
              SendNUIMessage({ type = 'task', task = 'person', data = data })
          end)
      end },
}

CreateThread(function()
    Wait(1600)
    VPO.Target.AddGlobalPed(options)
end)

---------------------------------------------------------------------------
-- Call list (built-in CAD when vinewood-dispatch isn't running; works alongside it too)
---------------------------------------------------------------------------
RegisterCommand(Config.Callouts.Command, function()
    if not LocalPlayer.state[VPO.StateDefs.duty.bag] then return VPO.ClientNotify(L('perm_off_duty'), 'error') end
    VPO.UI.OpenTask('calls', 'call:list', nil)
end, false)

VPO.UI.After('call:attach', function(res)
    if res.coords then SetNewWaypoint(res.coords.x, res.coords.y) end
end)

AddEventHandler('onResourceStop', function(res)
    if res == VPO.Resource then VPO.Target.RemoveGlobalPed(options) end
end)
