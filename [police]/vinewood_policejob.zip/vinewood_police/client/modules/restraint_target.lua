-- Target options on players and vehicles, plus the /cuff, /uncuff and /escort commands.
local Cfg = Config.Restraint
local L = VPO.L

local function onDuty() return LocalPlayer.state[VPO.StateDefs.duty.bag] ~= nil end
local function sidOf(entity)
    local pid = NetworkGetPlayerIndexFromPed(entity)
    return pid ~= -1 and GetPlayerServerId(pid) or nil
end
local function stateOf(sid, key) return sid and Player(sid).state[VPO.StateDefs[key].bag] or nil end
local function canAct() return onDuty() and not VPO.IsCuffed() and not IsPedInAnyVehicle(PlayerPedId(), false) end

local function send(action, data)
    CreateThread(function()
        local res = lib.callback.await('vinewood_police:cb:' .. action, false, data)
        if type(res) ~= 'table' then return VPO.ClientNotify(L('restraint_failed'), 'error') end
        if res.error then return VPO.ClientNotify(res.error, 'error') end
        if res.message then VPO.ClientNotify(res.message, 'inform') end
    end)
end

--- Used by the radial menu too.
VPO.RestraintSend = send

local playerOptions = {
    { name = 'vpo_cuff_rear', label = Cfg.Rear.Label, icon = 'fas fa-handcuffs', distance = Cfg.Distance,
      canInteract = function(e) return canAct() and not stateOf(sidOf(e), 'cuffed') end,
      onSelect = function(e) send('restraint:cuff', { target = sidOf(e), mode = 'rear' }) end },
    { name = 'vpo_cuff_front', label = Cfg.Front.Label, icon = 'fas fa-handcuffs', distance = Cfg.Distance,
      canInteract = function(e) return canAct() and not stateOf(sidOf(e), 'cuffed') end,
      onSelect = function(e) send('restraint:cuff', { target = sidOf(e), mode = 'front' }) end },
    { name = 'vpo_uncuff', label = 'Remove handcuffs', icon = 'fas fa-unlock', distance = Cfg.Distance,
      canInteract = function(e) return canAct() and stateOf(sidOf(e), 'cuffed') ~= nil end,
      onSelect = function(e) send('restraint:uncuff', { target = sidOf(e) }) end },
    { name = 'vpo_doublelock', label = 'Double-lock handcuffs', icon = 'fas fa-lock', distance = Cfg.Distance,
      canInteract = function(e) local c = stateOf(sidOf(e), 'cuffed'); return canAct() and c ~= nil and not c.doubleLocked end,
      onSelect = function(e) send('restraint:doubleLock', { target = sidOf(e) }) end },
    { name = 'vpo_checkcuffs', label = 'Check handcuffs', icon = 'fas fa-magnifying-glass', distance = Cfg.Distance,
      canInteract = function(e) return canAct() and stateOf(sidOf(e), 'cuffed') ~= nil end,
      onSelect = function(e) send('restraint:check', { target = sidOf(e) }) end },
    { name = 'vpo_escort', label = 'Escort', icon = 'fas fa-person-walking-arrow-right', distance = Cfg.Distance,
      canInteract = function(e)
          local sid = sidOf(e)
          return canAct() and not VPO.IsEscorting() and not stateOf(sid, 'escort')
              and (not Cfg.EscortRequiresCuffs or stateOf(sid, 'cuffed') ~= nil)
      end,
      onSelect = function(e) send('restraint:escort', { target = sidOf(e) }) end },
    { name = 'vpo_release', label = 'Stop escorting', icon = 'fas fa-hand', distance = Cfg.Distance + 1.0,
      canInteract = function() return onDuty() and VPO.IsEscorting() ~= nil end,
      onSelect = function() send('restraint:release') end },
}

local function cuffedInside(veh)
    for seat = -1, GetVehicleMaxNumberOfPassengers(veh) - 1 do
        local p = GetPedInVehicleSeat(veh, seat)
        if p ~= 0 and IsPedAPlayer(p) and stateOf(sidOf(p), 'cuffed') then return true end
    end
    return false
end

local vehicleOptions = {
    { name = 'vpo_seat', label = 'Put in vehicle', icon = 'fas fa-car-side', distance = 3.0,
      canInteract = function() return onDuty() and VPO.IsEscorting() ~= nil end,
      onSelect = function(veh) send('restraint:seat', { net = VehToNet(veh) }) end },
    { name = 'vpo_unseat', label = 'Take out of vehicle', icon = 'fas fa-door-open', distance = 3.0,
      canInteract = function(veh) return canAct() and not VPO.IsEscorting() and cuffedInside(veh) end,
      onSelect = function(veh) send('restraint:unseat', { net = VehToNet(veh) }) end },
}

CreateThread(function()
    Wait(1000)
    VPO.Target.AddGlobalPlayer(playerOptions)
    VPO.Target.AddGlobalVehicle(vehicleOptions)
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= VPO.Resource then return end
    VPO.Target.RemoveGlobalPlayer(playerOptions)
    VPO.Target.RemoveGlobalVehicle(vehicleOptions)
end)

---------------------------------------------------------------------------
-- Commands on the closest person
---------------------------------------------------------------------------
local function closest()
    local pid = lib.getClosestPlayer(GetEntityCoords(PlayerPedId()), Cfg.Distance, false)
    return pid and GetPlayerServerId(pid) or nil
end

local C = Cfg.Commands or {}
if C.cuff then
    RegisterCommand(C.cuff, function(_, args)
        local sid = closest()
        if not sid then return VPO.ClientNotify(L('restraint_no_target'), 'error') end
        send('restraint:cuff', { target = sid, mode = args[1] == 'front' and 'front' or 'rear' })
    end, false)
end
if C.uncuff then
    RegisterCommand(C.uncuff, function()
        local sid = closest()
        if not sid then return VPO.ClientNotify(L('restraint_no_target'), 'error') end
        send('restraint:uncuff', { target = sid })
    end, false)
end
if C.escort then
    RegisterCommand(C.escort, function()
        if VPO.IsEscorting() then return send('restraint:release') end
        local sid = closest()
        if not sid then return VPO.ClientNotify(L('restraint_no_target'), 'error') end
        send('restraint:escort', { target = sid })
    end, false)
end
