-- Scene kit on the client: placing props with a preview, picking them up, and slowing or stopping
-- NPC traffic around scenes (speed zones from GlobalState.vpo_scene_zones).
local Cfg = Config.Scene
local L = VPO.L
local propById = {}
for _, p in ipairs(Cfg.Props) do propById[p.id] = p end

RegisterCommand(Cfg.Command, function()
    if not LocalPlayer.state[VPO.StateDefs.duty.bag] then return VPO.ClientNotify(L('perm_off_duty'), 'error') end
    VPO.UI.OpenTask('scene', 'scene:info', nil)
end, false)

---------------------------------------------------------------------------
-- Placement
---------------------------------------------------------------------------
local placing = false
local placeRequested, stopRequested = false, false

-- Place and stop are key mappings (Enter and Backspace by default, rebindable in GTA settings). Reading
-- Enter as a game control missed the first press, so the key mapping catches it directly instead.
RegisterCommand('+vpo_scene_place', function() if placing then placeRequested = true end end, false)
RegisterCommand('-vpo_scene_place', function() end, false)
RegisterKeyMapping('+vpo_scene_place', 'Police: place scene kit', 'keyboard', 'RETURN')
RegisterCommand('+vpo_scene_stop', function() if placing then stopRequested = true end end, false)
RegisterCommand('-vpo_scene_stop', function() end, false)
RegisterKeyMapping('+vpo_scene_stop', 'Police: stop placing scene kit', 'keyboard', 'BACK')

local function inputTag(cmd) return ('~INPUT_%X~'):format((GetHashKey(cmd) & 0xFFFFFFFF) | 0x80000000) end
local PLACE_KEY, STOP_KEY = inputTag('+vpo_scene_place'), inputTag('+vpo_scene_stop')

local function loadModel(hash)
    RequestModel(hash)
    local deadline = GetGameTimer() + 5000
    while not HasModelLoaded(hash) and GetGameTimer() < deadline do Wait(10) end
    return HasModelLoaded(hash)
end

local function aimPoint()
    local cam = GetGameplayCamCoord()
    local rot = GetGameplayCamRot(2)
    local rx, rz = math.rad(rot.x), math.rad(rot.z)
    local dir = vector3(-math.sin(rz) * math.abs(math.cos(rx)), math.cos(rz) * math.abs(math.cos(rx)), math.sin(rx))
    local to = cam + dir * (Cfg.PlaceRange + 6.0)
    local ray = StartShapeTestLosProbe(cam.x, cam.y, cam.z, to.x, to.y, to.z, 1 + 16, PlayerPedId(), 7)
    local status, hit, coords
    repeat status, hit, coords = GetShapeTestResult(ray); Wait(0) until status ~= 1
    if hit == 1 then return coords end
    return nil
end

local function help(text)
    BeginTextCommandDisplayHelp('STRING')
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayHelp(0, false, false, -1)
end

local function place(id)
    local def = propById[id]
    if not def or placing then return end
    local hash = GetHashKey(def.model)
    if not loadModel(hash) then return VPO.ClientNotify(L('scene_failed'), 'error') end
    placing = true
    local ghost = CreateObject(hash, 0.0, 0.0, 0.0, false, false, false)
    SetEntityAlpha(ghost, 160, false)
    SetEntityCollision(ghost, false, false)
    FreezeEntityPosition(ghost, true)
    local heading = GetEntityHeading(PlayerPedId())
    placeRequested, stopRequested = false, false

    CreateThread(function()
        while placing do
            Wait(0)
            -- No attacking, punching or aiming while placing; Enter places, Q/E turn, Backspace stops
            for _, c in ipairs({ 24, 25, 37, 44, 38, 47, 58, 140, 141, 142, 143, 257, 263, 264, 191, 201, 215, 194, 177, 202 }) do
                DisableControlAction(0, c, true)
            end
            help(L('scene_help', def.label, PLACE_KEY, STOP_KEY))
            local pt = aimPoint()
            local me = GetEntityCoords(PlayerPedId())
            local ok = pt and #(pt - me) <= Cfg.PlaceRange
            if pt then
                SetEntityCoords(ghost, pt.x, pt.y, pt.z, false, false, false, false)
                PlaceObjectOnGroundProperly(ghost)
                SetEntityHeading(ghost, heading)
                SetEntityAlpha(ghost, ok and 170 or 70, false)
            end
            if IsDisabledControlPressed(0, 44) then heading = heading + 1.5 end     -- Q
            if IsDisabledControlPressed(0, 38) then heading = heading - 1.5 end     -- E
            if placeRequested then
                placeRequested = false
                if not ok then
                    VPO.ClientNotify(L('scene_too_far'), 'error')
                else
                    local c = GetEntityCoords(ghost)
                    local res = lib.callback.await('vinewood_police:cb:scene:place', false, { id = id, x = c.x, y = c.y, z = c.z, h = heading })
                    if type(res) ~= 'table' or res.error then VPO.ClientNotify(res and res.error or L('scene_failed'), 'error')
                    elseif res.traffic then VPO.ClientNotify(L(res.traffic == 'closed' and 'scene_traffic_closed' or 'scene_traffic_slow'), 'inform') end
                end
            end
            if stopRequested then placing = false end
        end
        DeleteEntity(ghost)
        SetModelAsNoLongerNeeded(hash)
    end)
end

---------------------------------------------------------------------------
-- Evidence markers: placed one after another, numbered by the server (lowest free number at the scene)
---------------------------------------------------------------------------
local EM = Cfg.EvidenceMarkers

local function markerHash(n) return GetHashKey(EM.Model:format(n)) end

function VPO.PlaceMarkers()
    if placing then return end
    local first = lib.callback.await('vinewood_police:cb:scene:markerNext', false)
    local n = type(first) == 'table' and first.number or nil
    if not n then return VPO.ClientNotify(L('marker_all_used', EM.Count), 'error') end
    placing = true
    placeRequested, stopRequested = false, false
    local heading = GetEntityHeading(PlayerPedId())
    local ghost, ghostN

    local function setGhost(num)
        if ghost and DoesEntityExist(ghost) then DeleteEntity(ghost) end
        ghost, ghostN = nil, num
        if not num then return end
        local hash = markerHash(num)
        if not loadModel(hash) then return end
        ghost = CreateObject(hash, 0.0, 0.0, 0.0, false, false, false)
        SetEntityCollision(ghost, false, false)
        FreezeEntityPosition(ghost, true)
        SetModelAsNoLongerNeeded(hash)
    end
    setGhost(n)

    CreateThread(function()
        while placing do
            Wait(0)
            for _, c in ipairs({ 24, 25, 37, 44, 38, 47, 58, 140, 141, 142, 143, 257, 263, 264, 191, 201, 215, 194, 177, 202 }) do
                DisableControlAction(0, c, true)
            end
            help(L('marker_help', ghostN and tostring(ghostN) or '-', PLACE_KEY, STOP_KEY))
            local pt = aimPoint()
            local me = GetEntityCoords(PlayerPedId())
            local ok = pt and #(pt - me) <= Cfg.PlaceRange and ghost ~= nil
            if pt and ghost then
                SetEntityCoords(ghost, pt.x, pt.y, pt.z, false, false, false, false)
                PlaceObjectOnGroundProperly(ghost)
                SetEntityHeading(ghost, heading)
                SetEntityAlpha(ghost, ok and 170 or 70, false)
            end
            if IsDisabledControlPressed(0, 44) then heading = heading + 1.5 end
            if IsDisabledControlPressed(0, 38) then heading = heading - 1.5 end
            if placeRequested then
                placeRequested = false
                if not ok then
                    VPO.ClientNotify(L('scene_too_far'), 'error')
                else
                    local c = GetEntityCoords(ghost)
                    local res = lib.callback.await('vinewood_police:cb:scene:marker', false, { x = c.x, y = c.y, z = c.z, h = heading })
                    if type(res) ~= 'table' or res.error then
                        VPO.ClientNotify(res and res.error or L('scene_failed'), 'error')
                    else
                        VPO.ClientNotify(L('marker_placed', res.number), 'success', 2500)
                        if not res.nextNumber then placing = false else setGhost(res.nextNumber) end
                    end
                end
            end
            if stopRequested then placing = false end
        end
        setGhost(nil)
    end)
end

RegisterNUICallback('sceneMarkers', function(_, cb)
    VPO.UI.Close()
    cb({})
    SetTimeout(100, function() CreateThread(VPO.PlaceMarkers) end)
end)

RegisterNUICallback('scenePick', function(body, cb)
    VPO.UI.Close()
    cb({})
    if type(body) == 'table' then SetTimeout(100, function() place(body.id) end) end
end)

---------------------------------------------------------------------------
-- Picking props up
---------------------------------------------------------------------------
local objectOptions = {
    { name = 'vpo_scene_pickup', label = 'Pick up', icon = 'fas fa-hand', distance = 2.5,
      -- (evidence markers show their number in the log when picked up)
      canInteract = function(e)
          return LocalPlayer.state[VPO.StateDefs.duty.bag] ~= nil and NetworkGetEntityIsNetworked(e) and Entity(e).state.vpo_scene ~= nil
      end,
      onSelect = function(e)
          local net = ObjToNet(e)
          CreateThread(function()
              local res = lib.callback.await('vinewood_police:cb:scene:pickup', false, { net = net })
              if type(res) ~= 'table' or res.error then VPO.ClientNotify(res and res.error or L('scene_failed'), 'error') end
          end)
      end },
}

CreateThread(function()
    Wait(1500)
    VPO.Target.AddGlobalObject(objectOptions)
end)

---------------------------------------------------------------------------
-- Traffic zones (applied on every client so NPC traffic it drives behaves)
---------------------------------------------------------------------------
local zones = {} -- [owner] = { id, key }

local function sync(list)
    list = list or {}
    for owner, z in pairs(zones) do
        local want = list[owner]
        local key = want and ('%.1f:%.1f:%.1f:%.1f:%.1f'):format(want.x, want.y, want.z, want.r, want.speed) or nil
        if key ~= z.key then RemoveRoadNodeSpeedZone(z.id); zones[owner] = nil end
    end
    for owner, want in pairs(list) do
        if not zones[owner] then
            local key = ('%.1f:%.1f:%.1f:%.1f:%.1f'):format(want.x, want.y, want.z, want.r, want.speed)
            zones[owner] = { id = AddRoadNodeSpeedZone(want.x, want.y, want.z, want.r, want.speed, false), key = key }
        end
    end
end

AddStateBagChangeHandler('vpo_scene_zones', 'global', function(_, _, value) sync(value) end)
CreateThread(function() Wait(2000); sync(GlobalState.vpo_scene_zones) end)

AddEventHandler('onResourceStop', function(res)
    if res ~= VPO.Resource then return end
    placing = false
    for _, z in pairs(zones) do RemoveRoadNodeSpeedZone(z.id) end
    VPO.Target.RemoveGlobalObject(objectOptions)
end)
