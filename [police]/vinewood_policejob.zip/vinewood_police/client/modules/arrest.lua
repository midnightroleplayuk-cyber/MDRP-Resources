-- Arrest, person search and stop and search: target options, the consent prompt and notices.
local L = VPO.L

local function onDuty() return LocalPlayer.state[VPO.StateDefs.duty.bag] ~= nil end
local function sidOf(entity)
    local pid = NetworkGetPlayerIndexFromPed(entity)
    return pid ~= -1 and GetPlayerServerId(pid) or nil
end
local function stateOf(sid, key) return sid and Player(sid).state[VPO.StateDefs[key].bag] or nil end
local function canAct() return onDuty() and not VPO.IsCuffed() and not IsPedInAnyVehicle(PlayerPedId(), false) end

local options = {
    { name = 'vpo_search', label = 'Search', icon = 'fas fa-magnifying-glass', distance = Config.Search.Distance,
      canInteract = function() return canAct() end,
      onSelect = function(e)
          local sid = sidOf(e)
          local needsConsent = not stateOf(sid, 'cuffed') and not stateOf(sid, 'custody')
          VPO.UI.OpenTask('search', 'search:open', sid, needsConsent and L('search_asking') or nil)
      end },
    { name = 'vpo_arrest', label = 'Arrest', icon = 'fas fa-gavel', distance = Config.Restraint.Distance + 0.5,
      canInteract = function(e)
          local sid = sidOf(e)
          return canAct() and not stateOf(sid, 'custody') and (not Config.Arrest.RequireCuffs or stateOf(sid, 'cuffed') ~= nil)
      end,
      onSelect = function(e) VPO.UI.OpenTask('arrest', 'arrest:prepare', sidOf(e)) end },
    { name = 'vpo_dearrest', label = 'Release from arrest', icon = 'fas fa-person-walking', distance = 3.0,
      canInteract = function(e) return canAct() and stateOf(sidOf(e), 'custody') ~= nil end,
      onSelect = function(e) VPO.UI.OpenTask('release', 'arrest:releasePrepare', sidOf(e)) end },
    { name = 'vpo_stopsearch', label = 'Stop and search record', icon = 'fas fa-file-pen', distance = 4.0,
      canInteract = function() return canAct() end,
      onSelect = function(e) VPO.UI.OpenTask('stopsearch', 'stopsearch:prepare', sidOf(e)) end },
}

CreateThread(function()
    Wait(1200)
    VPO.Target.AddGlobalPlayer(options)
end)

AddEventHandler('onResourceStop', function(res)
    if res == VPO.Resource then VPO.Target.RemoveGlobalPlayer(options) end
end)

-- Stop and search record for nobody in particular (they gave no name and left): /stopsearch
RegisterCommand('stopsearch', function()
    if not onDuty() then return VPO.ClientNotify(L('perm_off_duty'), 'error') end
    VPO.UI.OpenTask('stopsearch', 'stopsearch:prepare', nil)
end, false)

-- Opening someone's inventory: close the panel so the inventory can take focus.
VPO.UI.After('search:openInventory', function() VPO.UI.Close() end)

---------------------------------------------------------------------------
-- Prompts the server asks this player to answer (search consent, breath tests...)
---------------------------------------------------------------------------
local pending

lib.callback.register('vinewood_police:client:choice', function(data)
    if pending or type(data) ~= 'table' then return nil end
    local p = promise.new()
    pending = p
    SetNuiFocus(true, true)
    SendNUIMessage({ type = 'prompt', title = data.title, text = data.text, options = data.options, timeout = data.timeout or 20 })
    SetTimeout((data.timeout or 20) * 1000, function()
        if pending == p then
            pending = nil
            p:resolve(nil)
            SendNUIMessage({ type = 'promptClose' })
            if not VPO.UI.open then SetNuiFocus(false, false) end
        end
    end)
    return Citizen.Await(p)
end)

RegisterNUICallback('prompt', function(body, cb)
    if pending then
        local p = pending
        pending = nil
        p:resolve(type(body) == 'table' and body.choice or nil)
    end
    if not VPO.UI.open then SetNuiFocus(false, false) end
    cb({})
end)

-- Caution, arrest and stop and search notices shown to the person (no focus taken).
RegisterNetEvent('vinewood_police:client:notice', function(n)
    if type(n) ~= 'table' then return end
    SendNUIMessage({ type = 'notice', title = n.title, text = n.text, from = n.from })
end)
