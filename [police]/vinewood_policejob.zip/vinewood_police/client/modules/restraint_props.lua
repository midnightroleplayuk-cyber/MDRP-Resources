-- Handcuff props. Every client draws the cuffs on every cuffed player near it, locally, from the
-- replicated vpo_cuffed statebag. No networked props: nothing to orphan if someone crashes.
local Cfg = Config.Restraint
local props = {} -- [serverId] = { obj, mode, ped }

local function loadModel(name)
    local hash = type(name) == 'number' and name or GetHashKey(name)
    if not IsModelInCdimage(hash) then return nil end
    if HasModelLoaded(hash) then return hash end
    RequestModel(hash)
    local deadline = GetGameTimer() + 5000
    while not HasModelLoaded(hash) and GetGameTimer() < deadline do Wait(10) end
    return HasModelLoaded(hash) and hash or nil
end

local function remove(sid)
    local p = props[sid]
    if p and DoesEntityExist(p.obj) then DeleteEntity(p.obj) end
    props[sid] = nil
end

local function create(sid, ped, mode)
    local cfg = (mode == 'front' and Cfg.Front or Cfg.Rear).Prop
    if not cfg then return end
    local hash = loadModel(cfg.model) or (cfg.fallback and loadModel(cfg.fallback))
    if not hash then return end
    local c = GetEntityCoords(ped)
    local obj = CreateObject(hash, c.x, c.y, c.z, false, false, false)
    SetEntityCollision(obj, false, false)
    local f = cfg.flags or { true, true, false, true, 1, true }
    AttachEntityToEntity(obj, ped, GetPedBoneIndex(ped, cfg.bone), cfg.offset.x, cfg.offset.y, cfg.offset.z,
        cfg.rot.x, cfg.rot.y, cfg.rot.z, f[1], f[2], f[3], f[4], f[5], f[6])
    SetModelAsNoLongerNeeded(hash)
    props[sid] = { obj = obj, mode = mode, ped = ped }
end

CreateThread(function()
    while true do
        local seen = {}
        for _, pid in ipairs(GetActivePlayers()) do
            local sid = GetPlayerServerId(pid)
            local ped = GetPlayerPed(pid)
            local c = Player(sid).state[VPO.StateDefs.cuffed.bag]
            seen[sid] = true
            local p = props[sid]
            if c and DoesEntityExist(ped) then
                if not p or p.mode ~= c.mode or p.ped ~= ped or not DoesEntityExist(p.obj) or not IsEntityAttachedToEntity(p.obj, ped) then
                    remove(sid)
                    create(sid, ped, c.mode)
                end
            elseif p then
                remove(sid)
            end
        end
        -- Arrested NPCs (vehicle stops): rear cuffs
        for net in pairs(GlobalState.vpo_npc_cuffed or {}) do
            local key = 'npc:' .. net
            net = tonumber(net)
            seen[key] = true
            if net and NetworkDoesEntityExistWithNetworkId(net) then
                local ped = NetworkGetEntityFromNetworkId(net)
                local p = props[key]
                if DoesEntityExist(ped) and (not p or p.ped ~= ped or not DoesEntityExist(p.obj)) then
                    remove(key)
                    create(key, ped, 'rear')
                end
            elseif props[key] then
                remove(key)
            end
        end
        for sid in pairs(props) do if not seen[sid] then remove(sid) end end
        Wait(750)
    end
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= VPO.Resource then return end
    for sid in pairs(props) do remove(sid) end
end)
