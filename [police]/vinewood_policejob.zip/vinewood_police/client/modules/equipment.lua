-- Locker, armoury and changing room points, and uniforms. Uniforms are set straight on the ped, so they
-- work with any clothing script. They can be made in game (vpo locations, Uniforms).
local function outfitFind(id)
    for _, u in ipairs(Config.Uniforms.Outfits or {}) do if u.id == id then return u end end
    return nil
end

local saved -- the officer's own clothes, taken before the first uniform goes on

local function snapshot(ped)
    local s = { components = {}, props = {} }
    for c = 0, 11 do
        s.components[c] = { GetPedDrawableVariation(ped, c), GetPedTextureVariation(ped, c), GetPedPaletteVariation(ped, c) }
    end
    for p = 0, 7 do
        s.props[p] = { GetPedPropIndex(ped, p), GetPedPropTextureIndex(ped, p) }
    end
    return s
end

-- Pieces come as a list ({ id, d, t }) from the editor, or { [component] = { drawable, texture } } from the config.
local function each(list, fn)
    for k, v in pairs(list or {}) do
        if type(v) == 'table' then
            if v.id ~= nil then fn(tonumber(v.id), tonumber(v.d) or 0, tonumber(v.t) or 0, tonumber(v.p) or 0)
            else fn(tonumber(k), tonumber(v[1]) or 0, tonumber(v[2]) or 0, tonumber(v[3]) or 0) end
        end
    end
end

local function applyClothes(ped, set, clearProps)
    each(set.components, function(c, d, t, pal) SetPedComponentVariation(ped, c, d, t, pal) end)
    if clearProps then for p = 0, 7 do ClearPedProp(ped, p) end end
    each(set.props, function(p, d, t) if d == -1 then ClearPedProp(ped, p) else SetPedPropIndex(ped, p, d, t, true) end end)
end

--- What this ped is wearing, in the editor's shape.
function VPO.CurrentClothes()
    local ped = PlayerPedId()
    local out = { components = {}, props = {}, female = GetEntityModel(ped) == GetHashKey('mp_f_freemode_01') }
    for c = 1, 11 do
        if c ~= 2 then -- 0 face and 2 hair belong to the character
            out.components[#out.components + 1] = { id = c, d = GetPedDrawableVariation(ped, c), t = GetPedTextureVariation(ped, c) }
        end
    end
    for p = 0, 7 do
        local d = GetPedPropIndex(ped, p)
        if d ~= -1 then out.props[#out.props + 1] = { id = p, d = d, t = GetPedPropTextureIndex(ped, p) } end
    end
    return out
end

--- Try a set on (editor preview); 'own' puts your clothes back.
function VPO.TryClothes(set)
    local ped = PlayerPedId()
    if not saved then saved = snapshot(ped) end
    applyClothes(ped, set, true)
end

local function isFemale(ped) return GetEntityModel(ped) == GetHashKey("mp_f_freemode_01") end

function VPO.WearUniform(id)
    local ped = PlayerPedId()
    if id == 'own' then
        if saved then applyClothes(ped, saved, true); saved = nil end
        return
    end
    local u = outfitFind(id)
    if not u then return end
    local set = isFemale(ped) and u.female or u.male
    if not set then return end
    if not saved then saved = snapshot(ped) end
    applyClothes(ped, set, true)
end

VPO.UI.After('equipment:uniform', function(res) VPO.WearUniform(res.id) end)

AddEventHandler('vinewood_police:client:dutyChanged', function(on)
    if not on and Config.Uniforms.RestoreOnSignOff and saved then VPO.WearUniform('own') end
end)

VPO.Zones.Register('lockers', function()
    local out = {}
    for _, st in ipairs(Config.Stations or {}) do
        for i, l in ipairs(st.lockers or {}) do
            out[#out + 1] = { name = ('vpo_locker_%s_%d'):format(st.id, i), box = l, options = {
                { name = 'vpo_locker', label = 'Equipment locker', icon = 'fas fa-box-archive', distance = 2.0,
                  onSelect = function() VPO.UI.Open('locker') end },
            } }
        end
    end
    return out
end)

VPO.Zones.Register('armouries', function()
    local out = {}
    for _, st in ipairs(Config.Stations or {}) do
        for i, a in ipairs(st.armouries or {}) do
            out[#out + 1] = { name = ('vpo_armoury_%s_%d'):format(st.id, i), box = a, options = {
                { name = 'vpo_armoury', label = 'Armoury', icon = 'fas fa-shield-halved', distance = 2.0,
                  canInteract = function() return LocalPlayer.state[VPO.StateDefs.duty.bag] ~= nil end,
                  onSelect = function() VPO.UI.OpenTask('armoury', 'armoury:view', nil) end },
            } }
        end
    end
    return out
end)

VPO.Zones.Register('changing', function()
    local out = {}
    for _, st in ipairs(Config.Stations or {}) do
        for i, a in ipairs(st.changingRooms or {}) do
            out[#out + 1] = { name = ('vpo_changing_%s_%d'):format(st.id, i), box = a, options = {
                { name = 'vpo_changing', label = 'Changing room', icon = 'fas fa-shirt', distance = 2.5,
                  canInteract = function() return LocalPlayer.state[VPO.StateDefs.duty.bag] ~= nil end,
                  onSelect = function() VPO.UI.OpenTask('changing', 'equipment:changing', nil) end },
            } }
        end
    end
    return out
end)
