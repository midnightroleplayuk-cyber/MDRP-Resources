-- Custody on the detainee's side (kept in their cell) and the officer's (desk and panel).
local Cfg = Config.Custody
local L = VPO.L

---------------------------------------------------------------------------
-- Officer: panel from the desk or /custody while in a suite
---------------------------------------------------------------------------
local function openPanel() VPO.UI.OpenTask('custody', 'custody:panel', nil) end

-- By default the custody computer is only at the desk; set Config.Custody.Command to also allow a command
if Cfg.Command then
    RegisterCommand(Cfg.Command, function()
        if not LocalPlayer.state[VPO.StateDefs.duty.bag] then return VPO.ClientNotify(L('perm_off_duty'), 'error') end
        openPanel()
    end, false)
end

VPO.Zones.Register('custody', function()
    local out = {}
    for _, s in ipairs(Cfg.Suites or {}) do
        out[#out + 1] = { name = ('vpo_custody_%s'):format(s.id), box = s.desk, options = {
            { name = 'vpo_custody_desk', label = 'Custody desk', icon = 'fas fa-clipboard-list', distance = 2.5,
              canInteract = function() return LocalPlayer.state[VPO.StateDefs.duty.bag] ~= nil end,
              onSelect = openPanel },
        } }
    end
    return out
end)

---------------------------------------------------------------------------
-- Detainee: moved by the server, and kept in the cell
---------------------------------------------------------------------------
local function moveTo(c)
    local ped = PlayerPedId()
    DoScreenFadeOut(400)
    Wait(450)
    if IsPedInAnyVehicle(ped, false) then TaskLeaveVehicle(ped, GetVehiclePedIsIn(ped, false), 16) Wait(300) end
    SetEntityCoords(ped, c.x, c.y, c.z, false, false, false, false)
    SetEntityHeading(ped, c.w or 0.0)
    Wait(300)
    DoScreenFadeIn(500)
end

RegisterNetEvent('vinewood_police:client:custody:teleport', function(c)
    if type(c) == 'table' then moveTo(c) end
end)

local function myCell()
    local c = LocalPlayer.state[VPO.StateDefs.custody.bag]
    if not c or not c.cell or c.out then return nil end
    for _, s in ipairs(Cfg.Suites) do
        if s.id == c.cell.suite then
            for _, cell in ipairs(s.cells) do if cell.id == c.cell.id then return cell end end
        end
    end
    return nil
end

CreateThread(function()
    while true do
        local cell = myCell()
        if not cell then
            Wait(1500)
        else
            Wait(500)
            local ped = PlayerPedId()
            local here = GetEntityCoords(ped)
            if #(here - vector3(cell.coords.x, cell.coords.y, cell.coords.z)) > Cfg.CellRadius and not IsEntityDead(ped) then
                moveTo(cell.coords)
            end
        end
    end
end)

-- Opening a property bag: close the panel so the stash can take focus.
VPO.UI.After('custody:openProperty', function() VPO.UI.Close() end)

---------------------------------------------------------------------------
-- Evidence store
---------------------------------------------------------------------------
RegisterCommand(Config.Evidence.Command, function()
    if not LocalPlayer.state[VPO.StateDefs.duty.bag] then return VPO.ClientNotify(L('perm_off_duty'), 'error') end
    VPO.UI.OpenTask('evidence', 'evidence:list', nil)
end, false)

VPO.UI.After('evidence:open', function() VPO.UI.Close() end)
