-- Major incidents on the map (radius blips for on-duty officers) and cordon rings near the scene.
-- /incident opens the incident panel, /cases the CID case files.
local blips = {} -- [id] = { inner, outer, centre }

local function clearBlips()
    for _, b in pairs(blips) do
        for _, h in pairs(b) do if DoesBlipExist(h) then RemoveBlip(h) end end
    end
    blips = {}
end

local function onDuty() return LocalPlayer.state[VPO.StateDefs.duty.bag] ~= nil end

local function drawBlips()
    clearBlips()
    if not onDuty() then return end
    for id, i in pairs(GlobalState.vpo_incidents or {}) do
        local outer = AddBlipForRadius(i.x, i.y, i.z, i.outer + 0.0)
        SetBlipColour(outer, 47); SetBlipAlpha(outer, 70)
        local inner = AddBlipForRadius(i.x, i.y, i.z, i.inner + 0.0)
        SetBlipColour(inner, 1); SetBlipAlpha(inner, 110)
        local centre = AddBlipForCoord(i.x, i.y, i.z)
        SetBlipSprite(centre, 526); SetBlipColour(centre, 1); SetBlipScale(centre, 0.8)
        BeginTextCommandSetBlipName('STRING'); AddTextComponentSubstringPlayerName(('%s: %s'):format(i.ref or 'Incident', i.label)); EndTextCommandSetBlipName(centre)
        blips[id] = { outer = outer, inner = inner, centre = centre }
    end
end

AddStateBagChangeHandler('vpo_incidents', 'global', function() SetTimeout(0, drawBlips) end)
AddEventHandler('vinewood_police:client:dutyChanged', function() SetTimeout(0, drawBlips) end)
CreateThread(function() Wait(2000); drawBlips() end)

-- Cordon rings on the ground when you're near
CreateThread(function()
    while true do
        local list = GlobalState.vpo_incidents or {}
        local me = GetEntityCoords(PlayerPedId())
        local near = false
        for _, i in pairs(list) do
            local c = vector3(i.x, i.y, i.z)
            if #(me - c) < i.outer + 60.0 then
                near = true
                DrawMarker(1, i.x, i.y, i.z - 1.2, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, i.inner * 2.0, i.inner * 2.0, 0.6, 217, 83, 79, 60, false, false, 2, false, nil, nil, false)
                DrawMarker(1, i.x, i.y, i.z - 1.2, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, i.outer * 2.0, i.outer * 2.0, 0.4, 233, 211, 28, 35, false, false, 2, false, nil, nil, false)
            end
        end
        Wait(near and 0 or 1000)
    end
end)

RegisterCommand(Config.Incidents.Command, function()
    if not onDuty() then return VPO.ClientNotify(VPO.L('perm_off_duty'), 'error') end
    VPO.UI.OpenTask('incident', 'incident:panel', nil)
end, false)

RegisterCommand(Config.CID.Command, function()
    if not onDuty() then return VPO.ClientNotify(VPO.L('perm_off_duty'), 'error') end
    VPO.UI.OpenTask('cases', 'cid:list', nil)
end, false)

AddEventHandler('onResourceStop', function(res) if res == VPO.Resource then clearBlips() end end)
