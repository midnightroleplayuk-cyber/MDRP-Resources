-- Police tape, drawn from the texture in web/textures/policeline.png: a ribbon strung between points,
-- with a little sag and a flutter. Every player draws every tape near them from GlobalState.vpo_tapes.
-- Putting it up (/scenekit, Police tape): aim at a lamp post, cone or fence (or the ground: it's tied at
-- waist height), E adds a point, Z undoes, Enter finishes, Backspace cancels.
local T = Config.Scene.Tape
local L = VPO.L
local TXD, TEX = 'vpo_tape', 'policeline'

CreateThread(function()
    local txd = CreateRuntimeTxd(TXD)
    CreateRuntimeTextureFromImage(txd, TEX, T.Texture)
end)

local half = T.Width / 2
local tile = T.Width * 2 -- the image is twice as wide as it is tall

-- One straight span from a to b, tiled with the texture, sagging and fluttering. alpha for previews.
local function span(a, b, alpha, phase)
    local d = b - a
    local len = #d
    if len < 0.05 then return end
    local sag = T.Sag * (len / 10.0)
    local n = math.ceil(len / tile)
    local time = GetGameTimer() / 1000.0
    local function at(t)
        local p = a + d * t
        local wobble = T.Flutter * math.sin(time * 3.1 + t * len * 1.7 + phase) * math.sin(math.pi * t)
        return vector3(p.x, p.y, p.z - sag * 4.0 * t * (1.0 - t) + wobble)
    end
    local prev = at(0.0)
    for i = 1, n do
        local t1 = math.min(i * tile / len, 1.0)
        local cur = at(t1)
        local u1 = (t1 * len - (i - 1) * tile) / tile -- the last tile can be a part tile
        local at_, ab_ = vector3(prev.x, prev.y, prev.z + half), vector3(prev.x, prev.y, prev.z - half)
        local bt_, bb_ = vector3(cur.x, cur.y, cur.z + half), vector3(cur.x, cur.y, cur.z - half)
        -- front
        DrawSpritePoly(at_.x, at_.y, at_.z, bt_.x, bt_.y, bt_.z, bb_.x, bb_.y, bb_.z, 255, 255, 255, alpha, TXD, TEX, 0.0, 0.0, 1.0, u1, 0.0, 1.0, u1, 1.0, 1.0)
        DrawSpritePoly(at_.x, at_.y, at_.z, bb_.x, bb_.y, bb_.z, ab_.x, ab_.y, ab_.z, 255, 255, 255, alpha, TXD, TEX, 0.0, 0.0, 1.0, u1, 1.0, 1.0, 0.0, 1.0, 1.0)
        -- back
        DrawSpritePoly(bt_.x, bt_.y, bt_.z, at_.x, at_.y, at_.z, ab_.x, ab_.y, ab_.z, 255, 255, 255, alpha, TXD, TEX, u1, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 1.0, 1.0)
        DrawSpritePoly(bt_.x, bt_.y, bt_.z, ab_.x, ab_.y, ab_.z, bb_.x, bb_.y, bb_.z, 255, 255, 255, alpha, TXD, TEX, u1, 0.0, 1.0, 0.0, 1.0, 1.0, u1, 1.0, 1.0)
        prev = cur
    end
end

local function drawTape(points, alpha, seed)
    for i = 2, #points do span(points[i - 1], points[i], alpha or 255, (seed or 0) + i * 0.7) end
end

---------------------------------------------------------------------------
-- Every tape near you
---------------------------------------------------------------------------
local tapes = {} -- [id] = { points = { vector3 }, centre, radius }

local function load(all)
    tapes = {}
    for id, t in pairs(all or {}) do
        local pts, c = {}, vector3(0, 0, 0)
        for i, p in ipairs(t.points or {}) do pts[i] = vector3(p.x, p.y, p.z); c = c + pts[i] end
        if #pts >= 2 then
            c = c / #pts
            local r = 0.0
            for _, p in ipairs(pts) do r = math.max(r, #(p - c)) end
            tapes[id] = { points = pts, centre = c, radius = r, owner = t.owner, seed = (tonumber(id) or 1) * 1.3 }
        end
    end
end

AddStateBagChangeHandler('vpo_tapes', 'global', function(_, _, value) SetTimeout(0, function() load(value) end) end)
CreateThread(function() Wait(1500); load(GlobalState.vpo_tapes) end)

CreateThread(function()
    while true do
        local me = GetEntityCoords(PlayerPedId())
        local near = {}
        for _, t in pairs(tapes) do
            if #(me - t.centre) - t.radius < T.DrawDistance then near[#near + 1] = t end
        end
        if #near == 0 then
            Wait(750)
        else
            local untilCheck = GetGameTimer() + 500
            while GetGameTimer() < untilCheck do
                for _, t in ipairs(near) do drawTape(t.points, 255, t.seed) end
                Wait(0)
            end
        end
    end
end)

--- The tape nearest you (within 4 m of any part of it), for taking it down.
function VPO.NearestTape()
    local me = GetEntityCoords(PlayerPedId())
    local best, bestD
    for id, t in pairs(tapes) do
        for i = 2, #t.points do
            local a, b = t.points[i - 1], t.points[i]
            local ab = b - a
            local k = math.max(0.0, math.min(1.0, ((me - a).x * ab.x + (me - a).y * ab.y + (me - a).z * ab.z) / math.max(0.001, #ab ^ 2)))
            local d = #(me - (a + ab * k))
            if d < 4.0 and (not bestD or d < bestD) then best, bestD = id, d end
        end
    end
    return best
end

---------------------------------------------------------------------------
-- Putting it up
---------------------------------------------------------------------------
local placing = false

local function aimPoint()
    local cam, rot = GetGameplayCamCoord(), GetGameplayCamRot(2)
    local rx, rz = math.rad(rot.x), math.rad(rot.z)
    local dir = vector3(-math.sin(rz) * math.abs(math.cos(rx)), math.cos(rz) * math.abs(math.cos(rx)), math.sin(rx))
    local to = cam + dir * 30.0
    local ray = StartExpensiveSynchronousShapeTestLosProbe(cam.x, cam.y, cam.z, to.x, to.y, to.z, 1 | 16, PlayerPedId(), 7)
    local _, hit, pos, normal = GetShapeTestResult(ray)
    if hit ~= 1 then return nil end
    if normal.z > 0.7 then return vector3(pos.x, pos.y, pos.z + T.WaistHeight), true end -- ground: tie it at waist height
    return pos + normal * 0.04, false                                                       -- a post or wall: on its surface
end

local function released(c) return IsDisabledControlJustReleased(0, c) end

function VPO.PutUpTape()
    if placing then return end
    placing = true
    CreateThread(function()
        local points = {}
        while placing do
            Wait(0)
            for _, c in ipairs({ 24, 25, 37, 44, 38, 47, 58, 140, 141, 142, 20, 191, 201, 18, 177, 200 }) do DisableControlAction(0, c, true) end
            local p, ground = aimPoint()
            local me = GetEntityCoords(PlayerPedId())
            local last = points[#points]
            local ok = p and #(p - me) < 30.0 and (not last or #(p - last) <= T.MaxSpan)
            if #points > 0 then drawTape(points, 255, 0) end
            if last and p then span(last, p, ok and 170 or 60, 0) end
            for _, q in ipairs(points) do DrawMarker(28, q.x, q.y, q.z, 0, 0, 0, 0, 0, 0, 0.06, 0.06, 0.06, 47, 111, 224, 220, false, false, 2, false, nil, nil, false) end
            if p then DrawMarker(28, p.x, p.y, p.z, 0, 0, 0, 0, 0, 0, 0.07, 0.07, 0.07, ok and 233 or 217, ok and 211 or 83, ok and 28 or 79, 220, false, false, 2, false, nil, nil, false) end
            BeginTextCommandDisplayHelp('STRING')
            AddTextComponentSubstringPlayerName(('Police tape: %d point%s%s~n~~INPUT_PICKUP~ tie it here   ~INPUT_MULTIPLAYER_INFO~ undo~n~~INPUT_FRONTEND_ACCEPT~ finish   ~INPUT_FRONTEND_CANCEL~ cancel'):format(
                #points, #points == 1 and '' or 's',
                (last and p and not ok) and ('~n~~r~Too far: add a point in between (%d m max)~s~'):format(T.MaxSpan) or (ground and p and '~n~Tied at waist height' or '')))
            EndTextCommandDisplayHelp(0, false, false, -1)

            if released(38) and ok and #points < T.MaxPoints then
                points[#points + 1] = p
                PlaySoundFrontend(-1, 'SELECT', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
            elseif released(20) and #points > 0 then
                points[#points] = nil
            elseif released(191) or released(201) or released(18) then
                if #points >= 2 then
                    local send = {}
                    for i, q in ipairs(points) do send[i] = { x = q.x, y = q.y, z = q.z } end
                    local res = lib.callback.await('vinewood_police:cb:scene:tape', false, { points = send })
                    VPO.ClientNotify((type(res) == 'table' and res.error) or L('tape_up'), (type(res) == 'table' and res.error) and 'error' or 'success')
                    if type(res) == 'table' and res.ok then placing = false end
                end
            elseif released(177) or released(200) then
                placing = false
            end
        end
    end)
end

RegisterNUICallback('sceneTape', function(body, cb)
    cb({})
    VPO.UI.Close()
    if type(body) == 'table' and body.remove then
        CreateThread(function()
            local id = VPO.NearestTape()
            if not id then return VPO.ClientNotify(L('tape_none_near'), 'error') end
            local res = lib.callback.await('vinewood_police:cb:scene:tapeRemove', false, { id = id })
            VPO.ClientNotify((type(res) == 'table' and res.error) or L('tape_down'), (type(res) == 'table' and res.error) and 'error' or 'success')
        end)
    else
        SetTimeout(150, VPO.PutUpTape)
    end
end)
