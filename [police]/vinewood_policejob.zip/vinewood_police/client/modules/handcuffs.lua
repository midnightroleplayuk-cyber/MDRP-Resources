-- Quick keys (up: cuff, left: escort, down: uncuff) and the handcuffs item (cuffs out, in your hand).
local L = VPO.L
local KB = Config.Restraint.Keybinds or {}
local HC = Config.Restraint.HandcuffsItem or {}

local function onDuty() return LocalPlayer.state[VPO.StateDefs.duty.bag] ~= nil end
local function free()
    local ped = PlayerPedId()
    return onDuty() and not VPO.UI.open and not IsPedInAnyVehicle(ped, false) and not IsEntityDead(ped)
        and not (VPO.IsCuffed and VPO.IsCuffed())
end

local function closest()
    local pid = lib.getClosestPlayer(GetEntityCoords(PlayerPedId()), (Config.Radial and Config.Radial.CloseDistance) or 3.0, false)
    if not pid then VPO.ClientNotify(L('radial_nobody'), 'error') return nil end
    return GetPlayerServerId(pid)
end

---------------------------------------------------------------------------
-- Cuffs in hand
---------------------------------------------------------------------------
local prop = nil

local function putAway(silent)
    if prop and DoesEntityExist(prop) then DeleteEntity(prop) end
    prop = nil
    if not silent then VPO.ClientNotify(L('cuffs_put_away'), 'inform', 2500) end
end

local function cuff()
    local sid = closest()
    if not sid then return false end
    putAway(true)
    VPO.RestraintSend('restraint:cuff', { target = sid, mode = 'rear' })
    return true
end

local cuffTag = ('~INPUT_%X~'):format((GetHashKey('vpo_kb_cuff') & 0xFFFFFFFF) | 0x80000000)

local function takeOut()
    if prop then return putAway() end
    if not free() then return end
    local p = HC.Prop
    local hash = GetHashKey(p.model)
    RequestModel(hash)
    local deadline = GetGameTimer() + 3000
    while not HasModelLoaded(hash) and GetGameTimer() < deadline do Wait(10) end
    if not HasModelLoaded(hash) then return end
    local ped = PlayerPedId()
    local c = GetEntityCoords(ped)
    prop = CreateObject(hash, c.x, c.y, c.z, false, false, false)
    SetModelAsNoLongerNeeded(hash)
    SetEntityCollision(prop, false, false)
    AttachEntityToEntity(prop, ped, GetPedBoneIndex(ped, p.bone), p.offset.x, p.offset.y, p.offset.z, p.rot.x, p.rot.y, p.rot.z,
        true, true, false, true, 1, true)
    CreateThread(function()
        while prop do
            Wait(0)
            DisableControlAction(0, 24, true); DisableControlAction(0, 25, true); DisableControlAction(0, 140, true); DisableControlAction(0, 141, true); DisableControlAction(0, 142, true)
            DisableControlAction(0, 38, true); DisableControlAction(0, 177, true)
            BeginTextCommandDisplayHelp('STRING')
            AddTextComponentSubstringPlayerName(L('cuffs_out_help', cuffTag))
            EndTextCommandDisplayHelp(0, false, false, -1)
            if IsDisabledControlJustReleased(0, 38) and cuff() then break end
            if IsDisabledControlJustReleased(0, 177) or not free() then putAway() break end
        end
    end)
end

RegisterNetEvent('vinewood_police:client:cuffsOut', function() takeOut() end)
exports('cuffsOut', takeOut)

---------------------------------------------------------------------------
-- Quick keys (registered even when disabled, so a rebind isn't lost; they just do nothing)
---------------------------------------------------------------------------
RegisterCommand('vpo_kb_cuff', function()
    if not KB.Enabled or not free() then return end
    cuff()
end, false)
RegisterCommand('vpo_kb_escort', function()
    if not KB.Enabled or not free() then return end
    if VPO.IsEscorting() then return VPO.RestraintSend('restraint:release') end
    local sid = closest()
    if sid then VPO.RestraintSend('restraint:escort', { target = sid }) end
end, false)
RegisterCommand('vpo_kb_uncuff', function()
    if not KB.Enabled or not free() then return end
    local sid = closest()
    if sid then VPO.RestraintSend('restraint:uncuff', { target = sid }) end
end, false)
RegisterKeyMapping('vpo_kb_cuff', 'Police: handcuff the person in front', 'keyboard', KB.Cuff or 'UP')
RegisterKeyMapping('vpo_kb_escort', 'Police: escort / let go', 'keyboard', KB.Escort or 'LEFT')
RegisterKeyMapping('vpo_kb_uncuff', 'Police: remove handcuffs', 'keyboard', KB.Uncuff or 'DOWN')

AddEventHandler('onResourceStop', function(res) if res == VPO.Resource then putAway(true) end end)
