-- In-world editor tools, the vinewood_prison way: leave the menu, walk the custody suite and keep going
-- until you're done.
--   Place cells: stand where the detainee should be, facing the way they should face, [E] adds a cell.
--   Set doors:   walk up to a cell door (it lights up) or aim at it, [E] makes it the door of the nearest
--                cell without one ([Q] picks another cell, scroll picks another object).
-- [Z] undoes the last one, [Enter] saves and goes back to the editor, [Backspace] leaves without saving.
local L = VPO.L
local busy = false

local function blockControls()
    for _, c in ipairs({ 24, 25, 37, 44, 45, 47, 20, 38, 140, 141, 142, 199, 200, 191, 201, 18, 177, 14, 15, 16, 17, 241, 242 }) do
        DisableControlAction(0, c, true)
    end
end
local function released(c) return IsDisabledControlJustReleased(0, c) or IsControlJustReleased(0, c) end
local function confirm() return released(191) or released(201) or released(18) end
local function back() return released(177) or released(200) end

local function help(lines)
    BeginTextCommandDisplayHelp('STRING')
    AddTextComponentSubstringPlayerName(table.concat(lines, '~n~'))
    EndTextCommandDisplayHelp(0, false, false, -1)
end

local function text3d(pos, label)
    local on, x, y = World3dToScreen2d(pos.x, pos.y, pos.z)
    if not on then return end
    SetTextScale(0.32, 0.32); SetTextFont(4); SetTextCentre(true); SetTextOutline(); SetTextColour(255, 255, 255, 235)
    BeginTextCommandDisplayText('STRING'); AddTextComponentSubstringPlayerName(label); EndTextCommandDisplayText(x, y)
end

local function marker(c, r, g, b)
    DrawMarker(2, c.x, c.y, c.z + 0.3, 0.0, 0.0, 0.0, 0.0, 180.0, 0.0, 0.35, 0.35, 0.35, r, g, b, 200, false, true, 2, false, nil, nil, false)
end

local function suiteCopy(suiteId)
    local all = VPO.Loc.Plain(Config.Custody.Suites or {})
    for _, su in ipairs(all) do if su.id == suiteId then su.cells = su.cells or {}; return all, su end end
    return all, nil
end

local function finish(all, saveIt)
    local ok = true
    if saveIt then
        local res = lib.callback.await('vinewood_police:cb:loc:save', false, { key = 'custody', data = all })
        if type(res) ~= 'table' or res.error then
            ok = false
            VPO.ClientNotify((res and res.error) or L('scene_failed'), 'error')
        else
            VPO.ClientNotify(L('world_saved'), 'success')
        end
    end
    busy = false
    VPO.UI.OpenTask('locations', 'loc:get', 'custody')
    return ok
end

---------------------------------------------------------------------------
-- Place cells
---------------------------------------------------------------------------
local function placeCells(suiteId)
    local all, su = suiteCopy(suiteId)
    if not su then return VPO.ClientNotify(L('world_save_suite_first'), 'error') end
    busy = true
    local added = {}
    local function nextId()
        local n = #su.cells + 1
        local used = {}
        for _, c in ipairs(su.cells) do used[c.id] = true end
        while used['C' .. n] do n = n + 1 end
        return n
    end
    while true do
        Wait(0)
        blockControls()
        local ped = PlayerPedId()
        local me = GetEntityCoords(ped)
        for _, c in ipairs(su.cells) do
            local p = vector3(c.coords.x, c.coords.y, c.coords.z)
            if #(me - p) < 40.0 then marker(p, 233, 211, 28); text3d(p + vector3(0, 0, 0.9), c.label) end
        end
        help({ ('Placing cells: %s (%d added)'):format(su.label, #added),
            '~INPUT_PICKUP~ add a cell where you stand, facing the way you face',
            '~INPUT_MULTIPLAYER_INFO~ undo   ~INPUT_FRONTEND_ACCEPT~ save and finish   ~INPUT_FRONTEND_CANCEL~ leave without saving' })
        if released(38) then
            local n = nextId()
            local cell = { id = 'C' .. n, label = 'Cell ' .. n, coords = { x = me.x, y = me.y, z = me.z, w = GetEntityHeading(ped) } }
            su.cells[#su.cells + 1] = cell
            added[#added + 1] = cell
            PlaySoundFrontend(-1, 'SELECT', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
        elseif released(20) and #added > 0 then
            local last = table.remove(added)
            for i, c in ipairs(su.cells) do if c == last then table.remove(su.cells, i) break end end
            PlaySoundFrontend(-1, 'BACK', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
        elseif confirm() then
            return finish(all, #added > 0)
        elseif back() then
            return finish(all, false)
        end
    end
end

---------------------------------------------------------------------------
-- Set doors
---------------------------------------------------------------------------
-- Is this a real door GTA can lock? Register it briefly and ask whether its door physics loaded.
local realDoor, probing, probeBusy = {}, {}, false
local PROBE = GetHashKey('vinewood_police_probe')
local function probeDoor(ent)
    if realDoor[ent] ~= nil or probing[ent] then return realDoor[ent] end
    local c0 = GetEntityCoords(ent)
    if DoorSystemFindExistingDoor(c0.x, c0.y, c0.z, GetEntityModel(ent)) then realDoor[ent] = true return true end
    if probeBusy then return nil end
    probeBusy, probing[ent] = true, true
    CreateThread(function()
        local c = GetEntityCoords(ent)
        AddDoorToSystem(PROBE, GetEntityModel(ent), c.x, c.y, c.z, false, false, false)
        local result = false
        for _ = 1, 20 do
            Wait(50)
            if DoorSystemGetIsPhysicsLoaded(PROBE) then result = true break end
        end
        RemoveDoorFromSystem(PROBE)
        realDoor[ent], probing[ent], probeBusy = result, nil, false
    end)
    return nil
end

local shape = {}
local function doorShaped(ent)
    local model = GetEntityModel(ent)
    if shape[model] == nil then
        local mn, mx = GetModelDimensions(model)
        local sx, sy, sz = mx.x - mn.x, mx.y - mn.y, mx.z - mn.z
        shape[model] = sz > 1.5 and sz < 6.0 and math.min(sx, sy) < 0.8 and math.max(sx, sy) > 0.5 and math.max(sx, sy) < 10.0
    end
    return shape[model]
end

local function aimer()
    local probe, lastEnt
    return function()
        if probe then
            local status, hit, _, _, ent = GetShapeTestResult(probe)
            if status ~= 1 then lastEnt = (hit == 1 and ent ~= 0 and GetEntityType(ent) == 3) and ent or nil; probe = nil end
        end
        if not probe then
            local pos, rot = GetGameplayCamCoord(), GetGameplayCamRot(2)
            local rx, rz = math.rad(rot.x), math.rad(rot.z)
            local dir = vector3(-math.sin(rz) * math.abs(math.cos(rx)), math.cos(rz) * math.abs(math.cos(rx)), math.sin(rx))
            local dest = pos + dir * 30.0
            probe = StartShapeTestLosProbe(pos.x, pos.y, pos.z, dest.x, dest.y, dest.z, 1 | 16, PlayerPedId(), 4)
        end
        return lastEnt
    end
end

-- Objects you could mean, best first: the one you aim at, then door-shaped objects within 4 m
local function candidates(aimed)
    local ped = PlayerPedId()
    local pos, fwd = GetEntityCoords(ped), GetEntityForwardVector(ped)
    local list, seen = {}, {}
    if aimed and #(GetEntityCoords(aimed) - pos) < 15.0 then list[1] = aimed; seen[aimed] = true end
    local near = {}
    for _, obj in ipairs(GetGamePool('CObject')) do
        if not seen[obj] then
            local c = GetEntityCoords(obj)
            local d = #(c - pos)
            if d < 4.0 and doorShaped(obj) then
                local dir = (c - pos) / math.max(d, 0.01)
                near[#near + 1] = { obj = obj, score = d - (dir.x * fwd.x + dir.y * fwd.y) }
            end
        end
    end
    table.sort(near, function(a, b) return a.score < b.score end)
    for _, n in ipairs(near) do list[#list + 1] = n.obj end
    return list
end

local function setDoors(suiteId)
    local all, su = suiteCopy(suiteId)
    if not su then return VPO.ClientNotify(L('world_save_suite_first'), 'error') end
    if #su.cells == 0 then return VPO.ClientNotify(L('world_cells_first'), 'error') end
    busy = true
    SetEntityDrawOutlineColor(255, 221, 0, 255)
    SetEntityDrawOutlineShader(1)
    local aim = aimer()
    local undo, hovered, candIndex, cellPick, lastCands = {}, nil, 1, 1, {}
    local function outline(e, on) if e and DoesEntityExist(e) then SetEntityDrawOutline(e, on) end end

    local function doorOf(ent)
        local c = GetEntityCoords(ent)
        for _, cell in ipairs(su.cells) do
            if cell.door and #(vector3(cell.door.coords.x, cell.door.coords.y, cell.door.coords.z) - c) < 0.3 then return cell end
        end
    end

    -- Cells this door could belong to: nearest first, cells without a door before those with one
    local function cellsFor(ent)
        local c = GetEntityCoords(ent)
        local list = {}
        for _, cell in ipairs(su.cells) do
            local p = vector3(cell.coords.x, cell.coords.y, cell.coords.z)
            local flat = #(vector2(p.x, p.y) - vector2(c.x, c.y))
            if flat < 10.0 and math.abs(p.z - c.z) < 3.0 then list[#list + 1] = { cell = cell, d = flat + (cell.door and 100 or 0) } end
        end
        table.sort(list, function(a, b) return a.d < b.d end)
        return list
    end

    while true do
        Wait(0)
        blockControls()
        local me = GetEntityCoords(PlayerPedId())
        local cands = candidates(aim())
        if #cands ~= #lastCands or cands[1] ~= lastCands[1] then candIndex = 1 end
        lastCands = cands
        if released(241) or released(15) then candIndex = candIndex % math.max(#cands, 1) + 1 end
        if released(242) or released(14) then candIndex = (candIndex - 2) % math.max(#cands, 1) + 1 end
        local now = cands[candIndex]
        if now ~= hovered then outline(hovered, false); hovered = now; cellPick = 1 end
        outline(hovered, true)

        for _, cell in ipairs(su.cells) do
            local p = vector3(cell.coords.x, cell.coords.y, cell.coords.z)
            if #(me - p) < 40.0 then
                if cell.door then marker(p, 76, 175, 80) else marker(p, 233, 211, 28) end
                text3d(p + vector3(0, 0, 0.9), cell.label .. (cell.door and '  (door set)' or '  (no door)'))
            end
        end

        local status, choices, target = 'Walk up to a cell door or aim at it', {}, nil
        if hovered then
            local owner = doorOf(hovered)
            local real = probeDoor(hovered)
            choices = cellsFor(hovered)
            if released(44) and #choices > 0 then cellPick = cellPick % #choices + 1 end
            target = choices[cellPick] and choices[cellPick].cell
            if owner then status = ('Lit up: already the door of %s'):format(owner.label)
            elseif real == false then status = 'Lit up: not a working door (frame or prop). Scroll to the next object'
            elseif not target then status = 'Lit up: no cell of this suite near it'
            else status = ('Lit up: ~INPUT_PICKUP~ make it the door of %s%s'):format(target.label, real == nil and ' (checking...)' or '') end
            if target then
                local tp = vector3(target.coords.x, target.coords.y, target.coords.z)
                local dc = GetEntityCoords(hovered)
                DrawLine(dc.x, dc.y, dc.z, tp.x, tp.y, tp.z + 0.3, 255, 221, 0, 220)
            end
            if released(38) and target and not owner and real ~= false then
                local c = GetEntityCoords(hovered)
                undo[#undo + 1] = { cell = target, prev = target.door }
                target.door = { model = GetEntityModel(hovered), coords = { x = c.x, y = c.y, z = c.z } }
                PlaySoundFrontend(-1, 'SELECT', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
            end
        end
        local done = 0
        for _, cell in ipairs(su.cells) do if cell.door then done = done + 1 end end
        help({ ('Cell doors: %s (%d of %d cells have a door)'):format(su.label, done, #su.cells), status,
            '~INPUT_COVER~ another cell   scroll: another object',
            '~INPUT_MULTIPLAYER_INFO~ undo   ~INPUT_FRONTEND_ACCEPT~ save and finish   ~INPUT_FRONTEND_CANCEL~ leave without saving' })

        if released(20) and #undo > 0 then
            local u = table.remove(undo)
            u.cell.door = u.prev
            PlaySoundFrontend(-1, 'BACK', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
        elseif confirm() then
            outline(hovered, false)
            return finish(all, #undo > 0)
        elseif back() then
            outline(hovered, false)
            return finish(all, false)
        end
    end
end

---------------------------------------------------------------------------
-- Place cameras: a free camera you fly into the corner and line up (like vinewood_prison).
-- Saved inside a cell (or close to one) it becomes that cell's camera; otherwise a suite camera.
---------------------------------------------------------------------------
local function moveVector(pitch, yaw)
    local rz, rx = math.rad(yaw), math.rad(pitch)
    local fwd = vector3(-math.sin(rz) * math.cos(rx), math.cos(rz) * math.cos(rx), math.sin(rx))
    local right = vector3(math.cos(rz), math.sin(rz), 0.0)
    local speed = IsDisabledControlPressed(0, 21) and 8.0 or IsDisabledControlPressed(0, 19) and 0.8 or 3.0
    local move = vector3(0.0, 0.0, 0.0)
    if IsDisabledControlPressed(0, 32) then move = move + fwd end
    if IsDisabledControlPressed(0, 33) then move = move - fwd end
    if IsDisabledControlPressed(0, 35) then move = move + right end
    if IsDisabledControlPressed(0, 34) then move = move - right end
    if IsDisabledControlPressed(0, 22) then move = move + vector3(0.0, 0.0, 1.0) end
    if IsDisabledControlPressed(0, 36) then move = move - vector3(0.0, 0.0, 1.0) end
    return move * speed * GetFrameTime()
end

local function placeCameras(suiteId)
    local all, su = suiteCopy(suiteId)
    if not su then return VPO.ClientNotify(L('world_save_suite_first'), 'error') end
    su.cameras = su.cameras or {}
    busy = true
    local CC = Config.Custody.CCTV
    local start, rot = GetGameplayCamCoord(), GetGameplayCamRot(2)
    local cam = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
    local pitch, yaw, fov = rot.x, rot.z, 60.0
    SetCamCoord(cam, start.x, start.y, start.z)
    SetCamRot(cam, pitch, 0.0, yaw, 2)
    SetCamFov(cam, fov)
    RenderScriptCams(true, false, 0, true, true)
    local added, preview = {}, false

    local function cellFor(pos)
        local best, bestD
        for _, cell in ipairs(su.cells) do
            local p = vector3(cell.coords.x, cell.coords.y, cell.coords.z)
            local d = #(vector2(p.x, p.y) - vector2(pos.x, pos.y))
            if d < 4.5 and math.abs(p.z - pos.z) < 4.0 and (not bestD or d < bestD) then best, bestD = cell, d end
        end
        return best
    end
    local function nextLabel(cell)
        if cell then return cell.label end
        local n = 1
        for _, c in ipairs(su.cameras) do if not c.cell then n = n + 1 end end
        return ('Custody %d'):format(n)
    end

    local result = 'cancel'
    while true do
        Wait(0)
        DisableAllControlActions(0)
        EnableControlAction(0, 245, true)
        yaw = yaw - GetDisabledControlNormal(0, 1) * 8.0
        pitch = math.max(-89.0, math.min(89.0, pitch - GetDisabledControlNormal(0, 2) * 8.0))
        local pos = GetCamCoord(cam) + moveVector(pitch, yaw)
        SetCamCoord(cam, pos.x, pos.y, pos.z)
        SetCamRot(cam, pitch, 0.0, yaw, 2)
        SetFocusPosAndVel(pos.x, pos.y, pos.z, 0.0, 0.0, 0.0)
        if IsDisabledControlJustPressed(0, 241) then fov = math.max(CC.MinFov, fov - 3.0); SetCamFov(cam, fov) end
        if IsDisabledControlJustPressed(0, 242) then fov = math.min(CC.MaxFov, fov + 3.0); SetCamFov(cam, fov) end
        local cell = cellFor(pos)
        local hasCam = false
        if cell then for _, c in ipairs(su.cameras) do if c.cell == cell.id then hasCam = true end end end
        help({ ('Place cameras: %s (%d added)'):format(su.label, #added),
            ('This view saves as: %s%s   FOV %d'):format(nextLabel(cell), hasCam and ' (replaces its camera)' or '', math.floor(fov)),
            'WASD move  Space up  Ctrl down  Shift faster  Alt slower  mouse aim  scroll zoom',
            '~INPUT_PICKUP~ save this view   ~INPUT_ENTER~ CCTV look ' .. (preview and 'on' or 'off'),
            '~INPUT_MULTIPLAYER_INFO~ undo   ~INPUT_FRONTEND_ACCEPT~ save and finish   ~INPUT_FRONTEND_CANCEL~ leave without saving' })
        if IsDisabledControlJustReleased(0, 23) then
            preview = not preview
            if preview then SetTimecycleModifier(CC.Filter); SetTimecycleModifierStrength(CC.FilterStrength) else ClearTimecycleModifier() end
        elseif IsDisabledControlJustReleased(0, 38) then
            local entry = { id = 'K' .. (GetGameTimer() % 100000), label = nextLabel(cell), cell = cell and cell.id or nil,
                coords = { x = pos.x, y = pos.y, z = pos.z }, rot = { x = pitch, y = 0.0, z = yaw }, fov = fov }
            local replaced
            if cell then
                for idx, c in ipairs(su.cameras) do if c.cell == cell.id then replaced = { idx = idx, prev = c }; su.cameras[idx] = entry end end
            end
            if not replaced then su.cameras[#su.cameras + 1] = entry end
            added[#added + 1] = { entry = entry, replaced = replaced }
            PlaySoundFrontend(-1, 'Camera_Shoot', 'Phone_Soundset_Franklin', true)
        elseif IsDisabledControlJustReleased(0, 20) and #added > 0 then
            local u = table.remove(added)
            if u.replaced then su.cameras[u.replaced.idx] = u.replaced.prev
            else for idx, c in ipairs(su.cameras) do if c == u.entry then table.remove(su.cameras, idx) break end end end
            PlaySoundFrontend(-1, 'BACK', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
        elseif IsDisabledControlJustReleased(0, 191) or IsDisabledControlJustReleased(0, 201) or IsDisabledControlJustReleased(0, 18) then
            result = 'save' break
        elseif IsDisabledControlJustReleased(0, 177) or IsDisabledControlJustReleased(0, 200) then
            break
        end
    end
    ClearTimecycleModifier()
    RenderScriptCams(false, false, 0, true, true)
    DestroyCam(cam, false)
    ClearFocus()
    return finish(all, result == 'save' and #added > 0)
end

RegisterNUICallback('locWorld', function(body, cb)
    cb({})
    if busy or type(body) ~= 'table' or not body.suite then return end
    VPO.UI.Close()
    CreateThread(function()
        Wait(250)
        if body.mode == 'cells' then placeCells(body.suite) elseif body.mode == 'doors' then setDoors(body.suite) elseif body.mode == 'cameras' then placeCameras(body.suite) end
    end)
end)

---------------------------------------------------------------------------
-- Admin panel (/vpo)
---------------------------------------------------------------------------
RegisterNetEvent('vinewood_police:client:admin:open', function()
    VPO.UI.OpenTask('admin', 'admin:panel', nil)
end)

RegisterNUICallback('adminLocations', function(_, cb)
    cb({})
    VPO.UI.OpenTask('locations', 'loc:get', nil)
end)

RegisterNUICallback('adminCommand', function(body, cb)
    cb({})
    local cmds = { management = Config.Management.Command, standards = Config.Standards.Command }
    local c = type(body) == 'table' and cmds[body.cmd]
    if c then ExecuteCommand(c) end
end)
