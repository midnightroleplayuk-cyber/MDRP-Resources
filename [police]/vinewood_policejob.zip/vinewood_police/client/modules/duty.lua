-- Sign-on points, the hub command and duty notifications.
local L = VPO.L

RegisterCommand(Config.Duty.Command, function() VPO.UI.Open('duty') end, false)
if Config.Duty.Keybind and Config.Duty.Keybind ~= '' then
    RegisterKeyMapping(Config.Duty.Command, 'Police hub', 'keyboard', Config.Duty.Keybind)
end

VPO.Zones.Register('signon', function()
    local out = {}
    for _, st in ipairs(Config.Stations or {}) do
        if st.signOn then
            out[#out + 1] = { name = ('vpo_signon_%s'):format(st.id), box = st.signOn, options = {
                { name = 'vpo_signon', label = 'Sign on / off', icon = 'fas fa-id-badge', distance = 2.0,
                  onSelect = function() VPO.UI.Open('duty') end },
            } }
        end
    end
    return out
end)

-- Duty state comes from the server-owned statebag.
AddStateBagChangeHandler(VPO.StateDefs.duty.bag, ('player:%s'):format(GetPlayerServerId(PlayerId())), function(_, _, value)
    TriggerEvent('vinewood_police:client:dutyChanged', value ~= nil, value)
    VPO.UI.Push({ type = 'duty', duty = value })
end)
