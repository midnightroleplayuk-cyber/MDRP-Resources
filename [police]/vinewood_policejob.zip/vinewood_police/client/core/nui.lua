-- NUI bridge. The page asks for an action; this forwards it to the matching server callback.
-- Only actions listed here can be reached from the page.
local ACTIONS = {
    ['hub:open'] = true,
    ['duty:signOn'] = true, ['duty:signOff'] = true, ['duty:summary'] = true, ['duty:setStatus'] = true, ['duty:roster'] = true,
    ['notebook:list'] = true, ['notebook:add'] = true,
    ['equipment:locker'] = true, ['equipment:draw'] = true, ['equipment:return'] = true, ['equipment:uniform'] = true, ['equipment:changing'] = true,
    ['arrest:prepare'] = true, ['arrest:submit'] = true, ['arrest:showCaution'] = true, ['arrest:release'] = true, ['arrest:releasePrepare'] = true,
    ['search:open'] = true, ['search:openInventory'] = true, ['search:seize'] = true,
    ['stopsearch:prepare'] = true, ['stopsearch:submit'] = true,
    ['roads:open'] = true, ['roads:checkDriver'] = true, ['roads:reason'] = true, ['roads:ticket'] = true, ['roads:close'] = true,
    ['roads:npcAsk'] = true, ['roads:npcWarn'] = true, ['roads:npcPnc'] = true, ['roads:npcFingerprint'] = true,
    ['roads:npcStepOut'] = true, ['roads:npcArrest'] = true, ['roads:npcHandover'] = true,
    ['roads:searchVehicle'] = true, ['roads:forceEntry'] = true, ['roads:npcSearch'] = true, ['roads:npcSeize'] = true,
    ['roads:test'] = true, ['roads:seize'] = true,
    ['scene:info'] = true, ['scene:traffic'] = true, ['scene:clear'] = true,
    ['custody:panel'] = true, ['custody:log'] = true, ['custody:bookIn'] = true, ['custody:takeProperty'] = true,
    ['custody:openProperty'] = true, ['custody:cell'] = true, ['custody:out'] = true, ['custody:back'] = true,
    ['custody:welfare'] = true, ['custody:release'] = true, ['custody:returnProperty'] = true, ['custody:npc'] = true,
    ['evidence:list'] = true, ['evidence:open'] = true, ['evidence:status'] = true,
    ['enc:open'] = true, ['enc:ask'] = true, ['enc:warn'] = true, ['enc:pnc'] = true, ['enc:fingerprint'] = true, ['enc:search'] = true,
    ['enc:seize'] = true, ['enc:test'] = true, ['enc:arrest'] = true, ['enc:handover'] = true, ['enc:release'] = true,
    ['call:list'] = true, ['call:open'] = true, ['call:attach'] = true, ['call:close'] = true, ['call:backup'] = true, ['call:backupHere'] = true,
    ['loc:get'] = true, ['loc:save'] = true, ['loc:reset'] = true,
    ['custody:buzzer'] = true, ['custody:door'] = true, ['custody:cctv'] = true,
    ['admin:panel'] = true, ['admin:callouts'] = true, ['admin:callout'] = true, ['admin:uncuff'] = true, ['admin:acecheck'] = true, ['admin:quals'] = true,
    ['armoury:view'] = true, ['armoury:draw'] = true, ['armoury:handIn'] = true,
    ['incident:panel'] = true, ['incident:declare'] = true, ['incident:join'] = true, ['incident:leave'] = true, ['incident:role'] = true,
    ['incident:cordon'] = true, ['incident:note'] = true, ['incident:standDown'] = true,
    ['cid:list'] = true, ['cid:create'] = true, ['cid:open'] = true, ['cid:update'] = true,
    ['uof:list'] = true, ['uof:submit'] = true, ['complaint:prepare'] = true, ['complaint:submit'] = true,
    ['manage:panel'] = true, ['manage:hire'] = true, ['manage:rank'] = true, ['manage:suspend'] = true, ['manage:fire'] = true, ['manage:collar'] = true, ['manage:quals'] = true, ['manage:qualGrant'] = true, ['manage:qualRevoke'] = true,
    ['standards:panel'] = true, ['standards:review'] = true, ['standards:audit'] = true, ['standards:officer'] = true,
}

--- Street and area where the player stands, e.g. "Vespucci Boulevard, Little Seoul".
function VPO.Location()
    local c = GetEntityCoords(PlayerPedId())
    local street, cross = GetStreetNameAtCoord(c.x, c.y, c.z)
    local name = GetStreetNameFromHashKey(street)
    if cross ~= 0 then name = name .. ' / ' .. GetStreetNameFromHashKey(cross) end
    local zone = GetLabelText(GetNameOfZone(c.x, c.y, c.z))
    if zone and zone ~= '' and zone ~= 'NULL' then name = name .. ', ' .. zone end
    return name
end

VPO.UI = { open = false }

function VPO.UI.Request(action, data)
    if not ACTIONS[action] then return { error = 'Unknown action.' } end
    local res = lib.callback.await('vinewood_police:cb:' .. action, false, data)
    return type(res) == 'table' and res or { error = 'No response from the server.' }
end

--- Hooks the page can trigger client-side after a successful server call.
local after = {}
function VPO.UI.After(action, fn) after[action] = fn end

function VPO.UI.Open(tab)
    local data = VPO.UI.Request('hub:open')
    if data.error then return VPO.ClientNotify(data.error, 'error') end
    VPO.UI.open = true
    SetNuiFocus(true, true)
    SendNUIMessage({ type = 'open', tab = tab or 'duty', data = data })
end

--- Opens a task panel (arrest, search, stop and search) about another player.
--- prepare is the server callback that checks it's allowed and returns the form data.
function VPO.UI.OpenTask(task, prepare, target, waitingMessage)
    CreateThread(function()
        if waitingMessage then VPO.ClientNotify(waitingMessage, 'inform') end
        local data = VPO.UI.Request(prepare, { target = target })
        if data.error then return VPO.ClientNotify(data.error, 'error') end
        VPO.UI.open = true
        SetNuiFocus(true, true)
        SendNUIMessage({ type = 'task', task = task, target = target, data = data, location = VPO.Location() })
    end)
end

function VPO.UI.Close()
    VPO.UI.open = false
    SetNuiFocus(false, false)
    SendNUIMessage({ type = 'close' })
    TriggerEvent('vinewood_police:client:uiClosed')
end

function VPO.UI.Push(msg)
    if VPO.UI.open then SendNUIMessage(msg) end
end

RegisterNUICallback('request', function(body, cb)
    local action = type(body) == 'table' and body.action or nil
    local res = VPO.UI.Request(action, type(body) == 'table' and body.data or nil)
    if not res.error and after[action] then
        local ok, err = pcall(after[action], res, body.data)
        if not ok then VPO.Log.error('after %s failed: %s', action, err) end
    end
    cb(res)
end)

RegisterNUICallback('close', function(_, cb)
    VPO.UI.Close()
    cb({})
end)

AddEventHandler('onResourceStop', function(res)
    if res == VPO.Resource and VPO.UI.open then SetNuiFocus(false, false) end
end)
