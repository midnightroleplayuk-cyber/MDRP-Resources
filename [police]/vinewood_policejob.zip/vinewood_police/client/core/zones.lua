-- Target zones built from places in Config (stations, lockers, custody desks). Each module registers a
-- builder; zones are rebuilt whenever an admin changes the places in game.
VPO.Zones = {}
local builders, active = {}, {} -- active[group] = { zone names }

--- builder() returns { { name, box = { coords, size, rotation }, options = {...} }, ... }
function VPO.Zones.Register(group, builder) builders[group] = builder end

local function clear(group)
    for _, name in ipairs(active[group] or {}) do VPO.Target.RemoveZone(name) end
    active[group] = {}
end

function VPO.Zones.Rebuild()
    for group, build in pairs(builders) do
        clear(group)
        local ok, list = pcall(build)
        if ok then
            for _, z in ipairs(list or {}) do
                VPO.Target.AddBox(z.name, z.box, z.options)
                active[group][#active[group] + 1] = z.name
            end
        else
            VPO.Log.error('zones %s failed: %s', group, list)
        end
    end
end

CreateThread(function()
    Wait(1200) -- give the target resource a moment if both start together
    VPO.Zones.Rebuild()
end)

AddEventHandler('vinewood_police:client:locationsChanged', function() VPO.Zones.Rebuild() end)

AddEventHandler('onResourceStop', function(res)
    if res ~= VPO.Resource then return end
    for group in pairs(active) do clear(group) end
end)
