-- Client core. The client only displays and requests; the server decides.
RegisterNetEvent(VPO.Events.notify, function(message, kind, duration)
    VPO.ClientNotify(message, kind, duration)
end)

--- Server-owned state for this player, read from the replicated statebags.
function VPO.MyState(key)
    local d = VPO.StateDefs[key]
    return d and LocalPlayer.state[d.bag] or nil
end

if Config.Debug then
    RegisterCommand('vpostate', function()
        for key, d in pairs(VPO.StateDefs) do
            print(('%-10s %s'):format(key, json.encode(LocalPlayer.state[d.bag])))
        end
    end, false)
end
